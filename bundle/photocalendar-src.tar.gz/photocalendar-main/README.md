# CraftOffice PhotoCalendar

Rétegalapú fotónaptár-készítő (Rust, egui). Minden elem – a sablonok is – szerkeszthető.

## Fordítás és futtatás
    cargo run --release          # Windows és Linux
Windows: telepítsd a Rust-ot (rustup), majd a fenti parancs elég. Linux: a rendszer EGL/X11/Wayland csomagjai kellenek.
Android: még nincs (egui/rfd Android-előkészítés szükséges).

## Felépítés
- `model.rs` dokumentummodell (projekt, oldalak, rétegek) – JSON-ba menthető
- `generate.rs` naptártípusok és kötések oldalgenerátora; `templates.rs` beépített sablonok; `clipart.rs` clipart
- `layout.rs` oldal → rajzparancsok (DrawList); `raster.rs` (PNG/előnézet), `pdf.rs` (vektoros PDF), `gui.rs` (szerkesztő)
- `holidays.rs` szabályalapú ünnepek (HU, RO) – a listát hivatalos forrással ellenőrizni kell
- Betűtípus: Liberation Sans (SIL OFL), `assets/`

## Állapot
Lásd docs/FUNKCIOK.md. Ismert korlátok: Android-port még nincs; Windows build nem tesztelt; az ünnepnap-adatokat hivatalos listával ellenőrizni kell; CMYK csak vektor/szöveg (a printpdf nem tud CMYK képet; a fotók RGB-ben maradnak); a bleed a teljes oldalas, maszk nélküli képet kiterjeszti, a maszkos vagy forgatott rétegeket nem. Az N-up csempézés opcionálisan kicsinyít ("Nagy oldalak kicsinyítése").

## Ünnepnapok – ellenőrzés (2026-11-24)
- **Románia:** a lista megegyezik a Munka Törvénykönyve 139. cikkével (17 nap: Újév 1–2, Vízkereszt, Szent János, Egyesülés napja, ortodox nagypéntek + húsvét 2 nap, május 1, június 1, ortodox pünkösd 2 nap, Nagyboldogasszony, Szent András, december 1, karácsony 2 nap). Forrás: Codul muncii art. 139 (Legea 52/2023, 64/2018). A kormány által kiadott "áthidaló" napok évente változnak – ezeket Munkanap/Szabadnap eseményként kell felvenni.
- **Magyarország:** a december 24. a 2026. évi LXXII. törvény óta állandó munkaszüneti nap (2026-tól); a program ezt csak 2026-tól jelöli (az esemény "érvényes ettől az évtől" mezője). Az áthelyezett munkanapok/pihenőnapok minden évben miniszteri rendelettel jelennek meg; a 2027-es rendeletet még nem találtam, ezért a programban nincsenek benne – az Ünnepnapok ablakban "Egyszeri dátum" szabállyal vehetők fel (Munkanap / Szabadnap).

## Felület nyelve
A program felülete magyar, román és angol. Első indításkor a rendszer nyelvéből (LANG) választ, később a "Nyelv / Limbă / Language" menüben állítható, és a beállítások között megmarad. A fordítások az `i18n/dict.tsv` fájlban vannak (hu, ro, en oszlopok); hiányzó bejegyzés magyarul jelenik meg. Új nyelv felvételéhez új oszlop és `UiLang` változat kell.
