# CraftOffice PhotoCalendar

Rétegalapú fotónaptár-készítő (Rust, egui). Minden elem – a sablonok is – szerkeszthető.

## Fordítás és futtatás
    cargo run --release          # Windows és Linux
Windows: telepítsd a Rust-ot (rustup), majd a fenti parancs elég. Linux: a rendszer EGL/X11/Wayland csomagjai kellenek.
Android: még nincs (egui/rfd Android-előkészítés szükséges).

## Felépítés
- `model.rs` dokumentummodell (projekt, oldalak, rétegek) – JSON-ba menthető
- `generate.rs` naptártípusok és kötések oldalgenerátora; `templates.rs` beépített sablonok; `clipart.rs` clipart
- `layout.rs` oldal → rajzparancsok (DrawList); `raster.rs` (PNG/előnézet), `pdf.rs` (vektoros PDF), `gui.rs` (szerkesztő)
- `holidays.rs` szabályalapú ünnepek (HU, RO) – a listát hivatalos forrással ellenőrizni kell
- Betűtípus: Liberation Sans (SIL OFL), `assets/`

## Új a 0.3-ban
- Betűválasztó a szövegrétegeknél és a naptárrács stílusainál. 23 beépített szabad betűcsalád (SIL OFL, licencek: `assets/fonts/licenses/`), mind magyar és román ékezetekkel: Open Sans, Roboto, Roboto Condensed, Montserrat, Lato, Nunito, Raleway, Oswald, Source Sans 3, Noto Sans, Comfortaa, Merriweather, Lora, Playfair Display, Noto Serif, Yeseva One, Pacifico, Amatic SC, Great Vibes, Dancing Script, Caveat, Liberation Sans/Serif/Mono, Carlito, Caladea.
- A gépre telepített betűk (Windows, Linux, macOS) is választhatók; a programba nem kerülnek bele.
- Ha egy projekt betűje hiányzik a gépről, a program egy azonos szélességű szabad betűt használ helyette (Arial → Liberation Sans, Times New Roman → Liberation Serif, Courier New → Liberation Mono, Calibri → Carlito, Cambria → Caladea), és megnyitáskor jelzi.
- A PDF a használt betűket beágyazza; a beágyazást tiltó betű helyett a szabad megfelelője kerül bele.
- Az új sablonok saját betűt kaptak (Növényi: Lora, Napfelkelte: Montserrat, Hullámok: Nunito).

## Új a 0.2-ben
- Naptártípusok: Havi (egy hónap), Negyedéves (3 hónap oldalanként), Kétéves és Hároméves (24 / 36 hónap egy lapon). Az éves, 12 oldalas naptár a Spirálkötött típus (minden hónap külön oldalon).
- Saját sablonok: Növényi, Napfelkelte, Hullámok (és a meglévő Minimál) – saját vektorgrafikával, minden elemük (színek, cím, alcím, margók, fotó) szerkeszthető réteg.
- Napcellánként saját háttérszín vagy kép („Fotó naphoz” + cellaszín); Réteg › Minden réteg törlése az oldalról.
- Események: születésnap, évforduló és **névnap** (saját bejegyzés; beépített névnaplista nincs), évente ismétlődő vagy egyszeri dátummal.
- Holdfázisok: jelölve, hogy közelítő számítás (átlagos holdhónap, ±1 nap).
- Projektfájl: verziózott formátum (2), betöltéskor értékellenőrzés, újabb verziójú fájl elutasítása, a képek a projektfájlba csomagolhatók (Fájl › Képek mentése a projektfájlba) – betöltéskor a `<projekt>_kepek/` mappába kerülnek. Mentés átmeneti fájlon át. Figyelmeztetés nem mentett változásokra (bezárás, megnyitás, új naptár).
- Nyomtatási előnézet (Fájl › Nyomtatási előnézet…): pontosan azok a lapok, amelyek a PDF-be / nyomtatóra kerülnek, a képpontmérettel együtt (A4, 300 dpi: 2480 × 3508, fekvő 3508 × 2480).
- Minden feldolgozás helyben történik; a program nem küld semmit hálózatra.

## Állapot
Lásd docs/FUNKCIOK.md. Ismert korlátok: Android-port még nincs; Windows build nem tesztelt; az ünnepnap-adatokat hivatalos listával ellenőrizni kell; CMYK csak vektor/szöveg (a printpdf nem tud CMYK képet; a fotók RGB-ben maradnak); a bleed a teljes oldalas, maszk nélküli képet kiterjeszti, a maszkos vagy forgatott rétegeket nem. Az N-up csempézés opcionálisan kicsinyít ("Nagy oldalak kicsinyítése").

## Ünnepnapok – ellenőrzés (2026-11-24)
- **Románia:** a lista megegyezik a Munka Törvénykönyve 139. cikkével (17 nap: Újév 1–2, Vízkereszt, Szent János, Egyesülés napja, ortodox nagypéntek + húsvét 2 nap, május 1, június 1, ortodox pünkösd 2 nap, Nagyboldogasszony, Szent András, december 1, karácsony 2 nap). Forrás: Codul muncii art. 139 (Legea 52/2023, 64/2018). A kormány által kiadott "áthidaló" napok évente változnak – ezeket Munkanap/Szabadnap eseményként kell felvenni.
- **Magyarország:** a december 24. a 2026. évi LXXII. törvény óta állandó munkaszüneti nap (2026-tól); a program ezt csak 2026-tól jelöli (az esemény "érvényes ettől az évtől" mezője). Az áthelyezett munkanapok/pihenőnapok minden évben miniszteri rendelettel jelennek meg; a 2027-es rendeletet még nem találtam, ezért a programban nincsenek benne – az Ünnepnapok ablakban "Egyszeri dátum" szabállyal vehetők fel (Munkanap / Szabadnap).

## Felület nyelve
A program felülete magyar, román és angol. Első indításkor a rendszer nyelvéből (LANG) választ, később a "Nyelv / Limbă / Language" menüben állítható, és a beállítások között megmarad. A fordítások az `i18n/dict.tsv` fájlban vannak (hu, ro, en oszlopok); hiányzó bejegyzés magyarul jelenik meg. Új nyelv felvételéhez új oszlop és `UiLang` változat kell.
