//! Calendar core: date math, Easter, Hungarian/Romanian holidays, names.
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub enum Lang {
    Hu,
    Ro,
    En,
    De,
    Fr,
    Es,
    It,
    Sk,
}

impl Lang {
    pub const ALL: [Lang; 8] = [Lang::Hu, Lang::Ro, Lang::En, Lang::De, Lang::Fr, Lang::Es, Lang::It, Lang::Sk];
    pub fn label(self) -> &'static str {
        match self {
            Lang::Hu => "Magyar",
            Lang::Ro => "Română",
            Lang::En => "English",
            Lang::De => "Deutsch",
            Lang::Fr => "Français",
            Lang::Es => "Español",
            Lang::It => "Italiano",
            Lang::Sk => "Slovenčina",
        }
    }
    pub fn idx(self) -> usize {
        Lang::ALL.iter().position(|l| *l == self).unwrap_or(0)
    }
}

pub fn is_leap(y: i32) -> bool {
    (y % 4 == 0 && y % 100 != 0) || y % 400 == 0
}

pub fn days_in_month(y: i32, m: u32) -> u32 {
    match m {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        _ => {
            if is_leap(y) {
                29
            } else {
                28
            }
        }
    }
}

/// Day number since 1970-01-01.
pub fn to_days(y: i32, m: u32, d: u32) -> i64 {
    let y = if m <= 2 { y - 1 } else { y } as i64;
    let era = y.div_euclid(400);
    let yoe = y - era * 400;
    let mp = (m as i64 + 9) % 12;
    let doy = (153 * mp + 2) / 5 + d as i64 - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146097 + doe - 719468
}

pub fn from_days(z: i64) -> (i32, u32, u32) {
    let z = z + 719468;
    let era = z.div_euclid(146097);
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
    let m = if mp < 10 { mp + 3 } else { mp - 9 } as u32;
    ((if m <= 2 { y + 1 } else { y }) as i32, m, d)
}

/// 0 = Monday .. 6 = Sunday
pub fn weekday(y: i32, m: u32, d: u32) -> u32 {
    (to_days(y, m, d) + 3).rem_euclid(7) as u32
}

/// Western (Gregorian) Easter Sunday as day number.
pub fn easter_western(y: i32) -> i64 {
    let a = y % 19;
    let b = y / 100;
    let c = y % 100;
    let d = b / 4;
    let e = b % 4;
    let f = (b + 8) / 25;
    let g = (b - f + 1) / 3;
    let h = (19 * a + b - d - g + 15) % 30;
    let i = c / 4;
    let k = c % 4;
    let l = (32 + 2 * e + 2 * i - h - k) % 7;
    let m = (a + 11 * h + 22 * l) / 451;
    let month = (h + l - 7 * m + 114) / 31;
    let day = (h + l - 7 * m + 114) % 31 + 1;
    to_days(y, month as u32, day as u32)
}

/// Orthodox Easter (Julian computus, converted to Gregorian; valid 1900-2099: +13 days).
pub fn easter_orthodox(y: i32) -> i64 {
    let a = y % 4;
    let b = y % 7;
    let c = y % 19;
    let d = (19 * c + 15) % 30;
    let e = (2 * a + 4 * b - d + 34) % 7;
    let month = (d + e + 114) / 31;
    let day = (d + e + 114) % 31 + 1;
    // Julian date -> days; Julian day offset to Gregorian is 13 in 1900..2099
    to_days(y, month as u32, day as u32) + 13
}

const MONTHS: [[&str; 12]; 8] = [
    ["Január", "Február", "Március", "Április", "Május", "Június", "Július", "Augusztus", "Szeptember", "Október", "November", "December"],
    ["Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"],
    ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"],
    ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"],
    ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
    ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"],
    ["Január", "Február", "Marec", "Apríl", "Máj", "Jún", "Júl", "August", "September", "Október", "November", "December"],
];
const WD_SHORT: [[&str; 7]; 8] = [
    ["H", "K", "Sze", "Cs", "P", "Szo", "V"],
    ["L", "Ma", "Mi", "J", "V", "S", "D"],
    ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"],
    ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"],
    ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"],
    ["Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom"],
    ["Po", "Ut", "St", "Št", "Pi", "So", "Ne"],
];
const WD_LONG: [[&str; 7]; 8] = [
    ["Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat", "Vasárnap"],
    ["Luni", "Marți", "Miercuri", "Joi", "Vineri", "Sâmbătă", "Duminică"],
    ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"],
    ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"],
    ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"],
    ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"],
    ["Pondelok", "Utorok", "Streda", "Štvrtok", "Piatok", "Sobota", "Nedeľa"],
];
const WEEK: [&str; 8] = ["Hét", "Săpt", "Wk", "KW", "Sem", "Sem", "Sett", "Týž"];

/// Month name (1..=12).
pub fn month_name(lang: Lang, m: u32) -> &'static str {
    MONTHS[lang.idx()][(m.clamp(1, 12) - 1) as usize]
}

/// Short weekday names, Monday first.
pub fn weekday_short(lang: Lang, wd: u32) -> &'static str {
    WD_SHORT[lang.idx()][(wd % 7) as usize]
}

/// Full weekday names, Monday first.
pub fn weekday_name(lang: Lang, wd: u32) -> &'static str {
    WD_LONG[lang.idx()][(wd % 7) as usize]
}

pub fn week_short(lang: Lang) -> &'static str {
    WEEK[lang.idx()]
}

/// ISO 8601 (year, week number) of a date.
pub fn iso_week(y: i32, m: u32, d: u32) -> (i32, u32) {
    let dn = to_days(y, m, d);
    let thursday = dn - weekday(y, m, d) as i64 + 3;
    let (ty, _, _) = from_days(thursday);
    let jan1 = to_days(ty, 1, 1);
    (ty, ((thursday - jan1) / 7 + 1) as u32)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn easter() {
        assert_eq!(from_days(easter_western(2025)), (2025, 4, 20));
        assert_eq!(from_days(easter_western(2026)), (2026, 4, 5));
        assert_eq!(from_days(easter_orthodox(2025)), (2025, 4, 20));
        assert_eq!(from_days(easter_orthodox(2026)), (2026, 4, 12));
        assert_eq!(from_days(easter_orthodox(2024)), (2024, 5, 5));
    }
    #[test]
    fn iso() {
        assert_eq!(iso_week(2026, 1, 1), (2026, 1));
        assert_eq!(iso_week(2027, 1, 1), (2026, 53));
        assert_eq!(iso_week(2024, 12, 30), (2025, 1));
    }
    #[test]
    fn wd() {
        assert_eq!(weekday(2026, 11, 23), 0); // Monday
        assert_eq!(weekday(2000, 1, 1), 5); // Saturday
    }
}

/// Moon phase quarter that begins on this day: Some(0) new moon, 1 first quarter, 2 full moon, 3 last quarter.
/// Mean synodic month approximation (error well under a day), good for calendar icons.
pub fn moon_quarter_on(y: i32, m: u32, d: u32) -> Option<u32> {
    const NEW_MOON_2000: f64 = 10962.76; // days since 1970-01-01 of the new moon of 2000-01-06 18:14 UTC
    const SYN: f64 = 29.530588853;
    let day = to_days(y, m, d) as f64;
    let q = |t: f64| ((t - NEW_MOON_2000) / SYN * 4.0).floor();
    let (a, b) = (q(day), q(day + 1.0));
    if a != b { Some((b as i64).rem_euclid(4) as u32) } else { None }
}

#[cfg(test)]
mod moon_tests {
    use super::*;
    #[test]
    fn known_moons() {
        // new moon 2026-11-09, full moon 2026-11-24 (UTC dates, +-1 day tolerance)
        let near = |q: u32, y: i32, m: u32, d: u32| (d.saturating_sub(1)..=d + 1).any(|x| moon_quarter_on(y, m, x) == Some(q));
        assert!(near(0, 2026, 11, 9));
        assert!(near(2, 2026, 11, 24));
        assert!(near(0, 2027, 12, 28));
    }
}
