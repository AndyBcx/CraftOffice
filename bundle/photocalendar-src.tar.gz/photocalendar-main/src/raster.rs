//! Software rasteriser for DrawList -> RGBA image (PNG/JPEG export, tests).
use crate::draw::{Cmd, DrawList};
use crate::font;
use crate::shapes;
use crate::model::{Align, RectMm, Rgba};
use ab_glyph::{Font, ScaleFont};
use image::{DynamicImage, RgbaImage};
use std::collections::HashMap;

pub struct ImageCache {
    map: HashMap<String, Option<DynamicImage>>,
    /// If set, images are downscaled on load so that the longer side is at most this (preview use).
    max_side: Option<u32>,
}

impl ImageCache {
    pub fn new() -> Self {
        ImageCache { map: HashMap::new(), max_side: None }
    }
    pub fn preview(max_side: u32) -> Self {
        ImageCache { map: HashMap::new(), max_side: Some(max_side) }
    }
    pub fn clear(&mut self) {
        self.map.clear();
    }
    pub fn get(&mut self, path: &str) -> Option<&DynamicImage> {
        let ms = self.max_side;
        self.map
            .entry(path.to_string())
            .or_insert_with(|| {
                let im = image::open(path).ok()?;
                match ms {
                    Some(m) if im.width().max(im.height()) > m => Some(im.resize(m, m, image::imageops::FilterType::Triangle)),
                    _ => Some(im),
                }
            })
            .as_ref()
    }
}

impl Default for ImageCache {
    fn default() -> Self {
        Self::new()
    }
}

/// Brightness / contrast / saturation (each -1..1) applied in place.
pub fn apply_fx(img: &mut RgbaImage, fx: (f32, f32, f32)) {
    let (b, c, sat) = fx;
    if b == 0.0 && c == 0.0 && sat == 0.0 {
        return;
    }
    for p in img.pixels_mut() {
        let mut v = [p.0[0] as f32, p.0[1] as f32, p.0[2] as f32];
        let lum = 0.299 * v[0] + 0.587 * v[1] + 0.114 * v[2];
        for ch in v.iter_mut() {
            *ch = lum + (*ch - lum) * (1.0 + sat);
            *ch = (*ch - 128.0) * (1.0 + c) + 128.0 + b * 255.0;
        }
        for i in 0..3 {
            p.0[i] = v[i].clamp(0.0, 255.0) as u8;
        }
    }
}

fn blend(img: &mut RgbaImage, x: i32, y: i32, c: Rgba, cov: f32) {
    if x < 0 || y < 0 || x >= img.width() as i32 || y >= img.height() as i32 {
        return;
    }
    let a = (c.3 as f32 / 255.0) * cov.clamp(0.0, 1.0);
    if a <= 0.0 {
        return;
    }
    let p = img.get_pixel_mut(x as u32, y as u32);
    let da = p.0[3] as f32 / 255.0;
    let oa = a + da * (1.0 - a);
    if oa <= 0.0 {
        return;
    }
    for i in 0..3 {
        let src = [c.0, c.1, c.2][i] as f32;
        p.0[i] = ((src * a + p.0[i] as f32 * da * (1.0 - a)) / oa).round() as u8;
    }
    p.0[3] = (oa * 255.0).round() as u8;
}

/// Pixels per mm, limited so that the longer side does not exceed `max_px`.
pub fn scale_for(dl: &DrawList, dpi: f32, max_px: u32) -> f32 {
    let s = dpi / 25.4;
    let longest = dl.w_mm.max(dl.h_mm) * s;
    if longest > max_px as f32 { max_px as f32 / dl.w_mm.max(dl.h_mm) } else { s }
}

fn px_rect(r: RectMm, s: f32) -> (i32, i32, i32, i32) {
    (
        (r.x * s).round() as i32,
        (r.y * s).round() as i32,
        ((r.x + r.w) * s).round() as i32,
        ((r.y + r.h) * s).round() as i32,
    )
}

pub fn rasterize(dl: &DrawList, dpi: f32, max_px: u32, cache: &mut ImageCache) -> RgbaImage {
    let s = scale_for(dl, dpi, max_px);
    let w = (dl.w_mm * s).round().max(1.0) as u32;
    let h = (dl.h_mm * s).round().max(1.0) as u32;
    let mut img = RgbaImage::from_pixel(w, h, image::Rgba([255, 255, 255, 255]));
    draw_cmds(&mut img, &dl.cmds, s, cache);
    img
}

fn draw_cmds(img: &mut RgbaImage, cmds: &[Cmd], s: f32, cache: &mut ImageCache) {
    let (w, h) = (img.width(), img.height());
    for cmd in cmds {
        match cmd {
            Cmd::Group { rot_deg, cx, cy, cmds: inner } => {
                // draw unrotated into a transparent layer, then resample it rotated
                let mut layer = RgbaImage::from_pixel(w, h, image::Rgba([0, 0, 0, 0]));
                draw_cmds(&mut layer, inner, s, cache);
                let (sn, cs) = rot_deg.to_radians().sin_cos();
                let (pcx, pcy) = (cx * s, cy * s);
                // bounding box of the rotated image area (conservative: whole image diagonal-bounded by content)
                let (mut minx, mut miny, mut maxx, mut maxy) = (w as i32, h as i32, 0i32, 0i32);
                for (x, y, p) in layer.enumerate_pixels() {
                    if p.0[3] > 0 {
                        minx = minx.min(x as i32);
                        miny = miny.min(y as i32);
                        maxx = maxx.max(x as i32);
                        maxy = maxy.max(y as i32);
                    }
                }
                if maxx < minx {
                    continue;
                }
                let corners = [(minx as f32, miny as f32), (maxx as f32 + 1.0, miny as f32), (minx as f32, maxy as f32 + 1.0), (maxx as f32 + 1.0, maxy as f32 + 1.0)];
                let rotp = |x: f32, y: f32| (pcx + (x - pcx) * cs - (y - pcy) * sn, pcy + (x - pcx) * sn + (y - pcy) * cs);
                let rc: Vec<(f32, f32)> = corners.iter().map(|c| rotp(c.0, c.1)).collect();
                let (bx0, bx1) = (rc.iter().map(|c| c.0).fold(f32::MAX, f32::min).floor().max(0.0) as i32, (rc.iter().map(|c| c.0).fold(f32::MIN, f32::max).ceil() as i32).min(w as i32 - 1));
                let (by0, by1) = (rc.iter().map(|c| c.1).fold(f32::MAX, f32::min).floor().max(0.0) as i32, (rc.iter().map(|c| c.1).fold(f32::MIN, f32::max).ceil() as i32).min(h as i32 - 1));
                for y in by0..=by1 {
                    for x in bx0..=bx1 {
                        // inverse rotation of the pixel centre
                        let (px, py) = (x as f32 + 0.5 - pcx, y as f32 + 0.5 - pcy);
                        let (sx, sy) = (pcx + px * cs + py * sn, pcy - px * sn + py * cs);
                        if sx < 0.0 || sy < 0.0 || sx >= w as f32 - 1.0 || sy >= h as f32 - 1.0 {
                            continue;
                        }
                        let (fx, fy) = (sx - 0.5, sy - 0.5);
                        let (ix, iy) = (fx.floor().max(0.0) as u32, fy.floor().max(0.0) as u32);
                        let (tx, ty) = ((fx - ix as f32).clamp(0.0, 1.0), (fy - iy as f32).clamp(0.0, 1.0));
                        let g = |xx: u32, yy: u32| layer.get_pixel(xx.min(w - 1), yy.min(h - 1)).0;
                        let (p00, p10, p01, p11) = (g(ix, iy), g(ix + 1, iy), g(ix, iy + 1), g(ix + 1, iy + 1));
                        let mut acc = [0f32; 4];
                        // premultiplied bilinear
                        for (pp, wgt) in [(p00, (1.0 - tx) * (1.0 - ty)), (p10, tx * (1.0 - ty)), (p01, (1.0 - tx) * ty), (p11, tx * ty)] {
                            let a = pp[3] as f32 / 255.0;
                            acc[0] += pp[0] as f32 * a * wgt;
                            acc[1] += pp[1] as f32 * a * wgt;
                            acc[2] += pp[2] as f32 * a * wgt;
                            acc[3] += a * wgt;
                        }
                        if acc[3] > 0.001 {
                            blend(img, x, y, Rgba((acc[0] / acc[3]) as u8, (acc[1] / acc[3]) as u8, (acc[2] / acc[3]) as u8, 255), acc[3]);
                        }
                    }
                }
            }
            Cmd::Rect { r, fill, stroke } => {
                let (x0, y0, x1, y1) = px_rect(*r, s);
                if let Some(c) = fill {
                    for y in y0.max(0)..y1.min(h as i32) {
                        for x in x0.max(0)..x1.min(w as i32) {
                            blend(img, x, y, *c, 1.0);
                        }
                    }
                }
                if let Some((c, wmm)) = stroke {
                    let t = ((wmm * s).round() as i32).max(1);
                    for y in y0..y1 {
                        for x in x0..x1 {
                            if x < x0 + t || x >= x1 - t || y < y0 + t || y >= y1 - t {
                                blend(img, x, y, *c, 1.0);
                            }
                        }
                    }
                }
            }
            Cmd::Gradient { r, from, to, vertical } => {
                let (x0, y0, x1, y1) = px_rect(*r, s);
                for y in y0.max(0)..y1.min(h as i32) {
                    for x in x0.max(0)..x1.min(w as i32) {
                        let t = if *vertical {
                            (y - y0) as f32 / (y1 - y0).max(1) as f32
                        } else {
                            (x - x0) as f32 / (x1 - x0).max(1) as f32
                        };
                        let m = |a: u8, b: u8| (a as f32 + (b as f32 - a as f32) * t) as u8;
                        blend(img, x, y, Rgba(m(from.0, to.0), m(from.1, to.1), m(from.2, to.2), m(from.3, to.3)), 1.0);
                    }
                }
            }
            Cmd::Ellipse { r, fill, stroke } => {
                let (x0, y0, x1, y1) = px_rect(*r, s);
                let (cx, cy) = ((x0 + x1) as f32 / 2.0, (y0 + y1) as f32 / 2.0);
                let (rx, ry) = ((x1 - x0) as f32 / 2.0, (y1 - y0) as f32 / 2.0);
                let t = stroke.map(|(_, wmm)| (wmm * s).max(1.0)).unwrap_or(0.0);
                for y in y0.max(0)..y1.min(h as i32) {
                    for x in x0.max(0)..x1.min(w as i32) {
                        let dx = (x as f32 + 0.5 - cx) / rx.max(0.5);
                        let dy = (y as f32 + 0.5 - cy) / ry.max(0.5);
                        let d = dx * dx + dy * dy;
                        if d <= 1.0 {
                            if let Some(c) = fill {
                                blend(img, x, y, *c, 1.0);
                            }
                            if let Some((c, _)) = stroke {
                                let inner = 1.0 - t / rx.min(ry).max(1.0);
                                if d >= inner * inner {
                                    blend(img, x, y, *c, 1.0);
                                }
                            }
                        }
                    }
                }
            }
            Cmd::Line { x0, y0, x1, y1, color, width_mm } => {
                let (ax, ay, bx, by) = (x0 * s, y0 * s, x1 * s, y1 * s);
                let half = ((width_mm * s) / 2.0).max(0.5);
                let (minx, maxx) = (ax.min(bx) - half - 1.0, ax.max(bx) + half + 1.0);
                let (miny, maxy) = (ay.min(by) - half - 1.0, ay.max(by) + half + 1.0);
                let (dx, dy) = (bx - ax, by - ay);
                let len2 = (dx * dx + dy * dy).max(1e-6);
                for y in (miny.floor() as i32)..=(maxy.ceil() as i32) {
                    for x in (minx.floor() as i32)..=(maxx.ceil() as i32) {
                        let (px, py) = (x as f32 + 0.5, y as f32 + 0.5);
                        let t = (((px - ax) * dx + (py - ay) * dy) / len2).clamp(0.0, 1.0);
                        let (qx, qy) = (ax + t * dx, ay + t * dy);
                        let d = ((px - qx).powi(2) + (py - qy).powi(2)).sqrt();
                        let cov = (half + 0.5 - d).clamp(0.0, 1.0);
                        blend(img, x, y, *color, cov);
                    }
                }
            }
            Cmd::Image { path, dest, crop, opacity, mask, fx } => {
                let Some(src) = cache.get(path) else { continue };
                let (x0, y0, x1, y1) = px_rect(*dest, s);
                let (dw, dh) = ((x1 - x0).max(1) as u32, (y1 - y0).max(1) as u32);
                let (sw, sh) = (src.width() as f32, src.height() as f32);
                let cx = (crop.0 * sw).round().clamp(0.0, sw - 1.0) as u32;
                let cy = (crop.1 * sh).round().clamp(0.0, sh - 1.0) as u32;
                let cw = (((crop.2 - crop.0) * sw).round() as u32).clamp(1, src.width() - cx);
                let ch = (((crop.3 - crop.1) * sh).round() as u32).clamp(1, src.height() - cy);
                let mut piece = src.crop_imm(cx, cy, cw, ch).resize_exact(dw, dh, image::imageops::FilterType::Triangle).to_rgba8();
                apply_fx(&mut piece, *fx);
                let cov = mask.as_ref().map(|rings| shapes::coverage(rings, s, x0, y0, dw, dh));
                for (x, y, p) in piece.enumerate_pixels() {
                    let m = cov.as_ref().map(|c| c[(y * dw + x) as usize] as f32 / 255.0).unwrap_or(1.0);
                    if m > 0.0 {
                        blend(img, x0 + x as i32, y0 + y as i32, Rgba(p.0[0], p.0[1], p.0[2], p.0[3]), *opacity * m);
                    }
                }
            }
            Cmd::Polygon { rings, fill } => {
                let bb = shapes::bbox(rings);
                let (x0, y0) = ((bb.x * s).floor() as i32 - 1, (bb.y * s).floor() as i32 - 1);
                let (bw, bh) = (((bb.w * s).ceil() as u32 + 3).min(20000), ((bb.h * s).ceil() as u32 + 3).min(20000));
                let cov = shapes::coverage(rings, s, x0, y0, bw, bh);
                for y in 0..bh {
                    for x in 0..bw {
                        let c = cov[(y * bw + x) as usize];
                        if c > 0 {
                            blend(img, x0 + x as i32, y0 + y as i32, *fill, c as f32 / 255.0);
                        }
                    }
                }
            }
            Cmd::Text { r, text, size_mm, bold, color, align, .. } => {
                let px = size_mm * s;
                if px < 1.0 {
                    continue;
                }
                let f = font::font(*bold);
                let sf = f.as_scaled(ab_glyph::PxScale::from(px));
                let tw = font::text_width(text, px, *bold);
                let x_start = match align {
                    Align::Left => r.x * s,
                    Align::Center => r.x * s + (r.w * s - tw) / 2.0,
                    Align::Right => (r.x + r.w) * s - tw,
                };
                let cy = (r.y + r.h / 2.0) * s;
                let baseline = cy + (sf.ascent() + sf.descent()) / 2.0;
                let mut x = x_start;
                let mut prev = None;
                for ch in text.chars() {
                    let id = sf.glyph_id(ch);
                    if let Some(p) = prev {
                        x += sf.kern(p, id);
                    }
                    let glyph = id.with_scale_and_position(ab_glyph::PxScale::from(px), ab_glyph::point(x, baseline));
                    if let Some(og) = f.outline_glyph(glyph) {
                        let b = og.px_bounds();
                        og.draw(|gx, gy, cov| {
                            blend(img, b.min.x as i32 + gx as i32, b.min.y as i32 + gy as i32, *color, cov);
                        });
                    }
                    x += sf.h_advance(id);
                    prev = Some(id);
                }
            }
        }
    }
}
