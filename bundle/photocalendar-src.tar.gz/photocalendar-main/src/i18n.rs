//! User-interface language (Hungarian / Romanian / English).
//! Source strings in the code are Hungarian; `t` looks the translation up in `i18n/dict.tsv`
//! (columns: hu, ro, en). Missing entries fall back to the Hungarian text.
use std::collections::HashMap;
use std::sync::OnceLock;
use std::sync::atomic::{AtomicU8, Ordering};

#[derive(Clone, Copy, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize, Default)]
pub enum UiLang {
    #[default]
    Hu,
    Ro,
    En,
}

impl UiLang {
    pub const ALL: [UiLang; 3] = [UiLang::Hu, UiLang::Ro, UiLang::En];
    pub fn label(self) -> &'static str {
        match self {
            UiLang::Hu => "Magyar",
            UiLang::Ro => "Română",
            UiLang::En => "English",
        }
    }
}

static CUR: AtomicU8 = AtomicU8::new(0);
static MAP: OnceLock<HashMap<&'static str, [&'static str; 2]>> = OnceLock::new();

pub fn set(l: UiLang) {
    CUR.store(l as u8, Ordering::Relaxed);
}

pub fn get() -> UiLang {
    match CUR.load(Ordering::Relaxed) {
        1 => UiLang::Ro,
        2 => UiLang::En,
        _ => UiLang::Hu,
    }
}

fn map() -> &'static HashMap<&'static str, [&'static str; 2]> {
    MAP.get_or_init(|| {
        let mut m = HashMap::new();
        for line in include_str!("../i18n/dict.tsv").lines() {
            let f: Vec<&str> = line.split('\t').collect();
            if f.len() == 3 {
                m.insert(f[0], [f[1], f[2]]);
            }
        }
        m
    })
}

/// Translates a (Hungarian) source string into the current UI language.
pub fn t(s: &'static str) -> &'static str {
    match get() {
        UiLang::Hu => s,
        l => map().get(s).map(|v| v[l as usize - 1]).unwrap_or(s),
    }
}

/// Same for strings that are not 'static (style names, saved names); unknown text is returned unchanged.
pub fn tr(s: &str) -> String {
    match get() {
        UiLang::Hu => s.to_string(),
        l => map().get(s).map(|v| v[l as usize - 1].to_string()).unwrap_or_else(|| s.to_string()),
    }
}

/// Translated template with `{}` placeholders filled in order.
pub fn tf(template: &'static str, args: &[String]) -> String {
    let mut out = String::new();
    let mut it = args.iter();
    let mut rest = t(template);
    while let Some(i) = rest.find("{}") {
        out.push_str(&rest[..i]);
        if let Some(a) = it.next() {
            out.push_str(a);
        }
        rest = &rest[i + 2..];
    }
    out.push_str(rest);
    out
}

#[macro_export]
macro_rules! tf {
    ($lit:literal $(, $a:expr)* $(,)?) => { $crate::i18n::tf($lit, &[$(format!("{}", $a)),*]) };
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn dict_wellformed() {
        for line in include_str!("../i18n/dict.tsv").lines() {
            let f: Vec<&str> = line.split('\t').collect();
            assert_eq!(f.len(), 3, "bad line: {line}");
            for t in &f[1..] {
                assert_eq!(f[0].matches("{}").count(), t.matches("{}").count(), "placeholder mismatch: {line}");
            }
        }
    }
    #[test]
    fn translate_and_format() {
        set(UiLang::En);
        assert_eq!(t("Fájl"), "File");
        assert_eq!(tf("Mentve: {}", &["x".into()]), "Saved: x");
        set(UiLang::Ro);
        assert_eq!(t("Fájl"), "Fișier");
        assert_eq!(t("ismeretlen"), "ismeretlen");
        set(UiLang::Hu);
    }
}
