//! Fonts: the built-in free fonts (SIL OFL 1.1, licences in `fonts/licenses/`), the fonts
//! installed on this computer, and text measuring. Every backend (screen, PNG, PDF) asks this
//! module for the same face, so what is measured is what is drawn.
//!
//! A text names its font by family ("Open Sans", "Arial"). When a family is not here, a free
//! font with the same metrics stands in (Arial → Liberation Sans, Times New Roman → Liberation
//! Serif, Calibri → Carlito, …), so a calendar keeps its layout on another computer.
use ab_glyph::{Font, FontRef, ScaleFont};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, OnceLock};

pub static REGULAR_TTF: &[u8] = include_bytes!("../assets/LiberationSans-Regular.ttf");
pub static BOLD_TTF: &[u8] = include_bytes!("../assets/LiberationSans-Bold.ttf");

/// The font used when nothing else is asked for or found.
pub const DEFAULT_FAMILY: &str = "Liberation Sans";

/// Same widths as the proprietary fonts people know, so text breaks the same way.
const SUBSTITUTES: &[(&str, &str)] = &[
    ("arial", "Liberation Sans"),
    ("helvetica", "Liberation Sans"),
    ("arimo", "Liberation Sans"),
    ("times new roman", "Liberation Serif"),
    ("times", "Liberation Serif"),
    ("tinos", "Liberation Serif"),
    ("courier new", "Liberation Mono"),
    ("courier", "Liberation Mono"),
    ("cousine", "Liberation Mono"),
    ("calibri", "Carlito"),
    ("cambria", "Caladea"),
    ("segoe ui", "Open Sans"),
    ("verdana", "Noto Sans"),
    ("tahoma", "Noto Sans"),
    ("georgia", "Noto Serif"),
    ("trebuchet ms", "Source Sans 3"),
];

/// A loaded face. The bytes live as long as the program (fonts are few and small).
pub struct Face {
    pub family: String,
    pub bold: bool,
    pub data: &'static [u8],
    pub font: FontRef<'static>,
    /// The licence lets the font be embedded in a PDF.
    pub embeddable: bool,
}

#[derive(Clone, Debug)]
struct Files {
    name: String,
    regular: Option<PathBuf>,
    bold: Option<PathBuf>,
    builtin: bool,
}

#[derive(Default)]
struct Registry {
    families: HashMap<String, Files>,
    system_scanned: bool,
    loaded: HashMap<(String, bool), &'static Face>,
}

fn registry() -> &'static Mutex<Registry> {
    static R: OnceLock<Mutex<Registry>> = OnceLock::new();
    R.get_or_init(|| {
        let mut r = Registry::default();
        for dir in builtin_dirs() {
            scan_dir(&mut r, &dir, true, 0);
        }
        Mutex::new(r)
    })
}

/// Where the built-in fonts are: `fonts/` beside the program, or the source tree when run from it.
fn builtin_dirs() -> Vec<PathBuf> {
    let mut v = Vec::new();
    if let Ok(d) = std::env::var("PHOTOCALENDAR_FONTS") {
        v.push(PathBuf::from(d));
    }
    if let Ok(exe) = std::env::current_exe() {
        if let Some(d) = exe.parent() {
            v.push(d.join("fonts"));
            v.push(d.join("../share/photocalendar/fonts"));
        }
    }
    v.push(PathBuf::from(concat!(env!("CARGO_MANIFEST_DIR"), "/assets/fonts")));
    v.into_iter().filter(|d| d.is_dir()).collect()
}

/// The folders fonts are installed in on this computer.
fn system_dirs() -> Vec<PathBuf> {
    let mut v = Vec::new();
    let home = std::env::var_os("HOME").or_else(|| std::env::var_os("USERPROFILE")).map(PathBuf::from);
    if cfg!(windows) {
        let win = std::env::var_os("WINDIR").map(PathBuf::from).unwrap_or_else(|| PathBuf::from("C:\\Windows"));
        v.push(win.join("Fonts"));
        if let Some(l) = std::env::var_os("LOCALAPPDATA") {
            v.push(PathBuf::from(l).join("Microsoft\\Windows\\Fonts"));
        }
    } else if cfg!(target_os = "macos") {
        v.push(PathBuf::from("/Library/Fonts"));
        v.push(PathBuf::from("/System/Library/Fonts"));
        if let Some(h) = &home {
            v.push(h.join("Library/Fonts"));
        }
    } else {
        v.push(PathBuf::from("/usr/share/fonts"));
        v.push(PathBuf::from("/usr/local/share/fonts"));
        if let Some(h) = &home {
            v.push(h.join(".local/share/fonts"));
            v.push(h.join(".fonts"));
        }
    }
    v.into_iter().filter(|d| d.is_dir()).collect()
}

/// Family name and whether it is bold / italic, from the font's own name table.
fn describe(data: &[u8]) -> Option<(String, bool, bool)> {
    let face = ttf_parser::Face::parse(data, 0).ok()?;
    let name = |id: u16| face.names().into_iter().filter(|n| n.name_id == id && n.is_unicode()).find_map(|n| n.to_string());
    let family = name(ttf_parser::name_id::TYPOGRAPHIC_FAMILY).or_else(|| name(ttf_parser::name_id::FAMILY))?;
    let weight = face.weight().to_number();
    Some((family, face.is_bold() || weight >= 600, face.is_italic() || face.is_oblique()))
}

fn scan_dir(r: &mut Registry, dir: &Path, builtin: bool, depth: u32) {
    let Ok(rd) = std::fs::read_dir(dir) else { return };
    for e in rd.flatten() {
        let p = e.path();
        if p.is_dir() {
            if depth < 4 {
                scan_dir(r, &p, builtin, depth + 1);
            }
            continue;
        }
        let ext = p.extension().map(|x| x.to_string_lossy().to_ascii_lowercase()).unwrap_or_default();
        if !matches!(ext.as_str(), "ttf" | "otf") {
            continue;
        }
        // huge CJK fonts are not worth reading
        if e.metadata().map(|m| m.len() > 30_000_000).unwrap_or(true) {
            continue;
        }
        let Ok(data) = std::fs::read(&p) else { continue };
        let Some((family, bold, italic)) = describe(&data) else { continue };
        if italic {
            continue;
        }
        let entry = r.families.entry(family.to_lowercase()).or_insert_with(|| Files { name: family.clone(), regular: None, bold: None, builtin });
        // built-in files win over installed ones of the same family
        if entry.builtin && !builtin {
            continue;
        }
        let slot = if bold { &mut entry.bold } else { &mut entry.regular };
        // prefer the plain weights ("Regular", "Bold") over Light/Medium/Black
        let stem = p.file_stem().map(|s| s.to_string_lossy().to_lowercase()).unwrap_or_default();
        let plain = stem.ends_with("-regular") || stem.ends_with("-bold") || stem.ends_with("bd") || !stem.contains('-');
        if slot.is_none() || plain {
            *slot = Some(p);
        }
    }
}

fn ensure_system(r: &mut Registry) {
    if !r.system_scanned {
        r.system_scanned = true;
        for d in system_dirs() {
            scan_dir(r, &d, false, 0);
        }
    }
}

/// The family that will really be used for `family`, and whether it is a stand-in.
pub fn resolve(family: &str) -> (String, bool) {
    let want = family.trim();
    if want.is_empty() || want.eq_ignore_ascii_case(DEFAULT_FAMILY) {
        return (DEFAULT_FAMILY.into(), false);
    }
    let mut r = registry().lock().unwrap_or_else(|e| e.into_inner());
    let key = want.to_lowercase();
    if !r.families.contains_key(&key) {
        ensure_system(&mut r);
    }
    if let Some(f) = r.families.get(&key) {
        if f.regular.is_some() || f.bold.is_some() {
            return (f.name.clone(), false);
        }
    }
    let sub = SUBSTITUTES.iter().find(|(k, _)| *k == key).map(|(_, v)| *v).unwrap_or(DEFAULT_FAMILY);
    if sub == DEFAULT_FAMILY || r.families.contains_key(&sub.to_lowercase()) {
        (sub.into(), true)
    } else {
        (DEFAULT_FAMILY.into(), true)
    }
}

/// The face for a family and weight (a family without a bold face uses its regular one).
pub fn face(family: &str, bold: bool) -> &'static Face {
    let (fam, _) = resolve(family);
    if fam == DEFAULT_FAMILY {
        return builtin_default(bold);
    }
    let mut r = registry().lock().unwrap_or_else(|e| e.into_inner());
    let key = (fam.to_lowercase(), bold);
    if let Some(f) = r.loaded.get(&key) {
        return f;
    }
    let path = r.families.get(&key.0).and_then(|f| if bold { f.bold.clone().or_else(|| f.regular.clone()) } else { f.regular.clone().or_else(|| f.bold.clone()) });
    let loaded: Option<&'static Face> = path.and_then(|p| std::fs::read(p).ok()).and_then(|data| {
        let data: &'static [u8] = Box::leak(data.into_boxed_slice());
        let font = FontRef::try_from_slice(data).ok()?;
        let embeddable = ttf_parser::Face::parse(data, 0).map(|f| !matches!(f.permissions(), Some(ttf_parser::Permissions::Restricted))).unwrap_or(false);
        Some(&*Box::leak(Box::new(Face { family: fam.clone(), bold, data, font, embeddable })))
    });
    let face = loaded.unwrap_or_else(|| builtin_default(bold));
    r.loaded.insert(key, face);
    face
}

fn builtin_default(bold: bool) -> &'static Face {
    static R: OnceLock<Face> = OnceLock::new();
    static B: OnceLock<Face> = OnceLock::new();
    let mk = |data: &'static [u8], bold: bool| Face { family: DEFAULT_FAMILY.into(), bold, data, font: FontRef::try_from_slice(data).expect("built-in font"), embeddable: true };
    if bold { B.get_or_init(|| mk(BOLD_TTF, true)) } else { R.get_or_init(|| mk(REGULAR_TTF, false)) }
}

/// The face a PDF can embed: the font itself, or (when its licence forbids it) its stand-in.
pub fn pdf_face(family: &str, bold: bool) -> &'static Face {
    let f = face(family, bold);
    if f.embeddable {
        return f;
    }
    let sub = SUBSTITUTES.iter().find(|(k, _)| *k == f.family.to_lowercase()).map(|(_, v)| *v).unwrap_or(DEFAULT_FAMILY);
    face(sub, bold)
}

/// The fonts to offer: built-in families, then the ones installed on this computer.
pub fn families() -> (Vec<String>, Vec<String>) {
    let mut r = registry().lock().unwrap_or_else(|e| e.into_inner());
    ensure_system(&mut r);
    let mut builtin: Vec<String> = r.families.values().filter(|f| f.builtin && f.regular.is_some()).map(|f| f.name.clone()).collect();
    let mut system: Vec<String> = r.families.values().filter(|f| !f.builtin && f.regular.is_some()).map(|f| f.name.clone()).collect();
    if !builtin.iter().any(|f| f == DEFAULT_FAMILY) {
        builtin.push(DEFAULT_FAMILY.into());
    }
    builtin.sort_by_key(|s| s.to_lowercase());
    system.sort_by_key(|s| s.to_lowercase());
    (builtin, system)
}

/// The default face (kept for callers that do not name a family).
pub fn font(bold_face: bool) -> &'static FontRef<'static> {
    &face("", bold_face).font
}

/// Width of `text` in the same unit as `size` (em size).
pub fn text_width(text: &str, size: f32, bold_face: bool, family: &str) -> f32 {
    let f = &face(family, bold_face).font;
    let sf = f.as_scaled(ab_glyph::PxScale::from(size));
    let mut w = 0.0;
    let mut prev = None;
    for ch in text.chars() {
        let id = sf.glyph_id(ch);
        if let Some(p) = prev {
            w += sf.kern(p, id);
        }
        w += sf.h_advance(id);
        prev = Some(id);
    }
    w
}

/// Shrink `size` so that `text` fits `max_w` (same units).
pub fn fit_size(text: &str, size: f32, max_w: f32, bold_face: bool, family: &str) -> f32 {
    let w = text_width(text, size, bold_face, family);
    if w > max_w && w > 0.0 { size * max_w / w } else { size }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn built_in_fonts_and_stand_ins() {
        assert_eq!(resolve("").0, DEFAULT_FAMILY);
        let (f, sub) = resolve("Nincs Ilyen Betű 123");
        assert!(sub);
        assert_eq!(f, DEFAULT_FAMILY);
        let (b, _) = families();
        for fam in ["Open Sans", "Liberation Serif", "Carlito", "Great Vibes"] {
            assert!(b.iter().any(|x| x == fam), "{fam} missing from {b:?}");
        }
        assert_eq!(face("Open Sans", true).family, "Open Sans");
        let (a, sub) = resolve("Arial");
        assert!(a == "Arial" || (sub && a == "Liberation Sans"), "{a}");
        let (t, _) = resolve("Times New Roman");
        assert!(t == "Times New Roman" || t == "Liberation Serif", "{t}");
        let w1 = text_width("Március 2027", 10.0, false, "Open Sans");
        let w2 = text_width("Március 2027", 10.0, false, "Oswald");
        assert!((w1 - w2).abs() > 0.5);
        assert!(text_width("őűșț", 10.0, false, "Lato") > 0.0);
    }
}
