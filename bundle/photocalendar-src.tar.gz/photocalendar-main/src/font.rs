//! Embedded fonts (Liberation Sans, SIL OFL 1.1 – licence in assets/) and text measuring.
use ab_glyph::{Font, FontRef, ScaleFont};
use std::sync::OnceLock;

pub static REGULAR_TTF: &[u8] = include_bytes!("../assets/LiberationSans-Regular.ttf");
pub static BOLD_TTF: &[u8] = include_bytes!("../assets/LiberationSans-Bold.ttf");

fn regular() -> &'static FontRef<'static> {
    static F: OnceLock<FontRef<'static>> = OnceLock::new();
    F.get_or_init(|| FontRef::try_from_slice(REGULAR_TTF).expect("regular font"))
}
fn bold() -> &'static FontRef<'static> {
    static F: OnceLock<FontRef<'static>> = OnceLock::new();
    F.get_or_init(|| FontRef::try_from_slice(BOLD_TTF).expect("bold font"))
}

pub fn font(bold_face: bool) -> &'static FontRef<'static> {
    if bold_face { bold() } else { regular() }
}

/// Width of `text` in the same unit as `size` (em size).
pub fn text_width(text: &str, size: f32, bold_face: bool) -> f32 {
    let f = font(bold_face);
    let sf = f.as_scaled(ab_glyph::PxScale::from(size));
    let mut w = 0.0;
    let mut prev = None;
    for ch in text.chars() {
        let id = sf.glyph_id(ch);
        if let Some(p) = prev {
            w += sf.kern(p, id);
        }
        w += sf.h_advance(id);
        prev = Some(id);
    }
    w
}

/// Shrink `size` so that `text` fits `max_w` (same units).
pub fn fit_size(text: &str, size: f32, max_w: f32, bold_face: bool) -> f32 {
    let w = text_width(text, size, bold_face);
    if w > max_w && w > 0.0 { size * max_w / w } else { size }
}
