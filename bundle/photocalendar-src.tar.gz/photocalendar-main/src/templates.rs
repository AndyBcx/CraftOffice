//! Built-in page templates (original designs). They only produce ordinary layers and
//! backgrounds, so after applying one everything can still be edited, and any page can be
//! saved as a user template.
use crate::clipart;
use crate::generate::{r, title_pt};
use crate::model::*;

pub fn names() -> Vec<&'static str> {
    vec!["Klasszikus", "Teljes fotó", "Keretes", "Kör alakú fotó", "Szív (Valentin)", "Kollázs (3 fotó)", "Minimál", "Gyerek", "Karácsony", "Tavasz"]
}

fn photo_idx(pg: &Page) -> Option<usize> {
    pg.layers.iter().position(|l| matches!(l.kind, LayerKind::Photo(_)))
}

fn title_idx(pg: &Page) -> Option<usize> {
    pg.layers.iter().position(|l| matches!(l.kind, LayerKind::Text(_)))
}

fn grid_idx(pg: &Page) -> Option<usize> {
    pg.layers.iter().position(|l| matches!(l.kind, LayerKind::Grid(_)))
}

fn set_title(pg: &mut Page, color: Rgba, shadow: bool) {
    if let Some(i) = title_idx(pg) {
        if let LayerKind::Text(t) = &mut pg.layers[i].kind {
            t.color = color;
            t.fill = Fill::Color(color);
            t.drop_shadow = shadow;
        }
    }
}

fn set_photo(pg: &mut Page, f: impl FnOnce(&mut PhotoLayer, &mut RectMm)) {
    if let Some(i) = photo_idx(pg) {
        let l = &mut pg.layers[i];
        if let LayerKind::Photo(p) = &mut l.kind {
            f(p, &mut l.rect);
        }
    }
}

fn set_grid_bg(pg: &mut Page, bg: Fill) {
    if let Some(i) = grid_idx(pg) {
        if let LayerKind::Grid(g) = &mut pg.layers[i].kind {
            g.style.background = bg;
        }
    }
}

fn deco(pg: &mut Page, name: &str, rect: RectMm) {
    pg.layers.extend(clipart::instantiate(name, rect));
}

fn square_in(rc: RectMm) -> RectMm {
    let d = rc.w.min(rc.h);
    RectMm { x: rc.x + (rc.w - d) / 2.0, y: rc.y + (rc.h - d) / 2.0, w: d, h: d }
}

fn rect_shape(name: &str, rc: RectMm, kind: ShapeKind, c: Rgba) -> Layer {
    layer(name, rc, LayerKind::Shape(ShapeLayer { kind, fill: Fill::Color(c), outline: None, opacity: 1.0, drop_shadow: false }))
}

/// Builds template number `idx` (see [`names`]) for a page of `w` x `h` mm and month `ym`.
pub fn build(idx: usize, w: f32, h: f32, ym: Option<(i32, u32)>) -> Page {
    let (y, m) = ym.unwrap_or((2000, 1));
    let mut pg = default_month_page(w, h, y, m);
    pg.month = ym;
    let mn = w.min(h);
    let marg = mn * 0.05;
    let c = |r: u8, g: u8, b: u8| Rgba(r, g, b, 255);
    match idx {
        1 => {
            // full-bleed photo, translucent grid panel
            let landscape = w >= h;
            set_photo(&mut pg, |_, rc| *rc = r(0.0, 0.0, w, h));
            let (title, grid) = if landscape {
                (r(w * 0.52, marg, w * 0.45, h * 0.1), r(w * 0.52, marg + h * 0.12, w * 0.45, h - 2.0 * marg - h * 0.12))
            } else {
                (r(marg, h * 0.46, w - 2.0 * marg, h * 0.07), r(marg, h * 0.54, w - 2.0 * marg, h * 0.43))
            };
            if let Some(i) = title_idx(&pg) {
                pg.layers[i].rect = title;
                if let LayerKind::Text(t) = &mut pg.layers[i].kind {
                    t.font_size_pt = title_pt(title.h);
                }
            }
            if let Some(i) = grid_idx(&pg) {
                pg.layers[i].rect = grid;
            }
            // panel behind title+grid
            let panel = RectMm { x: title.x - marg * 0.4, y: title.y - marg * 0.4, w: title.w + marg * 0.8, h: grid.y + grid.h - title.y + marg * 0.8 };
            let pi = 1;
            pg.layers.insert(pi, rect_shape("Panel", panel, ShapeKind::RoundedRect, Rgba(255, 255, 255, 150)));
            set_grid_bg(&mut pg, Fill::None);
        }
        2 => {
            pg.background = Background::Gradient { top: c(255, 246, 232), bottom: c(250, 224, 196) };
            set_photo(&mut pg, |p, _| {
                p.frame_mm = mn * 0.018;
                p.frame_color = Rgba::WHITE;
                p.drop_shadow = true;
            });
            set_title(&mut pg, c(120, 60, 30), false);
            set_grid_bg(&mut pg, Fill::Color(Rgba(255, 255, 255, 215)));
        }
        3 => {
            pg.background = Background::Gradient { top: c(235, 245, 255), bottom: c(205, 225, 245) };
            let mut sq = RectMm { x: 0.0, y: 0.0, w: 0.0, h: 0.0 };
            set_photo(&mut pg, |p, rc| {
                sq = square_in(*rc);
                *rc = sq;
                p.mask = Some(ShapeKind::Circle);
                p.frame_mm = mn * 0.012;
                p.frame_color = Rgba::WHITE;
                p.drop_shadow = true;
            });
            let big = RectMm { x: sq.x - sq.w * 0.04, y: sq.y - sq.h * 0.04, w: sq.w * 1.08, h: sq.h * 1.08 };
            pg.layers.insert(0, rect_shape("Gyűrű", big, ShapeKind::Ring, Rgba(150, 190, 230, 255)));
            set_title(&mut pg, c(40, 70, 110), false);
        }
        4 => {
            pg.background = Background::Gradient { top: c(255, 235, 240), bottom: c(250, 200, 215) };
            set_photo(&mut pg, |p, _| {
                p.mask = Some(ShapeKind::Heart);
                p.frame_mm = mn * 0.01;
                p.frame_color = Rgba::WHITE;
                p.drop_shadow = true;
            });
            set_title(&mut pg, c(170, 20, 60), false);
            set_grid_bg(&mut pg, Fill::Color(Rgba(255, 255, 255, 220)));
        }
        5 => {
            if let Some(i) = photo_idx(&pg) {
                let base = pg.layers[i].rect;
                let gap = marg * 0.4;
                let big = r(base.x, base.y, base.w * 0.62 - gap / 2.0, base.h);
                let sw = base.w * 0.38 - gap / 2.0;
                let (s1, s2) = (r(base.x + big.w + gap, base.y, sw, (base.h - gap) / 2.0), r(base.x + big.w + gap, base.y + (base.h + gap) / 2.0, sw, (base.h - gap) / 2.0));
                pg.layers[i].rect = big;
                let mut extra = vec![];
                for (k, rc) in [s1, s2].into_iter().enumerate() {
                    let mut l = pg.layers[i].clone();
                    l.rect = rc;
                    l.name = format!("Fotó {}", k + 2);
                    extra.push(l);
                }
                for (k, l) in extra.into_iter().enumerate() {
                    pg.layers.insert(i + 1 + k, l);
                }
                for l in pg.layers.iter_mut() {
                    if let LayerKind::Photo(p) = &mut l.kind {
                        p.frame_mm = mn * 0.006;
                        p.frame_color = Rgba::WHITE;
                    }
                }
            }
        }
        6 => {
            let landscape = w >= h;
            set_photo(&mut pg, |_, rc| {
                if landscape {
                    *rc = r(marg, marg, w - 2.0 * marg, h * 0.3);
                } else {
                    *rc = r(marg, marg, w - 2.0 * marg, h * 0.26);
                }
            });
            let top = marg + if landscape { h * 0.3 } else { h * 0.26 } + marg * 0.6;
            if let Some(i) = title_idx(&pg) {
                pg.layers[i].rect = r(marg, top, w - 2.0 * marg, h * 0.08);
                if let LayerKind::Text(t) = &mut pg.layers[i].kind {
                    t.align = Align::Left;
                    t.font_size_pt = title_pt(h * 0.08);
                }
            }
            if let Some(i) = grid_idx(&pg) {
                let gt = top + h * 0.09;
                pg.layers[i].rect = r(marg, gt, w - 2.0 * marg, h - marg - gt);
            }
            set_grid_bg(&mut pg, Fill::None);
        }
        7 => {
            pg.background = Background::Gradient { top: c(255, 250, 215), bottom: c(255, 235, 180) };
            set_photo(&mut pg, |p, _| {
                p.mask = Some(ShapeKind::RoundedRect);
                p.frame_mm = mn * 0.012;
                p.frame_color = c(255, 150, 60);
            });
            set_title(&mut pg, c(220, 90, 30), false);
            set_grid_bg(&mut pg, Fill::Color(Rgba(255, 255, 255, 220)));
            let s = mn * 0.16;
            deco(&mut pg, "Napocska", r(w - s - marg * 0.3, marg * 0.2, s, s));
            deco(&mut pg, "Felhő", r(marg * 0.2, marg * 0.2, s * 1.1, s * 0.7));
            deco(&mut pg, "Virág", r(w - s * 0.9 - marg, h - s * 0.9 - marg * 0.5, s * 0.8, s * 0.8));
        }
        8 => {
            pg.background = Background::Gradient { top: c(150, 20, 35), bottom: c(95, 10, 25) };
            set_photo(&mut pg, |p, _| {
                p.frame_mm = mn * 0.012;
                p.frame_color = Rgba::WHITE;
            });
            set_title(&mut pg, Rgba::WHITE, true);
            set_grid_bg(&mut pg, Fill::Color(Rgba(255, 255, 255, 235)));
            let s = mn * 0.17;
            deco(&mut pg, "Fenyőfa", r(marg * 0.3, h - s * 1.2 - marg * 0.3, s * 0.9, s * 1.2));
            deco(&mut pg, "Hóember", r(w - s * 0.9 - marg * 0.3, h - s * 1.2 - marg * 0.3, s * 0.9, s * 1.2));
            deco(&mut pg, "Hópehely", r(w - s - marg * 0.3, marg * 0.2, s * 0.8, s * 0.8));
            deco(&mut pg, "Hópehely", r(marg * 0.3, marg * 0.2, s * 0.6, s * 0.6));
        }
        9 => {
            pg.background = Background::Gradient { top: c(235, 250, 225), bottom: c(205, 235, 190) };
            set_photo(&mut pg, |p, _| {
                p.mask = Some(ShapeKind::RoundedRect);
                p.frame_mm = mn * 0.012;
                p.frame_color = Rgba::WHITE;
                p.drop_shadow = true;
            });
            set_title(&mut pg, c(40, 110, 50), false);
            set_grid_bg(&mut pg, Fill::Color(Rgba(255, 255, 255, 215)));
            let s = mn * 0.15;
            deco(&mut pg, "Virág", r(marg * 0.2, marg * 0.1, s, s));
            deco(&mut pg, "Pillangó", r(w - s * 1.1 - marg * 0.2, marg * 0.1, s, s));
            deco(&mut pg, "Levél", r(w - s * 1.1 - marg, h - s * 0.8 - marg * 0.3, s, s * 0.7));
            deco(&mut pg, "Virág", r(marg * 0.5, h - s - marg * 0.3, s * 0.8, s * 0.8));
        }
        _ => {}
    }
    pg
}
