pub mod cal;
pub mod clipart;
pub mod templates;
pub mod config;
pub mod draw;
pub mod photo;
pub mod styles;
pub mod export;
pub mod generate;
pub mod font;
pub mod holidays;
pub mod layout;
pub mod raster;
pub mod shapes;
pub mod model;
pub mod pdf;
pub mod gui;
pub mod i18n;
pub mod platform;
pub mod gui_dialogs;
pub mod gui_props;
pub mod gui_util;

#[cfg(target_os = "android")]
#[unsafe(no_mangle)]
fn android_main(app: android_activity::AndroidApp) {
    let _ = gui::run_android(app);
}
