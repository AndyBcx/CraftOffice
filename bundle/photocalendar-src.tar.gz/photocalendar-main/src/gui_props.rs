//! Property panel (right side): page background and the selected layer.
use crate::gui::App;
use crate::gui_util::*;
use crate::model::*;
use eframe::egui;

impl App {
    pub(crate) fn props(&mut self, ui: &mut egui::Ui) {
        let (pw, ph) = self.page_dims();
        let inch = self.cfg.inch;
        let cur = self.cur;
        let mut changed = false;
        let mut auto_photo = false;
        let mut save_style: Option<GridStyle> = None;
        let mut pick_style: Option<GridStyle> = None;
        {
            let page = &mut self.proj.pages[cur];
            ui.heading(crate::i18n::t("Oldal"));
            let mut kind = match page.background {
                Background::Color(_) => 0,
                Background::Gradient { .. } => 1,
                Background::Image { .. } => 2,
            };
            let k0 = kind;
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Háttér:"));
                ui.selectable_value(&mut kind, 0, crate::i18n::t("Szín"));
                ui.selectable_value(&mut kind, 1, crate::i18n::t("Átmenet"));
                ui.selectable_value(&mut kind, 2, crate::i18n::t("Kép"));
            });
            if kind != k0 {
                page.background = match kind {
                    0 => Background::Color(Rgba::WHITE),
                    1 => Background::Gradient { top: Rgba::WHITE, bottom: Rgba(200, 210, 230, 255) },
                    _ => Background::Image { path: String::new(), lighten: false, fit: BgFit::Fill },
                };
                changed = true;
            }
            match &mut page.background {
                Background::Color(c) => changed |= rgba_edit(ui, c),
                Background::Gradient { top, bottom } => {
                    ui.horizontal(|ui| {
                        changed |= rgba_edit(ui, top);
                        changed |= rgba_edit(ui, bottom);
                    });
                }
                Background::Image { path, lighten, fit } => {
                    if ui.button(crate::i18n::t("Háttérkép…")).clicked() {
                        if let Some(f) = pick_image() {
                            *path = f;
                            changed = true;
                        }
                    }
                    ui.horizontal(|ui| {
                        changed |= ui.selectable_value(fit, BgFit::Fill, crate::i18n::t("Kitöltés")).changed();
                        changed |= ui.selectable_value(fit, BgFit::Fit, crate::i18n::t("Illesztés")).changed();
                        changed |= ui.selectable_value(fit, BgFit::Stretch, crate::i18n::t("Nyújtás")).changed();
                    });
                    changed |= ui.checkbox(lighten, crate::i18n::t("Háttér világosítása")).changed();
                }
            }
            if let Some((y, m)) = page.month {
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Fotó naphoz:"));
                    ui.add(egui::DragValue::new(&mut self.day_pick).range(1..=crate::cal::days_in_month(y, m)));
                    if ui.button(crate::i18n::t("Kép…")).clicked() {
                        if let Some(f) = pick_image() {
                            self.proj.day_photos.retain(|d| !(d.year == y && d.month == m && d.day == self.day_pick));
                            self.proj.day_photos.push(DayPhoto { year: y, month: m, day: self.day_pick, path: f });
                            changed = true;
                        }
                    }
                    if ui.small_button(crate::i18n::t("Törlés")).clicked() {
                        let dp = self.day_pick;
                        self.proj.day_photos.retain(|d| !(d.year == y && d.month == m && d.day == dp));
                        changed = true;
                    }
                });
            }
        }
        ui.separator();
        let Some(si) = self.sel else {
            ui.label(crate::i18n::t("Válassz ki egy réteget az oldalon vagy a listában."));
            if changed {
                self.touch();
            }
            return;
        };
        let cell_idx = &mut self.cell_idx;
        let (cfg_styles, style_cat, style_name) = (&self.cfg.styles, &mut self.style_cat, &mut self.style_name);
        let Some(l) = self.proj.pages[cur].layers.get_mut(si) else { return };
        ui.heading(crate::i18n::t("Réteg"));
        changed |= ui.text_edit_singleline(&mut l.name).changed();
        egui::Grid::new("rect").num_columns(4).show(ui, |ui| {
            ui.label("X");
            changed |= len_edit(ui, &mut l.rect.x, inch, -pw..=pw * 2.0);
            ui.label("Y");
            changed |= len_edit(ui, &mut l.rect.y, inch, -ph..=ph * 2.0);
            ui.end_row();
            ui.label("Sz");
            changed |= len_edit(ui, &mut l.rect.w, inch, 1.0..=pw * 3.0);
            ui.label("M");
            changed |= len_edit(ui, &mut l.rect.h, inch, 1.0..=ph * 3.0);
            ui.end_row();
        });
        ui.horizontal(|ui| {
            ui.label(crate::i18n::t("Forgatás"));
            changed |= ui.add(egui::DragValue::new(&mut l.rotation_deg).speed(0.5).range(-360.0..=360.0).suffix("°")).changed();
            if ui.small_button("0°").clicked() {
                l.rotation_deg = 0.0;
                changed = true;
            }
        });
        ui.separator();
        let rect = l.rect;
        match &mut l.kind {
            LayerKind::Photo(p) => {
                ui.heading(crate::i18n::t("Fotó"));
                ui.horizontal(|ui| {
                    if ui.button(crate::i18n::t("Csere…")).clicked() {
                        if let Some(f) = pick_image() {
                            p.path = Some(f);
                            changed = true;
                        }
                    }
                    if p.path.is_some() && ui.button(crate::i18n::t("Eltávolítás")).clicked() {
                        p.path = None;
                        changed = true;
                    }
                    if p.path.is_some() && ui.button(crate::i18n::t("Autokivágás")).clicked() {
                        auto_photo = true;
                    }
                });
                changed |= ui.add(egui::Slider::new(&mut p.zoom, 1.0..=5.0).text(crate::i18n::t("Nagyítás"))).changed();
                changed |= ui.add(egui::Slider::new(&mut p.pan_x, -1.0..=1.0).text(crate::i18n::t("Eltolás X"))).changed();
                changed |= ui.add(egui::Slider::new(&mut p.pan_y, -1.0..=1.0).text(crate::i18n::t("Eltolás Y"))).changed();
                ui.small(crate::i18n::t("Egérrel: Nézet fölött „Fotó igazítása egérrel”, görgő = nagyítás."));
                changed |= ui.add(egui::Slider::new(&mut p.opacity, 0.0..=1.0).text(crate::i18n::t("Átlátszatlanság"))).changed();
                ui.separator();
                changed |= ui.add(egui::Slider::new(&mut p.brightness, -1.0..=1.0).text(crate::i18n::t("Fényerő"))).changed();
                changed |= ui.add(egui::Slider::new(&mut p.contrast, -1.0..=1.0).text(crate::i18n::t("Kontraszt"))).changed();
                changed |= ui.add(egui::Slider::new(&mut p.saturation, -1.0..=1.0).text(crate::i18n::t("Telítettség"))).changed();
                if ui.button(crate::i18n::t("Effektek visszaállítása")).clicked() {
                    p.brightness = 0.0;
                    p.contrast = 0.0;
                    p.saturation = 0.0;
                    changed = true;
                }
                ui.separator();
                egui::ComboBox::from_id_salt("mask").selected_text(p.mask.map(shape_name).unwrap_or("Maszk: nincs")).show_ui(ui, |ui| {
                    changed |= ui.selectable_value(&mut p.mask, None, crate::i18n::t("Nincs (téglalap)")).changed();
                    for k in MASKS {
                        changed |= ui.selectable_value(&mut p.mask, Some(k), shape_name(k)).changed();
                    }
                });
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Keret"));
                    changed |= ui.add(egui::DragValue::new(&mut p.frame_mm).speed(0.1).range(0.0..=30.0).suffix(" mm")).changed();
                    changed |= rgba_edit(ui, &mut p.frame_color);
                });
                changed |= outline_edit(ui, &mut p.outline);
                changed |= ui.checkbox(&mut p.drop_shadow, crate::i18n::t("Vetett árnyék")).changed();
            }
            LayerKind::Text(t) => {
                ui.heading(crate::i18n::t("Szöveg"));
                changed |= ui.text_edit_multiline(&mut t.text).changed();
                ui.horizontal(|ui| {
                    if ui.small_button("+ Év").clicked() {
                        t.text.push_str("{year}");
                        changed = true;
                    }
                    if ui.small_button(crate::i18n::t("+ Hónap")).clicked() {
                        t.text.push_str("{month}");
                        changed = true;
                    }
                    if ui.small_button(crate::i18n::t("+ Hónap Év")).clicked() {
                        t.text.push_str("{month_year}");
                        changed = true;
                    }
                });
                changed |= ui.add(egui::DragValue::new(&mut t.font_size_pt).speed(0.5).range(4.0..=400.0).suffix(" pt")).changed();
                ui.horizontal(|ui| {
                    changed |= ui.checkbox(&mut t.bold, crate::i18n::t("Félkövér")).changed();
                    changed |= ui.checkbox(&mut t.italic, crate::i18n::t("Dőlt")).changed();
                });
                changed |= align_edit(ui, &mut t.align);
                let c0 = t.fill.clone();
                if fill_edit(ui, crate::i18n::t("Kitöltés"), &mut t.fill) {
                    if let Fill::Color(c) = &t.fill {
                        t.color = *c;
                    }
                    changed = true;
                }
                let _ = c0;
                changed |= outline_edit(ui, &mut t.outline);
                changed |= ui.checkbox(&mut t.drop_shadow, crate::i18n::t("Vetett árnyék")).changed();
                changed |= ui.add(egui::Slider::new(&mut t.opacity, 0.0..=1.0).text(crate::i18n::t("Átlátszatlanság"))).changed();
            }
            LayerKind::Image { path, opacity } => {
                ui.heading(crate::i18n::t("Kép"));
                ui.label(path.as_str());
                if ui.button(crate::i18n::t("Csere…")).clicked() {
                    if let Some(f) = pick_image() {
                        *path = f;
                        changed = true;
                    }
                }
                changed |= ui.add(egui::Slider::new(opacity, 0.0..=1.0).text(crate::i18n::t("Átlátszatlanság"))).changed();
            }
            LayerKind::Shape(s) => {
                ui.heading(crate::i18n::t("Alakzat / clipart"));
                egui::ComboBox::from_id_salt("shape").selected_text(shape_name(s.kind)).show_ui(ui, |ui| {
                    for k in SHAPES {
                        changed |= ui.selectable_value(&mut s.kind, k, shape_name(k)).changed();
                    }
                });
                changed |= fill_edit(ui, crate::i18n::t("Kitöltés"), &mut s.fill);
                changed |= outline_edit(ui, &mut s.outline);
                changed |= ui.add(egui::Slider::new(&mut s.opacity, 0.0..=1.0).text(crate::i18n::t("Átlátszatlanság"))).changed();
                changed |= ui.checkbox(&mut s.drop_shadow, crate::i18n::t("Vetett árnyék")).changed();
            }
            LayerKind::Holes { count, diameter_mm, vertical, color } => {
                ui.heading(crate::i18n::t("Kötés (lyukak)"));
                let mut c = *count as i32;
                changed |= ui.add(egui::DragValue::new(&mut c).range(1..=200).prefix(crate::i18n::t("Darab "))).changed();
                *count = c as u32;
                changed |= ui.add(egui::DragValue::new(diameter_mm).speed(0.1).range(0.5..=15.0).suffix(" mm")).changed();
                changed |= ui.checkbox(vertical, crate::i18n::t("Függőleges")).changed();
                changed |= rgba_edit(ui, color);
            }
            LayerKind::Grid(g) => {
                ui.heading(crate::i18n::t("Naptárrács"));
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Hónap:"));
                    let mut fixed = g.fixed_month.is_some();
                    if ui.checkbox(&mut fixed, crate::i18n::t("rögzített")).changed() {
                        g.fixed_month = if fixed { Some((2000, 1)) } else { None };
                        changed = true;
                    }
                    if let Some((y, m)) = &mut g.fixed_month {
                        changed |= ui.add(egui::DragValue::new(y).range(1900..=2099)).changed();
                        changed |= ui.add(egui::DragValue::new(m).range(1..=12)).changed();
                    }
                });
                // style library
                ui.separator();
                ui.label(crate::i18n::t("Hónapstílus:"));
                let builtin = crate::styles::builtin();
                egui::ComboBox::from_id_salt("stylepick").selected_text(crate::i18n::t("Stílus választása…")).show_ui(ui, |ui| {
                    for cat in crate::styles::CATEGORIES {
                        let any = builtin.iter().chain(cfg_styles.iter()).any(|s| s.category == cat);
                        if !any {
                            continue;
                        }
                        ui.label(egui::RichText::new(crate::i18n::t(cat)).strong());
                        for s in builtin.iter().chain(cfg_styles.iter()).filter(|s| s.category == cat) {
                            if ui.selectable_label(false, format!("  {}", crate::i18n::tr(&s.name))).clicked() {
                                pick_style = Some(s.style.clone());
                            }
                        }
                    }
                });
                ui.horizontal(|ui| {
                    egui::ComboBox::from_id_salt("stylecat").selected_text(crate::i18n::t(crate::styles::CATEGORIES[*style_cat])).show_ui(ui, |ui| {
                        for (i, c) in crate::styles::CATEGORIES.iter().enumerate() {
                            ui.selectable_value(style_cat, i, crate::i18n::t(c));
                        }
                    });
                    ui.text_edit_singleline(style_name);
                    if ui.button(crate::i18n::t("Mentés stílusként")).clicked() {
                        save_style = Some(g.style.clone());
                    }
                });
                ui.separator();
                let st = &mut g.style;
                egui::ComboBox::from_id_salt("arr").selected_text(arr_name(st.arrangement)).show_ui(ui, |ui| {
                    for a in ARRS {
                        changed |= ui.selectable_value(&mut st.arrangement, a, arr_name(a)).changed();
                    }
                });
                changed |= ui.checkbox(&mut st.show_month_name, crate::i18n::t("Hónap neve")).changed();
                changed |= ui.checkbox(&mut st.show_day_names, crate::i18n::t("Napnevek")).changed();
                changed |= ui.checkbox(&mut st.show_week_numbers, crate::i18n::t("Hetek száma")).changed();
                changed |= ui.checkbox(&mut st.hide_empty_cells, crate::i18n::t("Üres cellák elrejtése")).changed();
                changed |= ui.checkbox(&mut st.hide_border, crate::i18n::t("Keret elrejtése")).changed();
                changed |= ui.checkbox(&mut st.show_holiday_names, crate::i18n::t("Ünnepnevek")).changed();
                changed |= ui.checkbox(&mut st.highlight_holidays, crate::i18n::t("Ünnepek kiemelése")).changed();
                changed |= ui.checkbox(&mut st.highlight_saturday, crate::i18n::t("Szombat kiemelése")).changed();
                changed |= ui.checkbox(&mut st.highlight_sunday, crate::i18n::t("Vasárnap kiemelése")).changed();
                changed |= ui.checkbox(&mut st.week_starts_monday, crate::i18n::t("A hét hétfőn kezdődik")).changed();
                changed |= ui.checkbox(&mut st.show_moon_phases, crate::i18n::t("Holdfázisok")).changed();
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Vonalszín"));
                    changed |= rgba_edit(ui, &mut st.line_color);
                });
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Napcella alakja"));
                    egui::ComboBox::from_id_salt("cellshape").selected_text(shape_name(st.cell_shape)).show_ui(ui, |ui| {
                        for k in CELL_SHAPES {
                            changed |= ui.selectable_value(&mut st.cell_shape, k, shape_name(k)).changed();
                        }
                    });
                });
                changed |= fill_edit(ui, crate::i18n::t("Háttér"), &mut st.background);
                changed |= fill_edit(ui, crate::i18n::t("Páratlan sor"), &mut st.odd_row);
                changed |= fill_edit(ui, crate::i18n::t("Páros sor"), &mut st.even_row);
                ui.separator();
                ui.label(crate::i18n::t("Cellastílus szerkesztése:"));
                let names = [crate::i18n::t("Hónap fejléc"), crate::i18n::t("Napnevek"), crate::i18n::t("Hétvége napnevek"), crate::i18n::t("Hétköznapok"), crate::i18n::t("Hétvégék / ünnepek"), crate::i18n::t("Hetek száma"), crate::i18n::t("Hetek fejléc")];
                egui::ComboBox::from_id_salt("cell").selected_text(names[(*cell_idx).min(6)]).show_ui(ui, |ui| {
                    for (i, n) in names.iter().enumerate() {
                        ui.selectable_value(cell_idx, i, *n);
                    }
                });
                let cs = match *cell_idx {
                    0 => &mut st.month_header,
                    1 => &mut st.weekday_names,
                    2 => &mut st.weekend_names,
                    3 => &mut st.weekdays,
                    4 => &mut st.weekends_holidays,
                    5 => &mut st.week_numbers,
                    _ => &mut st.week_numbers_header,
                };
                changed |= ui.text_edit_singleline(&mut cs.text).changed();
                ui.small("[&MonthName] [&Month] [&Year] [&DayNameShort] [&DayName] [&Day] [&Week] [&WeekShort]");
                let mut extra = cs.extra_text.clone().unwrap_or_default();
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Kiegészítő szöveg"));
                    if ui.text_edit_singleline(&mut extra).changed() {
                        cs.extra_text = if extra.is_empty() { None } else { Some(extra.clone()) };
                        changed = true;
                    }
                });
                changed |= ui.add(egui::DragValue::new(&mut cs.size).speed(0.01).range(0.05..=3.0).prefix(crate::i18n::t("Méret "))).changed();
                ui.horizontal(|ui| {
                    changed |= ui.checkbox(&mut cs.bold, "F").changed();
                    changed |= ui.checkbox(&mut cs.italic, "D").changed();
                    changed |= ui.checkbox(&mut cs.underline, "A").changed();
                    changed |= rgba_edit(ui, &mut cs.color);
                });
                changed |= align_edit(ui, &mut cs.align);
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Cellakeret"));
                    changed |= ui.add(egui::DragValue::new(&mut cs.frame_width_mm).speed(0.02).range(0.0..=3.0).suffix(" mm")).changed();
                    changed |= rgba_edit(ui, &mut cs.frame_color);
                });
                ui.horizontal(|ui| {
                    for (i, n) in ["fent", "jobb", "lent", "bal"].iter().enumerate() {
                        changed |= ui.checkbox(&mut cs.borders[i], *n).changed();
                    }
                });
                changed |= fill_edit(ui, crate::i18n::t("Cella háttér"), &mut cs.background);
            }
        }
        let _ = rect;
        if let Some(st) = pick_style {
            if let Some(l) = self.proj.pages[cur].layers.get_mut(si) {
                if let LayerKind::Grid(g) = &mut l.kind {
                    g.style = st;
                    changed = true;
                }
            }
        }
        if let Some(st) = save_style {
            self.cfg.styles.push(crate::styles::NamedStyle { category: crate::styles::CATEGORIES[self.style_cat].to_string(), name: self.style_name.clone(), style: st });
            self.cfg.save();
            self.status = crate::tf!("Stílus elmentve: {}", self.style_name);
        }
        if auto_photo {
            if let Some(l) = self.proj.pages[cur].layers.get_mut(si) {
                let ar = l.rect.w / l.rect.h.max(0.001);
                if let LayerKind::Photo(p) = &mut l.kind {
                    if let Some(path) = p.path.clone() {
                        if let Some(img) = self.cache.get(&path) {
                            let (z, px, py) = crate::photo::auto_crop(img, ar);
                            p.zoom = z;
                            p.pan_x = px;
                            p.pan_y = py;
                            changed = true;
                        }
                    }
                }
            }
        }
        if changed {
            self.touch();
        }
    }
}
