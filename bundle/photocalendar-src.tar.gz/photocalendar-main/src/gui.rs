//! Layer-based calendar editor (egui): main window, canvas and panels.
//! Dialogs live in `gui_dialogs`, the property panel in `gui_props`.
use crate::cal::Lang;
use crate::config::Config;
use crate::gui_util::*;
use crate::model::*;
use crate::{export, layout, pdf, raster};
use eframe::egui;
use std::collections::HashMap;
use std::path::PathBuf;

#[derive(Clone, Copy, PartialEq)]
pub(crate) enum Drag {
    None,
    Move { dx: f32, dy: f32 },
    Resize { corner: usize },
    PhotoPan,
}

#[derive(Default)]
pub(crate) struct Windows {
    pub preview: bool,
    pub settings: bool,
    pub holidays: bool,
    pub langs: bool,
    pub export: bool,
    pub papers: bool,
    pub wizard: bool,
    pub collage: bool,
    pub styles: bool,
}

pub struct App {
    pub(crate) proj: Project,
    pub(crate) file: Option<PathBuf>,
    pub(crate) cur: usize,
    pub(crate) sel: Option<usize>,
    pub(crate) cache: raster::ImageCache,
    pub(crate) thumb_cache: raster::ImageCache,
    pub(crate) tex: Option<egui::TextureHandle>,
    pub(crate) tex_key: (usize, u32),
    pub(crate) dirty: bool,
    pub(crate) edited: bool,
    pub(crate) fit: bool,
    pub(crate) zoom_px_mm: f32,
    pub(crate) show_grid: bool,
    pub(crate) grid_mm: f32,
    pub(crate) snap: bool,
    pub(crate) photo_mode: bool,
    pub(crate) drag: Drag,
    pub(crate) cfg: Config,
    pub(crate) tpl_name: String,
    pub(crate) cell_idx: usize,
    pub(crate) status: String,
    pub(crate) win: Windows,
    pub(crate) history: Vec<String>,
    pub(crate) redo: Vec<String>,
    pub(crate) last_snap: String,
    pub(crate) clip: Vec<Layer>,
    pub(crate) thumbs: HashMap<usize, egui::TextureHandle>,
    pub(crate) size_w: f32,
    pub(crate) size_h: f32,
    pub(crate) size_name: String,
    pub(crate) wiz: crate::gui_dialogs::Wizard,
    pub(crate) hol_group: usize,
    pub(crate) lang_edit: usize,
    pub(crate) day_pick: u32,
    pub(crate) style_cat: usize,
    pub(crate) style_name: String,
    pub(crate) preset_name: String,
    pub(crate) collage_n: usize,
    pub(crate) collage_photos: Vec<String>,
    /// The project as last saved or opened (for "unsaved changes").
    pub(crate) saved_snap: String,
    /// Save the pictures inside the project file.
    pub(crate) pack_images: bool,
    /// An action waiting for the "unsaved changes" answer.
    pub(crate) pending: Option<Pending>,
    pub(crate) allow_close: bool,
    /// Print preview: the prepared sheets as pictures, and the one shown.
    pub(crate) preview_tex: Vec<(egui::TextureHandle, f32, f32)>,
    pub(crate) preview_at: usize,
}

/// What to do once the unsaved changes are dealt with.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub(crate) enum Pending {
    Close,
    Open,
    New,
}

impl App {
    pub fn new() -> App {
        let size = PageSize::presets().into_iter().find(|s| s.name == "A4").unwrap();
        let year = {
            use chrono::Datelike;
            chrono::Local::now().year() + 1
        };
        let proj = Project::new_default(size.clone(), false, year, 1, Lang::Hu);
        let last_snap = serde_json::to_string(&proj).unwrap_or_default();
        let cfg = Config::load();
        crate::i18n::set(cfg.ui_lang);
        let mut win = Windows::default();
        win.wizard = true;
        App {
            wiz: crate::gui_dialogs::Wizard::new(year),
            proj,
            file: None,
            cur: 0,
            sel: None,
            cache: raster::ImageCache::preview(2200),
            thumb_cache: raster::ImageCache::preview(500),
            tex: None,
            tex_key: (usize::MAX, 0),
            dirty: true,
            edited: false,
            fit: true,
            zoom_px_mm: 2.0,
            show_grid: false,
            grid_mm: 10.0,
            snap: false,
            photo_mode: false,
            drag: Drag::None,
            cfg,
            tpl_name: crate::i18n::t("Saját sablon").into(),
            cell_idx: 0,
            status: crate::i18n::t("Kész.").into(),
            win,
            history: vec![],
            redo: vec![],
            last_snap,
            clip: vec![],
            thumbs: HashMap::new(),
            size_w: size.w_mm,
            size_h: size.h_mm,
            size_name: size.name.clone(),
            hol_group: 0,
            lang_edit: 0,
            day_pick: 1,
            style_cat: 0,
            style_name: crate::i18n::t("Saját stílus").into(),
            preset_name: crate::i18n::t("Saját beállítás").into(),
            collage_n: 3,
            collage_photos: vec![],
            saved_snap: String::new(),
            pack_images: true,
            pending: None,
            allow_close: false,
            preview_tex: vec![],
            preview_at: 0,
        }
    }

    /// The project differs from what was last saved or opened.
    pub(crate) fn is_modified(&self) -> bool {
        // a fresh, untouched calendar from the wizard counts as saved
        !self.saved_snap.is_empty() && serde_json::to_string(&self.proj).unwrap_or_default() != self.saved_snap
    }

    pub(crate) fn mark_saved(&mut self) {
        self.saved_snap = serde_json::to_string(&self.proj).unwrap_or_default();
    }

    /// Ask first when there are unsaved changes; otherwise do it now.
    pub(crate) fn guarded(&mut self, what: Pending, ctx: &egui::Context) {
        if self.is_modified() {
            self.pending = Some(what);
        } else {
            self.proceed(what, ctx);
        }
    }

    fn proceed(&mut self, what: Pending, ctx: &egui::Context) {
        match what {
            Pending::Close => {
                self.allow_close = true;
                ctx.send_viewport_cmd(egui::ViewportCommand::Close);
            }
            Pending::Open => self.do_open(),
            Pending::New => self.win.wizard = true,
        }
    }

    /// "Unsaved changes" question.
    pub(crate) fn unsaved_window(&mut self, ctx: &egui::Context) {
        let Some(what) = self.pending else { return };
        let mut act = 0;
        egui::Window::new(crate::i18n::t("Nem mentett változások")).collapsible(false).resizable(false).anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0]).show(ctx, |ui| {
            ui.label(crate::i18n::t("A naptárban mentetlen változások vannak. Mented őket?"));
            ui.horizontal(|ui| {
                if ui.button(crate::i18n::t("Mentés")).clicked() {
                    act = 1;
                }
                if ui.button(crate::i18n::t("Elvetés")).clicked() {
                    act = 2;
                }
                if ui.button(crate::i18n::t("Mégse")).clicked() {
                    act = 3;
                }
            });
        });
        match act {
            1 => {
                self.save(false);
                self.pending = None;
                if !self.is_modified() {
                    self.proceed(what, ctx);
                }
            }
            2 => {
                self.pending = None;
                self.proceed(what, ctx);
            }
            3 => self.pending = None,
            _ => {}
        }
    }

    /// Print preview: exactly the sheets the PDF / printer gets (paper, N-up, margins, bleed, marks).
    pub(crate) fn preview_window(&mut self, ctx: &egui::Context) {
        if self.preview_tex.is_empty() {
            let dims = Self::dims_fn();
            let sheets = export::prepare(&self.proj, &dims);
            for (i, dl) in sheets.iter().enumerate() {
                let img = raster::rasterize(dl, 60.0, 1100, &mut self.thumb_cache);
                let ci = egui::ColorImage::from_rgba_unmultiplied([img.width() as usize, img.height() as usize], img.as_raw());
                self.preview_tex.push((ctx.load_texture(format!("prev{i}"), ci, egui::TextureOptions::LINEAR), dl.w_mm, dl.h_mm));
            }
            self.preview_at = self.preview_at.min(self.preview_tex.len().saturating_sub(1));
        }
        let mut open = self.win.preview;
        let n = self.preview_tex.len();
        let dpi = self.proj.dpi as f32;
        egui::Window::new(crate::i18n::t("Nyomtatási előnézet")).open(&mut open).default_size([620.0, 760.0]).show(ctx, |ui| {
            ui.horizontal(|ui| {
                if ui.button("◀").clicked() && self.preview_at > 0 {
                    self.preview_at -= 1;
                }
                ui.label(crate::tf!("{}. lap / {}", self.preview_at + 1, n));
                if ui.button("▶").clicked() && self.preview_at + 1 < n {
                    self.preview_at += 1;
                }
                if ui.button(crate::i18n::t("Frissítés")).clicked() {
                    self.preview_tex.clear();
                }
            });
            if let Some((t, wmm, hmm)) = self.preview_tex.get(self.preview_at) {
                let (wpx, hpx) = ((wmm * dpi / 25.4).round(), (hmm * dpi / 25.4).round());
                ui.small(crate::tf!("{} × {} mm · {} dpi-n {} × {} képpont", format!("{wmm:.0}"), format!("{hmm:.0}"), dpi, wpx, hpx));
                let avail = ui.available_size();
                let k = (avail.x / wmm).min((avail.y - 8.0) / hmm).max(0.1);
                let r = ui.allocate_exact_size(egui::vec2(wmm * k, hmm * k), egui::Sense::hover()).0;
                ui.painter().rect_filled(r.expand(1.0), 0.0, egui::Color32::from_gray(90));
                ui.painter().image(t.id(), r, egui::Rect::from_min_max(egui::pos2(0.0, 0.0), egui::pos2(1.0, 1.0)), egui::Color32::WHITE);
            }
        });
        if !open {
            self.preview_tex.clear();
        }
        self.win.preview = open;
    }

    // ---- state helpers ------------------------------------------------------------------

    pub(crate) fn touch(&mut self) {
        self.dirty = true;
        self.edited = true;
        self.thumbs.remove(&self.cur);
    }

    pub(crate) fn structure_changed(&mut self) {
        self.thumbs.clear();
        self.touch();
    }

    pub(crate) fn page_dims(&self) -> (f32, f32) {
        self.proj.page_dims_mm()
    }

    pub(crate) fn photo_slot(pg: &mut Page) -> Option<&mut PhotoLayer> {
        pg.layers.iter_mut().find_map(|l| match &mut l.kind {
            LayerKind::Photo(p) => Some(p),
            _ => None,
        })
    }

    fn restore(&mut self, snap: &str) {
        if let Ok(p) = serde_json::from_str::<Project>(snap) {
            self.proj = p;
            self.last_snap = snap.to_string();
            self.cur = self.cur.min(self.proj.pages.len().saturating_sub(1));
            self.sel = None;
            self.thumbs.clear();
            self.dirty = true;
        }
    }

    pub(crate) fn undo(&mut self) {
        if let Some(prev) = self.history.pop() {
            self.redo.push(self.last_snap.clone());
            self.restore(&prev);
            self.status = crate::i18n::t("Visszavonva.").into();
        }
    }

    pub(crate) fn redo_action(&mut self) {
        if let Some(next) = self.redo.pop() {
            self.history.push(self.last_snap.clone());
            self.restore(&next);
            self.status = crate::i18n::t("Újra végrehajtva.").into();
        }
    }

    /// Called every frame: records an undo step once an edit is finished (mouse released).
    fn snapshot_if_edited(&mut self, ctx: &egui::Context) {
        if !self.edited || ctx.input(|i| i.pointer.any_down()) {
            return;
        }
        self.edited = false;
        let snap = serde_json::to_string(&self.proj).unwrap_or_default();
        if snap != self.last_snap {
            self.history.push(std::mem::replace(&mut self.last_snap, snap));
            if self.history.len() > 100 {
                self.history.remove(0);
            }
            self.redo.clear();
        }
    }

    // ---- clipboard ----------------------------------------------------------------------

    pub(crate) fn copy_sel(&mut self) {
        if let Some(l) = self.sel.and_then(|i| self.proj.pages[self.cur].layers.get(i)) {
            self.clip = vec![l.clone()];
            self.status = crate::i18n::t("Másolva.").into();
        }
    }

    pub(crate) fn delete_sel(&mut self) {
        if let Some(i) = self.sel {
            let layers = &mut self.proj.pages[self.cur].layers;
            if i < layers.len() {
                layers.remove(i);
                self.sel = None;
                self.touch();
            }
        }
    }

    pub(crate) fn cut_sel(&mut self) {
        self.copy_sel();
        self.delete_sel();
    }

    pub(crate) fn paste(&mut self) {
        if self.clip.is_empty() {
            return;
        }
        let first = self.proj.pages[self.cur].layers.len();
        for mut l in self.clip.clone() {
            l.rect.x += 5.0;
            l.rect.y += 5.0;
            self.proj.pages[self.cur].layers.push(l);
        }
        self.sel = Some(first);
        self.touch();
    }

    fn keys(&mut self, ctx: &egui::Context) {
        if ctx.egui_wants_keyboard_input() {
            return;
        }
        let (cmd, shift) = ctx.input(|i| (i.modifiers.command, i.modifiers.shift));
        let pressed = |k: egui::Key| ctx.input(|i| i.key_pressed(k));
        // egui-winit turns Ctrl+C/X/V into Copy/Cut/Paste events instead of key presses
        let ev = |f: fn(&egui::Event) -> bool| ctx.input(|i| i.events.iter().any(f));
        if cmd && pressed(egui::Key::Z) && !shift {
            self.undo();
        } else if cmd && (pressed(egui::Key::Y) || (pressed(egui::Key::Z) && shift)) {
            self.redo_action();
        } else if cmd && pressed(egui::Key::C) || ev(|e| matches!(e, egui::Event::Copy)) {
            self.copy_sel();
            // a non-empty OS clipboard makes the next Ctrl+V arrive as a Paste event
            ctx.copy_text("photocalendar-layer".into());
        } else if cmd && pressed(egui::Key::X) || ev(|e| matches!(e, egui::Event::Cut)) {
            self.cut_sel();
            ctx.copy_text("photocalendar-layer".into());
        } else if cmd && pressed(egui::Key::V) || ev(|e| matches!(e, egui::Event::Paste(_))) {
            self.paste();
        } else if pressed(egui::Key::Delete) {
            self.delete_sel();
        }
    }

    // ---- layers --------------------------------------------------------------------------

    pub(crate) fn add_layer(&mut self, name: &str, kind: LayerKind) {
        let (w, h) = self.page_dims();
        let r = RectMm { x: w * 0.2, y: h * 0.2, w: w * 0.4, h: h * 0.15 };
        self.add_layer_at(name, r, kind);
    }

    pub(crate) fn add_layer_at(&mut self, name: &str, r: RectMm, kind: LayerKind) {
        let pg = &mut self.proj.pages[self.cur];
        pg.layers.push(Layer { name: name.into(), rect: r, rotation_deg: 0.0, visible: true, locked: false, kind });
        self.sel = Some(pg.layers.len() - 1);
        self.touch();
    }

    pub(crate) fn add_text(&mut self, name: &str, text: &str, pt: f32, bold: bool) {
        self.add_layer(
            name,
            LayerKind::Text(TextLayer {
                text: text.into(),
                font_size_pt: pt,
                bold,
                color: Rgba::BLACK,
                align: Align::Left,
                opacity: 1.0,
                italic: false,
                drop_shadow: false,
                fill: Fill::Color(Rgba::BLACK),
                outline: None,
            }),
        );
    }

    pub(crate) fn add_clipart(&mut self, name: &str) {
        let (w, h) = self.page_dims();
        let s = w.min(h) * 0.25;
        let rect = if name.starts_with("Keret") { RectMm { x: 0.0, y: 0.0, w, h } } else { RectMm { x: (w - s) / 2.0, y: (h - s) / 2.0, w: s, h: s } };
        let layers = crate::clipart::instantiate(name, rect);
        let pg = &mut self.proj.pages[self.cur];
        let first = pg.layers.len();
        pg.layers.extend(layers);
        self.sel = Some(first);
        self.touch();
    }

    /// Month Set: 12 (or all project) mini month grids on the current page.
    pub(crate) fn add_month_set(&mut self) {
        let (w, h) = self.page_dims();
        let n = self.proj.months.clamp(1, 12) as usize;
        let (mut y, mut m) = (self.proj.start_year, self.proj.start_month);
        let area = RectMm { x: w * 0.05, y: h * 0.55, w: w * 0.9, h: h * 0.4 };
        let cols = if w > h { 4 } else { 3 };
        let rows = n.div_ceil(cols);
        let gap = w.min(h) * 0.02;
        let (cw, ch) = ((area.w - gap * (cols as f32 - 1.0)) / cols as f32, (area.h - gap * (rows as f32 - 1.0)) / rows as f32);
        for i in 0..n {
            let mut st = GridStyle::default();
            st.show_month_name = true;
            st.show_holiday_names = false;
            st.background = Fill::None;
            let r = RectMm { x: area.x + (i % cols) as f32 * (cw + gap), y: area.y + (i / cols) as f32 * (ch + gap), w: cw, h: ch };
            self.proj.pages[self.cur].layers.push(Layer {
                name: crate::tf!("Hónap {}", i + 1),
                rect: r,
                rotation_deg: 0.0,
                visible: true,
                locked: false,
                kind: LayerKind::Grid(GridLayer { fixed_month: Some((y, m)), style: st }),
            });
            m += 1;
            if m > 12 {
                m = 1;
                y += 1;
            }
        }
        self.touch();
    }

    /// Photo collage: several photo layers in a grid arrangement.
    pub(crate) fn add_collage(&mut self, photos: &[String], n: usize) {
        let (w, h) = self.page_dims();
        let area = RectMm { x: w * 0.05, y: h * 0.05, w: w * 0.9, h: h * 0.45 };
        let cols = match n {
            1 => 1,
            2 => 2,
            3 | 4 => 2,
            _ => 3,
        };
        let rows = n.div_ceil(cols);
        let gap = w.min(h) * 0.015;
        let (cw, ch) = ((area.w - gap * (cols as f32 - 1.0)) / cols as f32, (area.h - gap * (rows as f32 - 1.0)) / rows as f32);
        let first = self.proj.pages[self.cur].layers.len();
        for i in 0..n {
            let mut p = PhotoLayer::empty();
            p.path = photos.get(i).cloned();
            p.frame_mm = w.min(h) * 0.004;
            p.frame_color = Rgba::WHITE;
            p.drop_shadow = true;
            self.proj.pages[self.cur].layers.push(Layer {
                name: crate::tf!("Kollázs fotó {}", i + 1),
                rect: RectMm { x: area.x + (i % cols) as f32 * (cw + gap), y: area.y + (i / cols) as f32 * (ch + gap), w: cw, h: ch },
                rotation_deg: 0.0,
                visible: true,
                locked: false,
                kind: LayerKind::Photo(p),
            });
        }
        self.sel = Some(first);
        self.touch();
    }

    pub(crate) fn add_photos(&mut self) {
        let files = pick_images();
        if files.is_empty() {
            return;
        }
        let mut it = files.into_iter();
        let n = self.proj.pages.len();
        let mut put = 0;
        for k in 0..n {
            let i = (self.cur + k) % n;
            if let Some(p) = Self::photo_slot(&mut self.proj.pages[i]) {
                if p.path.is_none() {
                    if let Some(f) = it.next() {
                        p.path = Some(f);
                        put += 1;
                    }
                }
            }
        }
        let left = it.count();
        self.status = crate::tf!("{} fotó elhelyezve{}", put, if left > 0 { crate::tf!(", {} nem fért el (nincs üres hely)", left) } else { String::new() });
        self.structure_changed();
    }

    // ---- alignment ----------------------------------------------------------------------

    pub(crate) fn align_sel(&mut self, how: &str) {
        let (w, h) = self.page_dims();
        let Some(i) = self.sel else { return };
        let Some(l) = self.proj.pages[self.cur].layers.get_mut(i) else { return };
        match how {
            "h" => l.rect.x = (w - l.rect.w) / 2.0,
            "v" => l.rect.y = (h - l.rect.h) / 2.0,
            "left" => l.rect.x = 0.0,
            "right" => l.rect.x = w - l.rect.w,
            "top" => l.rect.y = 0.0,
            "bottom" => l.rect.y = h - l.rect.h,
            _ => {}
        }
        self.touch();
    }

    /// Applies position and size of the selected layer to the layers of the same name on all pages.
    pub(crate) fn apply_rect_to_all(&mut self) {
        let Some(i) = self.sel else { return };
        let Some(src) = self.proj.pages[self.cur].layers.get(i).cloned() else { return };
        let mut n = 0;
        for pg in self.proj.pages.iter_mut() {
            for l in pg.layers.iter_mut() {
                if l.name == src.name && std::mem::discriminant(&l.kind) == std::mem::discriminant(&src.kind) {
                    l.rect = src.rect;
                    l.rotation_deg = src.rotation_deg;
                    n += 1;
                }
            }
        }
        self.status = crate::tf!("{} réteg átméretezve az összes oldalon.", n);
        self.structure_changed();
    }

    // ---- templates ----------------------------------------------------------------------

    pub(crate) fn apply_template(&mut self, ti: usize, all: bool) {
        let t = self.cfg.templates[ti].clone();
        let (w, h) = self.page_dims();
        let (sx, sy) = (if t.w_mm > 0.0 { w / t.w_mm } else { 1.0 }, if t.h_mm > 0.0 { h / t.h_mm } else { 1.0 });
        let pages: Vec<usize> = if all { (0..self.proj.pages.len()).collect() } else { vec![self.cur] };
        for i in pages {
            let pg = &mut self.proj.pages[i];
            let old_photo = Self::photo_slot(pg).and_then(|p| p.path.clone());
            let month = pg.month;
            *pg = t.portrait_page.clone();
            pg.month = month;
            for l in pg.layers.iter_mut() {
                l.rect = RectMm { x: l.rect.x * sx, y: l.rect.y * sy, w: l.rect.w * sx, h: l.rect.h * sy };
                if let (Some(ph), LayerKind::Photo(p)) = (&old_photo, &mut l.kind) {
                    p.path = Some(ph.clone());
                }
            }
        }
        self.sel = None;
        self.structure_changed();
    }

    pub(crate) fn apply_builtin(&mut self, idx: usize, all: bool) {
        let (w, h) = self.page_dims();
        let pages: Vec<usize> = if all { (0..self.proj.pages.len()).collect() } else { vec![self.cur] };
        for i in pages {
            let old = &self.proj.pages[i];
            let mut photos: Vec<Option<String>> = old
                .layers
                .iter()
                .filter_map(|l| match &l.kind {
                    LayerKind::Photo(p) => Some(p.path.clone()),
                    _ => None,
                })
                .collect();
            photos.reverse();
            let holes: Vec<Layer> = old.layers.iter().filter(|l| matches!(l.kind, LayerKind::Holes { .. })).cloned().collect();
            let mut np = crate::templates::build(idx, w, h, old.month);
            for l in np.layers.iter_mut() {
                if let LayerKind::Photo(p) = &mut l.kind {
                    if let Some(path) = photos.pop() {
                        p.path = path;
                    }
                }
            }
            np.layers.extend(holes);
            self.proj.pages[i] = np;
        }
        self.sel = None;
        self.structure_changed();
    }

    // ---- export ---------------------------------------------------------------------------

    fn dims_fn() -> impl Fn(&str) -> Option<(u32, u32)> {
        |p: &str| image::image_dimensions(p).ok()
    }

    pub(crate) fn build_pdf_bytes(&mut self) -> Vec<u8> {
        let dims = Self::dims_fn();
        let sheets = export::prepare(&self.proj, &dims);
        let mut cache = raster::ImageCache::new();
        pdf::export_pdf(&sheets, &self.proj.title, self.proj.dpi as f32, &mut cache, self.proj.export.cmyk)
    }

    pub(crate) fn export_pdf(&mut self) {
        let Some(path) = crate::platform::FileDialog::new().add_filter(crate::i18n::t("PDF"), &["pdf"]).set_file_name("naptar.pdf").save_file() else { return };
        let bytes = self.build_pdf_bytes();
        self.status = match std::fs::write(&path, bytes) {
            Ok(_) => crate::tf!("PDF kész: {}", path.display()),
            Err(e) => crate::tf!("PDF hiba: {}", e),
        };
    }

    pub(crate) fn print_now(&mut self) {
        let bytes = self.build_pdf_bytes();
        let path = std::env::temp_dir().join("photocalendar_nyomtatas.pdf");
        if let Err(e) = std::fs::write(&path, bytes) {
            self.status = crate::tf!("Nyomtatás hiba: {}", e);
            return;
        }
        self.status = match export::print_file(&path, self.proj.export.copies) {
            Ok(_) => crate::i18n::t("Elküldve a nyomtatóra.").into(),
            Err(e) => crate::tf!("Nyomtatás hiba: {} (a PDF itt van: {})", e, path.display()),
        };
    }

    /// PNG or JPEG (by file extension) of the current page, or of all pages of the selected range.
    pub(crate) fn export_image(&mut self, all: bool) {
        let Some(path) = crate::platform::FileDialog::new().add_filter(crate::i18n::t("Kép"), &["png", "jpg", "jpeg"]).set_file_name("oldal.png").save_file() else { return };
        let dims = Self::dims_fn();
        let mut cache = raster::ImageCache::new();
        let q = self.proj.export.jpeg_quality.clamp(10, 100);
        let idx: Vec<usize> = if all { export::parse_range(&self.proj.export.page_range, self.proj.pages.len()) } else { vec![self.cur] };
        let mut ok = 0;
        for (k, i) in idx.iter().enumerate() {
            let dl = layout::render_page(&self.proj, *i, &dims);
            let img = raster::rasterize(&dl, self.proj.dpi as f32, 12000, &mut cache);
            let p = if idx.len() > 1 {
                let stem = path.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| "oldal".into());
                let ext = path.extension().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| "png".into());
                path.with_file_name(format!("{stem}_{:02}.{ext}", k + 1))
            } else {
                path.clone()
            };
            let is_jpg = matches!(p.extension().and_then(|e| e.to_str()).map(|e| e.to_lowercase()).as_deref(), Some("jpg") | Some("jpeg"));
            let res = if is_jpg {
                let rgb = image::DynamicImage::ImageRgba8(img).to_rgb8();
                std::fs::File::create(&p).map_err(|e| e.to_string()).and_then(|f| {
                    image::codecs::jpeg::JpegEncoder::new_with_quality(std::io::BufWriter::new(f), q).encode_image(&rgb).map_err(|e| e.to_string())
                })
            } else {
                img.save(&p).map_err(|e| e.to_string())
            };
            if res.is_ok() {
                ok += 1;
            }
        }
        self.status = crate::tf!("{} kép mentve: {}", ok, path.display());
    }

    // ---- menu -----------------------------------------------------------------------------

    fn save(&mut self, as_new: bool) {
        if self.file.is_none() || as_new {
            if let Some(p) = crate::platform::FileDialog::new().add_filter("PhotoCalendar", &["json"]).set_file_name("naptar.json").save_file() {
                self.file = Some(p);
            } else {
                return;
            }
        }
        if let Some(p) = self.file.clone() {
            match crate::projfile::save(&self.proj, &p, self.pack_images) {
                Ok(missing) => {
                    self.mark_saved();
                    self.status = if missing.is_empty() {
                        crate::tf!("Mentve: {}", p.display())
                    } else {
                        crate::tf!("Mentve: {} ({} kép nem olvasható, csak az útvonala került a fájlba)", p.display(), missing.len())
                    };
                }
                Err(e) => self.status = crate::tf!("Hiba: {}", e),
            }
        }
    }

    fn do_open(&mut self) {
        if let Some(p) = crate::platform::FileDialog::new().add_filter("PhotoCalendar", &["json"]).pick_file() {
            match crate::projfile::load(&p) {
                Ok((pr, notes)) => {
                    self.status = if notes.is_empty() {
                        crate::tf!("Megnyitva: {}", p.display())
                    } else {
                        crate::tf!("Megnyitva, javított értékek: {}", notes.join(", "))
                    };
                    self.proj = pr;
                    self.file = Some(p);
                    self.cur = 0;
                    self.sel = None;
                    self.cache.clear();
                    self.thumb_cache.clear();
                    self.history.clear();
                    self.redo.clear();
                    self.last_snap = serde_json::to_string(&self.proj).unwrap_or_default();
                    self.saved_snap = self.last_snap.clone();
                    self.thumbs.clear();
                    self.dirty = true;
                }
                Err(e) => self.status = crate::tf!("Hiba: {}", e),
            }
        }
    }

    fn import_pages(&mut self) {
        if let Some(p) = crate::platform::FileDialog::new().add_filter("PhotoCalendar", &["json"]).pick_file() {
            match Project::load(&p) {
                Ok(pr) => {
                    let n = pr.pages.len();
                    let (w, h) = self.page_dims();
                    let (ow, oh) = pr.page_dims_mm();
                    let (sx, sy) = (w / ow.max(1.0), h / oh.max(1.0));
                    for mut pg in pr.pages {
                        for l in pg.layers.iter_mut() {
                            l.rect = RectMm { x: l.rect.x * sx, y: l.rect.y * sy, w: l.rect.w * sx, h: l.rect.h * sy };
                        }
                        self.proj.pages.push(pg);
                    }
                    self.status = crate::tf!("{} oldal importálva (átméretezve az aktuális lapméretre).", n);
                    self.structure_changed();
                }
                Err(e) => self.status = crate::tf!("Hiba: {}", e),
            }
        }
    }

    fn menu(&mut self, ui: &mut egui::Ui) {
        egui::MenuBar::new().ui(ui, |ui| {
            ui.menu_button(crate::i18n::t("Fájl"), |ui| {
                if ui.button(crate::i18n::t("Új naptár (varázsló)…")).clicked() {
                    self.guarded(Pending::New, &ui.ctx().clone());
                    ui.close();
                }
                if ui.button(crate::i18n::t("Megnyitás…")).clicked() {
                    self.guarded(Pending::Open, &ui.ctx().clone());
                    ui.close();
                }
                if ui.button(crate::i18n::t("Mentés")).clicked() {
                    self.save(false);
                    ui.close();
                }
                if ui.button(crate::i18n::t("Mentés másként…")).clicked() {
                    self.save(true);
                    ui.close();
                }
                ui.checkbox(&mut self.pack_images, crate::i18n::t("Képek mentése a projektfájlba"))
                    .on_hover_text(crate::i18n::t("A fotók a projektfájlba kerülnek, így a naptár egy fájlban átvihető másik gépre. Minden a saját gépeden marad."));
                if ui.button(crate::i18n::t("Nyomtatási előnézet…")).clicked() {
                    self.preview_tex.clear();
                    self.win.preview = true;
                    ui.close();
                }
                ui.separator();
                if ui.button(crate::i18n::t("Oldal mentése sablonként")).clicked() {
                    let (w, h) = self.page_dims();
                    let mut pg = self.proj.pages[self.cur].clone();
                    if let Some(p) = Self::photo_slot(&mut pg) {
                        p.path = None;
                    }
                    self.cfg.templates.push(Template { name: self.tpl_name.clone(), portrait_page: pg, w_mm: w, h_mm: h });
                    self.cfg.save();
                    self.status = crate::tf!("Sablon elmentve: {}", self.tpl_name);
                    ui.close();
                }
                ui.separator();
                if ui.button(crate::i18n::t("Export / nyomtatás…")).clicked() {
                    self.win.export = true;
                    ui.close();
                }
                if ui.button(crate::i18n::t("PDF mentése…")).clicked() {
                    self.export_pdf();
                    ui.close();
                }
                if ui.button(crate::i18n::t("Aktuális oldal képként (PNG/JPEG)…")).clicked() {
                    self.export_image(false);
                    ui.close();
                }
                if ui.button(crate::i18n::t("Oldalak képként (PNG/JPEG)…")).clicked() {
                    self.export_image(true);
                    ui.close();
                }
            });
            ui.menu_button(crate::i18n::t("Szerkesztés"), |ui| {
                if ui.add_enabled(!self.history.is_empty(), egui::Button::new(crate::i18n::t("Visszavonás (Ctrl+Z)"))).clicked() {
                    self.undo();
                    ui.close();
                }
                if ui.add_enabled(!self.redo.is_empty(), egui::Button::new(crate::i18n::t("Újra (Ctrl+Y)"))).clicked() {
                    self.redo_action();
                    ui.close();
                }
                ui.separator();
                if ui.button(crate::i18n::t("Kivágás (Ctrl+X)")).clicked() {
                    self.cut_sel();
                    ui.close();
                }
                if ui.button(crate::i18n::t("Másolás (Ctrl+C)")).clicked() {
                    self.copy_sel();
                    ui.close();
                }
                if ui.button(crate::i18n::t("Beillesztés (Ctrl+V)")).clicked() {
                    self.paste();
                    ui.close();
                }
                if ui.button(crate::i18n::t("Törlés (Del)")).clicked() {
                    self.delete_sel();
                    ui.close();
                }
            });
            ui.menu_button(crate::i18n::t("Naptár"), |ui| {
                if ui.button(crate::i18n::t("Beállítások (méret, kötés, nyelv)…")).clicked() {
                    self.win.settings = true;
                    ui.close();
                }
                if ui.button(crate::i18n::t("Ünnepnapok…")).clicked() {
                    self.win.holidays = true;
                    ui.close();
                }
                if ui.button(crate::i18n::t("Nyelvszerkesztő…")).clicked() {
                    self.win.langs = true;
                    ui.close();
                }
                if ui.button(crate::i18n::t("Hónapstílus…")).clicked() {
                    self.win.styles = true;
                    ui.close();
                }
                if ui.button(crate::i18n::t("Papírméretek kezelése…")).clicked() {
                    self.win.papers = true;
                    ui.close();
                }
                ui.separator();
                if ui.button(crate::i18n::t("Fotók hozzáadása…")).clicked() {
                    self.add_photos();
                    ui.close();
                }
                if ui.button(crate::i18n::t("Oldal duplikálása")).clicked() {
                    self.duplicate_page();
                    ui.close();
                }
                if ui.button(crate::i18n::t("Oldalak importálása fájlból…")).clicked() {
                    self.import_pages();
                    ui.close();
                }
            });
            ui.menu_button(crate::i18n::t("Hozzáadás"), |ui| {
                if ui.button(crate::i18n::t("Fotó")).clicked() {
                    self.add_layer(crate::i18n::t("Fotó"), LayerKind::Photo(PhotoLayer::empty()));
                    ui.close();
                }
                if ui.button(crate::i18n::t("Fotókollázs…")).clicked() {
                    self.win.collage = true;
                    ui.close();
                }
                if ui.button(crate::i18n::t("Felirat (caption)")).clicked() {
                    self.add_text(crate::i18n::t("Felirat"), "{month_year}", 18.0, false);
                    ui.close();
                }
                if ui.button(crate::i18n::t("Szöveg")).clicked() {
                    self.add_text(crate::i18n::t("Szöveg"), crate::i18n::t("Szöveg"), 24.0, false);
                    ui.close();
                }
                ui.menu_button(crate::i18n::t("Díszítőelemek"), |ui| {
                    for n in crate::clipart::names() {
                        if ui.button(crate::i18n::t(n)).clicked() {
                            self.add_clipart(n);
                            ui.close();
                        }
                    }
                });
                if ui.button(crate::i18n::t("Logó / kép fájlból…")).clicked() {
                    if let Some(f) = pick_image() {
                        self.add_layer(crate::i18n::t("Kép"), LayerKind::Image { path: f, opacity: 1.0 });
                    }
                    ui.close();
                }
                if ui.button(crate::i18n::t("Alakzat")).clicked() {
                    self.add_layer(
                        crate::i18n::t("Alakzat"),
                        LayerKind::Shape(ShapeLayer { kind: ShapeKind::Rectangle, fill: Fill::Color(Rgba(220, 220, 240, 255)), outline: None, opacity: 1.0, drop_shadow: false }),
                    );
                    ui.close();
                }
                if ui.button(crate::i18n::t("Naptárhónap (rács)")).clicked() {
                    self.add_layer(crate::i18n::t("Naptárrács"), LayerKind::Grid(GridLayer { fixed_month: None, style: GridStyle::default() }));
                    ui.close();
                }
                if ui.button(crate::i18n::t("Hónapkészlet (mini hónapok)")).clicked() {
                    self.add_month_set();
                    ui.close();
                }
                if ui.button(crate::i18n::t("Kötés (spirállyukak)")).clicked() {
                    let (w, _) = self.page_dims();
                    self.add_layer_at(
                        crate::i18n::t("Kötés (spirál)"),
                        RectMm { x: w * 0.05, y: 3.0, w: w * 0.9, h: 6.0 },
                        LayerKind::Holes { count: (w * 0.9 / 12.7) as u32, diameter_mm: 3.5, vertical: false, color: Rgba(90, 90, 90, 255) },
                    );
                    ui.close();
                }
            });
            ui.menu_button(crate::i18n::t("Réteg"), |ui| {
                if ui.button(crate::i18n::t("Minden réteg törlése az oldalról")).clicked() {
                    self.proj.pages[self.cur].layers.clear();
                    self.sel = None;
                    self.touch();
                    ui.close();
                }
                ui.separator();
                if ui.button(crate::i18n::t("Előre hozás")).clicked() {
                    self.reorder(1);
                    ui.close();
                }
                if ui.button(crate::i18n::t("Hátra küldés")).clicked() {
                    self.reorder(-1);
                    ui.close();
                }
                ui.separator();
                for (label, how) in [
                    (crate::i18n::t("Középre vízszintesen"), "h"),
                    (crate::i18n::t("Középre függőlegesen"), "v"),
                    (crate::i18n::t("Balra az oldalhoz"), "left"),
                    (crate::i18n::t("Jobbra az oldalhoz"), "right"),
                    (crate::i18n::t("Felülre az oldalhoz"), "top"),
                    (crate::i18n::t("Alulra az oldalhoz"), "bottom"),
                ] {
                    if ui.button(label).clicked() {
                        self.align_sel(how);
                        ui.close();
                    }
                }
                ui.separator();
                if ui.button(crate::i18n::t("Méret/pozíció alkalmazása minden oldalra")).clicked() {
                    self.apply_rect_to_all();
                    ui.close();
                }
            });
            ui.menu_button(crate::i18n::t("Nézet"), |ui| {
                ui.checkbox(&mut self.show_grid, crate::i18n::t("Rács"));
                ui.checkbox(&mut self.snap, crate::i18n::t("Rácshoz igazítás"));
                ui.add(egui::Slider::new(&mut self.grid_mm, 1.0..=50.0).text(crate::i18n::t("Rács mérete (mm)")));
                ui.checkbox(&mut self.cfg.inch, crate::i18n::t("Hüvelyk (inch) mértékegység"));
            });
            ui.menu_button("Nyelv / Limbă / Language", |ui| {
                for l in crate::i18n::UiLang::ALL {
                    if ui.radio_value(&mut self.cfg.ui_lang, l, l.label()).changed() {
                        crate::i18n::set(l);
                        self.cfg.save();
                        self.thumb_cache.clear();
                        ui.close();
                    }
                }
            });
        });
    }

    fn reorder(&mut self, dir: i32) {
        let Some(s) = self.sel else { return };
        let layers = &mut self.proj.pages[self.cur].layers;
        if dir > 0 && s + 1 < layers.len() {
            layers.swap(s, s + 1);
            self.sel = Some(s + 1);
        } else if dir < 0 && s > 0 {
            layers.swap(s, s - 1);
            self.sel = Some(s - 1);
        } else {
            return;
        }
        self.touch();
    }

    pub(crate) fn duplicate_page(&mut self) {
        let pg = self.proj.pages[self.cur].clone();
        self.proj.pages.insert(self.cur + 1, pg);
        self.cur += 1;
        self.sel = None;
        self.structure_changed();
    }

    // ---- left panel -------------------------------------------------------------------------

    fn thumb(&mut self, ctx: &egui::Context, i: usize, budget: &mut u32) -> Option<egui::TextureId> {
        if let Some(t) = self.thumbs.get(&i) {
            return Some(t.id());
        }
        if *budget == 0 {
            ctx.request_repaint();
            return None;
        }
        *budget -= 1;
        let dims = Self::dims_fn();
        let dl = layout::render_page(&self.proj, i, &dims);
        let img = raster::rasterize(&dl, 10.0, 130, &mut self.thumb_cache);
        let ci = egui::ColorImage::from_rgba_unmultiplied([img.width() as usize, img.height() as usize], img.as_raw());
        let t = ctx.load_texture(format!("thumb{i}"), ci, egui::TextureOptions::LINEAR);
        let id = t.id();
        self.thumbs.insert(i, t);
        Some(id)
    }

    fn left_panel(&mut self, ui: &mut egui::Ui) {
        let ctx = ui.ctx().clone();
        ui.heading(crate::i18n::t("Oldalak"));
        let mut budget = 2u32;
        let mut act: Option<&str> = None;
        egui::ScrollArea::vertical().id_salt("pages").max_height(300.0).show(ui, |ui| {
            for i in 0..self.proj.pages.len() {
                let label = match self.proj.pages[i].month {
                    Some((y, m)) => format!("{}. {} {}", i + 1, self.proj.month_name(self.proj.lang, m), y),
                    None => crate::tf!("{}. Szabad oldal", i + 1),
                };
                ui.horizontal(|ui| {
                    if let Some(id) = self.thumb(&ctx, i, &mut budget) {
                        let (pw, ph) = self.page_dims();
                        let sz = if pw > ph { egui::vec2(52.0, 52.0 * ph / pw) } else { egui::vec2(52.0 * pw / ph, 52.0) };
                        let r = ui.add(egui::Image::new((id, sz)).sense(egui::Sense::click()));
                        if r.clicked() {
                            self.cur = i;
                            self.sel = None;
                            self.dirty = true;
                        }
                    }
                    if ui.selectable_label(self.cur == i, label).clicked() {
                        self.cur = i;
                        self.sel = None;
                        self.dirty = true;
                    }
                });
            }
        });
        ui.horizontal_wrapped(|ui| {
            if ui.small_button(crate::i18n::t("+ Szabad")).clicked() {
                act = Some("add");
            }
            if ui.small_button(crate::i18n::t("Másol")).clicked() {
                act = Some("dup");
            }
            if ui.small_button(crate::i18n::t("Töröl")).clicked() {
                act = Some("del");
            }
            if ui.small_button("▲").clicked() {
                act = Some("up");
            }
            if ui.small_button("▼").clicked() {
                act = Some("down");
            }
        });
        match act {
            Some("add") => {
                let (w, h) = self.page_dims();
                let mut pg = default_month_page(w, h, 2000, 1);
                pg.month = None;
                pg.layers.retain(|l| matches!(l.kind, LayerKind::Photo(_)));
                self.proj.pages.push(pg);
                self.cur = self.proj.pages.len() - 1;
                self.structure_changed();
            }
            Some("dup") => self.duplicate_page(),
            Some("del") if self.proj.pages.len() > 1 => {
                self.proj.pages.remove(self.cur);
                self.cur = self.cur.min(self.proj.pages.len() - 1);
                self.sel = None;
                self.structure_changed();
            }
            Some("up") if self.cur > 0 => {
                self.proj.pages.swap(self.cur, self.cur - 1);
                self.cur -= 1;
                self.structure_changed();
            }
            Some("down") if self.cur + 1 < self.proj.pages.len() => {
                self.proj.pages.swap(self.cur, self.cur + 1);
                self.cur += 1;
                self.structure_changed();
            }
            _ => {}
        }
        ui.separator();
        ui.heading(crate::i18n::t("Rétegek"));
        let n = self.proj.pages[self.cur].layers.len();
        egui::ScrollArea::vertical().id_salt("layers").max_height(220.0).show(ui, |ui| {
            for i in (0..n).rev() {
                let l = &mut self.proj.pages[self.cur].layers[i];
                ui.horizontal(|ui| {
                    if ui.checkbox(&mut l.visible, "").changed() {
                        self.dirty = true;
                        self.edited = true;
                    }
                    let lock = if l.locked { "🔒" } else { "🔓" };
                    if ui.small_button(lock).clicked() {
                        l.locked = !l.locked;
                        self.edited = true;
                    }
                    if ui.selectable_label(self.sel == Some(i), crate::i18n::tr(&l.name)).clicked() {
                        self.sel = Some(i);
                    }
                });
            }
        });
        ui.horizontal_wrapped(|ui| {
            if ui.small_button(crate::i18n::t("▲ előre")).clicked() {
                self.reorder(1);
            }
            if ui.small_button(crate::i18n::t("▼ hátra")).clicked() {
                self.reorder(-1);
            }
            if ui.small_button(crate::i18n::t("Másol")).clicked() {
                self.copy_sel();
                self.paste();
            }
            if ui.small_button(crate::i18n::t("Töröl")).clicked() {
                self.delete_sel();
            }
        });
        ui.separator();
        ui.heading(crate::i18n::t("Beépített sablonok"));
        let mut bi: Option<(usize, bool)> = None;
        for (i, n) in crate::templates::names().iter().enumerate() {
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t(n));
                if ui.small_button(crate::i18n::t("Ide")).clicked() {
                    bi = Some((i, false));
                }
                if ui.small_button(crate::i18n::t("Mind")).clicked() {
                    bi = Some((i, true));
                }
            });
        }
        if let Some((i, all)) = bi {
            self.apply_builtin(i, all);
        }
        ui.separator();
        ui.heading(crate::i18n::t("Saját sablonok"));
        ui.horizontal(|ui| {
            ui.text_edit_singleline(&mut self.tpl_name);
            if ui.button(crate::i18n::t("Mentés")).clicked() {
                let (w, h) = self.page_dims();
                let mut pg = self.proj.pages[self.cur].clone();
                if let Some(p) = Self::photo_slot(&mut pg) {
                    p.path = None;
                }
                self.cfg.templates.push(Template { name: self.tpl_name.clone(), portrait_page: pg, w_mm: w, h_mm: h });
                self.cfg.save();
            }
        });
        let mut apply: Option<(usize, bool)> = None;
        let mut del: Option<usize> = None;
        for (i, t) in self.cfg.templates.iter().enumerate() {
            ui.horizontal(|ui| {
                ui.label(&t.name);
                if ui.small_button(crate::i18n::t("Ide")).clicked() {
                    apply = Some((i, false));
                }
                if ui.small_button(crate::i18n::t("Mind")).clicked() {
                    apply = Some((i, true));
                }
                if ui.small_button("✖").clicked() {
                    del = Some(i);
                }
            });
        }
        if let Some((i, all)) = apply {
            self.apply_template(i, all);
        }
        if let Some(i) = del {
            self.cfg.templates.remove(i);
            self.cfg.save();
        }
    }

    // ---- canvas -----------------------------------------------------------------------------

    fn canvas(&mut self, ui: &mut egui::Ui) {
        let (pw, ph) = self.page_dims();
        ui.horizontal(|ui| {
            ui.checkbox(&mut self.fit, crate::i18n::t("Illesztés"));
            if !self.fit {
                ui.add(egui::Slider::new(&mut self.zoom_px_mm, 0.5..=10.0).text(crate::i18n::t("Nagyítás")));
                if ui.button("100%").clicked() {
                    self.zoom_px_mm = 96.0 / 25.4;
                }
            }
            ui.checkbox(&mut self.show_grid, crate::i18n::t("Rács"));
            ui.checkbox(&mut self.snap, crate::i18n::t("Igazítás"));
            ui.add(egui::Slider::new(&mut self.grid_mm, 1.0..=50.0).text(crate::i18n::t("Rács mérete")));
            ui.checkbox(&mut self.photo_mode, crate::i18n::t("Fotó igazítása egérrel"));
        });
        let avail = ui.available_size();
        let (resp, painter) = ui.allocate_painter(avail, egui::Sense::click_and_drag());
        let area = resp.rect;
        let scale = if self.fit { ((area.width() - 20.0) / pw).min((area.height() - 20.0) / ph).max(0.1) } else { self.zoom_px_mm };
        let size = egui::vec2(pw * scale, ph * scale);
        let origin = if size.x <= area.width() && size.y <= area.height() { area.center() - size / 2.0 } else { area.min + egui::vec2(10.0, 10.0) };
        let page_rect = egui::Rect::from_min_size(origin, size);

        let px_per_mm = scale * ui.ctx().pixels_per_point();
        let key = (self.cur, (px_per_mm * 100.0) as u32);
        if self.dirty || self.tex.is_none() || key != self.tex_key {
            let dims = Self::dims_fn();
            let dl = layout::render_page(&self.proj, self.cur, &dims);
            let img = raster::rasterize(&dl, px_per_mm * 25.4, 3200, &mut self.cache);
            let ci = egui::ColorImage::from_rgba_unmultiplied([img.width() as usize, img.height() as usize], img.as_raw());
            self.tex = Some(ui.ctx().load_texture("page", ci, egui::TextureOptions::LINEAR));
            self.tex_key = key;
            self.dirty = false;
        }
        painter.rect_filled(area, 0.0, egui::Color32::from_gray(90));
        if let Some(t) = &self.tex {
            painter.image(t.id(), page_rect, egui::Rect::from_min_max(egui::pos2(0.0, 0.0), egui::pos2(1.0, 1.0)), egui::Color32::WHITE);
        }
        if self.show_grid {
            let col = egui::Color32::from_rgba_unmultiplied(0, 120, 255, 70);
            let mut x = 0.0;
            while x <= pw {
                painter.line_segment([page_rect.min + egui::vec2(x * scale, 0.0), page_rect.min + egui::vec2(x * scale, size.y)], (1.0, col));
                x += self.grid_mm;
            }
            let mut y = 0.0;
            while y <= ph {
                painter.line_segment([page_rect.min + egui::vec2(0.0, y * scale), page_rect.min + egui::vec2(size.x, y * scale)], (1.0, col));
                y += self.grid_mm;
            }
        }
        let to_mm = |p: egui::Pos2| ((p.x - page_rect.min.x) / scale, (p.y - page_rect.min.y) / scale);
        let snap = |v: f32, on: bool, g: f32| if on { (v / g).round() * g } else { v };

        let sel_rect = self.sel.and_then(|i| self.proj.pages[self.cur].layers.get(i)).map(|l| l.rect);
        if let Some(r) = sel_rect {
            let rr = egui::Rect::from_min_size(page_rect.min + egui::vec2(r.x * scale, r.y * scale), egui::vec2(r.w * scale, r.h * scale));
            painter.rect_stroke(rr, 0.0, egui::Stroke::new(1.5, egui::Color32::from_rgb(0, 120, 255)), egui::StrokeKind::Outside);
            for c in [rr.left_top(), rr.right_top(), rr.left_bottom(), rr.right_bottom()] {
                painter.rect_filled(egui::Rect::from_center_size(c, egui::vec2(9.0, 9.0)), 1.0, egui::Color32::WHITE);
                painter.rect_stroke(egui::Rect::from_center_size(c, egui::vec2(9.0, 9.0)), 1.0, egui::Stroke::new(1.0, egui::Color32::from_rgb(0, 120, 255)), egui::StrokeKind::Inside);
            }
        }

        // mouse wheel over a selected photo = zoom of the picture
        if resp.hovered() {
            let scroll = ui.ctx().input(|i| i.smooth_scroll_delta.y);
            if scroll != 0.0 {
                if let (Some(si), Some(pos)) = (self.sel, resp.hover_pos()) {
                    let (mx, my) = to_mm(pos);
                    let mut hit = false;
                    if let Some(l) = self.proj.pages[self.cur].layers.get_mut(si) {
                        if let LayerKind::Photo(p) = &mut l.kind {
                            if mx >= l.rect.x && mx <= l.rect.x + l.rect.w && my >= l.rect.y && my <= l.rect.y + l.rect.h {
                                p.zoom = (p.zoom * (1.0 + scroll * 0.002)).clamp(1.0, 5.0);
                                hit = true;
                            }
                        }
                    }
                    if hit {
                        self.touch();
                    }
                }
            }
        }

        if resp.drag_started() || resp.clicked() {
            if let Some(pos) = resp.interact_pointer_pos() {
                let (mx, my) = to_mm(pos);
                self.drag = Drag::None;
                if let Some(r) = sel_rect {
                    let corners = [(r.x, r.y), (r.x + r.w, r.y), (r.x, r.y + r.h), (r.x + r.w, r.y + r.h)];
                    for (ci, (cx, cy)) in corners.iter().enumerate() {
                        if ((mx - cx) * scale).abs() < 8.0 && ((my - cy) * scale).abs() < 8.0 {
                            self.drag = Drag::Resize { corner: ci };
                        }
                    }
                }
                if self.drag == Drag::None {
                    let layers = &self.proj.pages[self.cur].layers;
                    let inside = |l: &Layer| l.visible && !l.locked && mx >= l.rect.x && mx <= l.rect.x + l.rect.w && my >= l.rect.y && my <= l.rect.y + l.rect.h;
                    let on_sel_photo = self.photo_mode
                        && self.sel.and_then(|i| layers.get(i)).is_some_and(|l| matches!(l.kind, LayerKind::Photo(_)) && inside(l));
                    if on_sel_photo {
                        self.drag = Drag::PhotoPan;
                    } else {
                        let hit = (0..layers.len()).rev().find(|&i| inside(&layers[i]));
                        self.sel = hit;
                        if let Some(i) = hit {
                            let r = layers[i].rect;
                            self.drag = Drag::Move { dx: mx - r.x, dy: my - r.y };
                        }
                    }
                }
            }
        }
        if resp.dragged() && self.drag != Drag::None {
            if let (Some(pos), Some(si)) = (resp.interact_pointer_pos(), self.sel) {
                let (mx, my) = to_mm(pos);
                let (snap_on, g) = (self.snap, self.grid_mm);
                let delta = resp.drag_delta();
                if let Some(l) = self.proj.pages[self.cur].layers.get_mut(si) {
                    match self.drag {
                        Drag::Move { dx, dy } => {
                            l.rect.x = snap(mx - dx, snap_on, g);
                            l.rect.y = snap(my - dy, snap_on, g);
                        }
                        Drag::Resize { corner } => {
                            let (mx, my) = (snap(mx, snap_on, g), snap(my, snap_on, g));
                            let (x0, y0, x1, y1) = (l.rect.x, l.rect.y, l.rect.x + l.rect.w, l.rect.y + l.rect.h);
                            let (nx0, ny0, nx1, ny1) = match corner {
                                0 => (mx.min(x1 - 2.0), my.min(y1 - 2.0), x1, y1),
                                1 => (x0, my.min(y1 - 2.0), mx.max(x0 + 2.0), y1),
                                2 => (mx.min(x1 - 2.0), y0, x1, my.max(y0 + 2.0)),
                                _ => (x0, y0, mx.max(x0 + 2.0), my.max(y0 + 2.0)),
                            };
                            l.rect = RectMm { x: nx0, y: ny0, w: nx1 - nx0, h: ny1 - ny0 };
                        }
                        Drag::PhotoPan => {
                            if let LayerKind::Photo(p) = &mut l.kind {
                                let k = 2.0 * p.zoom.max(1.0);
                                p.pan_x = (p.pan_x - delta.x / scale / l.rect.w * k).clamp(-1.0, 1.0);
                                p.pan_y = (p.pan_y - delta.y / scale / l.rect.h * k).clamp(-1.0, 1.0);
                            }
                        }
                        Drag::None => {}
                    }
                    self.dirty = true;
                    self.edited = true;
                }
            }
        }
        if resp.drag_stopped() {
            self.drag = Drag::None;
            self.thumbs.remove(&self.cur);
        }
    }
}

impl eframe::App for App {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let ctx = ui.ctx().clone();
        self.keys(&ctx);
        egui::Panel::top("menu").show(ui, |ui| self.menu(ui));
        egui::Panel::bottom("status").show(ui, |ui| {
            ui.horizontal(|ui| {
                ui.label(&self.status);
                ui.separator();
                ui.label(crate::tf!("{}/{} oldal", self.cur + 1, self.proj.pages.len()));
            });
        });
        egui::Panel::left("left").default_size(250.0).show(ui, |ui| {
            egui::ScrollArea::vertical().show(ui, |ui| self.left_panel(ui));
        });
        egui::Panel::right("right").default_size(320.0).show(ui, |ui| {
            egui::ScrollArea::vertical().show(ui, |ui| self.props(ui));
        });
        egui::CentralPanel::default().show(ui, |ui| self.canvas(ui));
        // closing with unsaved changes asks first
        if ctx.input(|i| i.viewport().close_requested()) && !self.allow_close && self.is_modified() {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            self.pending = Some(Pending::Close);
        }
        self.unsaved_window(&ctx);
        if self.win.preview {
            self.preview_window(&ctx);
        }
        self.dialogs(&ctx);
        self.snapshot_if_edited(&ctx);
    }
}

pub fn run() -> eframe::Result {
    let opts = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default().with_inner_size([1500.0, 920.0]).with_title("CraftOffice PhotoCalendar"),
        ..Default::default()
    };
    eframe::run_native("CraftOffice PhotoCalendar", opts, Box::new(|_cc| Ok(Box::new(App::new()))))
}

/// Android entry, called from `android_main` (UNTESTED: needs the Android SDK/NDK to build).
#[cfg(target_os = "android")]
pub fn run_android(app: android_activity::AndroidApp) -> eframe::Result {
    if let Some(dir) = app.internal_data_path() {
        let _ = crate::config::ANDROID_DIR.set(dir);
    }
    let opts = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    eframe::run_native("CraftOffice PhotoCalendar", opts, Box::new(|_cc| Ok(Box::new(App::new()))))
}
