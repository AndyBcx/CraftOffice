//! Photo helpers: automatic crop (keeps the most detailed region in frame).
use image::DynamicImage;

/// Returns (zoom, pan_x, pan_y) for a photo layer so that the area with the most detail
/// (edge energy centroid) stays in the frame. `frame_ar` = frame width / height.
pub fn auto_crop(img: &DynamicImage, frame_ar: f32) -> (f32, f32, f32) {
    let g = img.thumbnail(96, 96).to_luma8();
    let (w, h) = (g.width() as i32, g.height() as i32);
    if w < 3 || h < 3 {
        return (1.0, 0.0, 0.0);
    }
    let (mut sx, mut sy, mut sum) = (0.0f64, 0.0f64, 0.0f64);
    for y in 1..h - 1 {
        for x in 1..w - 1 {
            let p = |dx: i32, dy: i32| g.get_pixel((x + dx) as u32, (y + dy) as u32).0[0] as f64;
            let gx = p(1, 0) - p(-1, 0);
            let gy = p(0, 1) - p(0, -1);
            let e = gx * gx + gy * gy;
            sx += e * x as f64;
            sy += e * y as f64;
            sum += e;
        }
    }
    if sum <= 0.0 {
        return (1.0, 0.0, 0.0);
    }
    let (cx, cy) = ((sx / sum) / w as f64, (sy / sum) / h as f64); // 0..1 centroid
    let img_ar = w as f32 / h as f32;
    // visible fraction of the image at zoom 1 (cover fit)
    let (vw, vh) = if img_ar > frame_ar { (frame_ar / img_ar, 1.0) } else { (1.0, img_ar / frame_ar) };
    let zoom = 1.25f32; // slight zoom so panning has an effect
    let (vw, vh) = (vw / zoom, vh / zoom);
    // pan so that the centroid is the centre of the view, clamped
    let pan = |c: f64, v: f32| -> f32 {
        let room = (1.0 - v).max(1e-4);
        (((c as f32 - 0.5) / (room * 0.5)).clamp(-1.0, 1.0)).max(-1.0)
    };
    (zoom, pan(cx, vw), pan(cy, vh))
}
