//! Dialog windows: wizard, settings, holidays, language editor, export/print, paper sizes,
//! collage and style manager.
use crate::cal::Lang;
use crate::gui::App;
use crate::gui_util::*;
use crate::holidays::{DateRule, Event, EventKind, HolidayGroup};
use crate::model::*;
use crate::raster;
use eframe::egui;

pub struct Wizard {
    pub kind: CalendarKind,
    pub tpl: usize,
    pub landscape: bool,
    pub size: PageSize,
    pub w: f32,
    pub h: f32,
    pub dpi: u32,
    pub year: i32,
    pub month: u32,
    pub lang: Lang,
    pub second: Option<Lang>,
    pub binding: Binding,
    pub layout: PageLayout,
    pub months: u32,
    pub photos: Vec<String>,
    previews: Vec<Option<egui::TextureHandle>>,
    prev_landscape: Option<bool>,
}

impl Wizard {
    pub fn new(year: i32) -> Wizard {
        let size = PageSize::presets().into_iter().find(|s| s.name == "A4").unwrap();
        Wizard {
            kind: CalendarKind::Spiral,
            tpl: 0,
            landscape: false,
            w: size.w_mm,
            h: size.h_mm,
            size,
            dpi: 300,
            year,
            month: 1,
            lang: Lang::Hu,
            second: None,
            binding: Binding::None,
            layout: PageLayout::SamePage,
            months: 12,
            photos: vec![],
            previews: vec![],
            prev_landscape: None,
        }
    }
}

fn lang_combo(ui: &mut egui::Ui, id: &str, v: &mut Lang) -> bool {
    let mut c = false;
    egui::ComboBox::from_id_salt(id).selected_text(v.label()).show_ui(ui, |ui| {
        for l in Lang::ALL {
            c |= ui.selectable_value(v, l, l.label()).changed();
        }
    });
    c
}

fn lang2_combo(ui: &mut egui::Ui, id: &str, v: &mut Option<Lang>) -> bool {
    let mut c = false;
    egui::ComboBox::from_id_salt(id).selected_text(v.map(|l| l.label()).unwrap_or("nincs")).show_ui(ui, |ui| {
        c |= ui.selectable_value(v, None, "nincs").changed();
        for l in Lang::ALL {
            c |= ui.selectable_value(v, Some(l), l.label()).changed();
        }
    });
    c
}

/// All paper sizes: built-in presets plus the user's own.
fn all_sizes(cfg: &crate::config::Config) -> Vec<PageSize> {
    let mut v = PageSize::presets();
    v.extend(cfg.paper_sizes.iter().cloned());
    v
}

impl App {
    pub(crate) fn dialogs(&mut self, ctx: &egui::Context) {
        if self.win.wizard {
            self.wizard_window(ctx);
        }
        if self.win.settings {
            self.settings_window(ctx);
        }
        if self.win.holidays {
            self.holiday_window(ctx);
        }
        if self.win.langs {
            self.lang_window(ctx);
        }
        if self.win.export {
            self.export_window(ctx);
        }
        if self.win.papers {
            self.paper_window(ctx);
        }
        if self.win.collage {
            self.collage_window(ctx);
        }
        if self.win.styles {
            self.style_window(ctx);
        }
    }

    // ---- wizard -------------------------------------------------------------------------

    fn wizard_previews(&mut self, ctx: &egui::Context) {
        let w = &mut self.wiz;
        if w.prev_landscape == Some(w.landscape) && w.previews.len() == crate::templates::names().len() {
            return;
        }
        w.previews.clear();
        let (pw, ph) = if w.landscape { (297.0, 210.0) } else { (210.0, 297.0) };
        let a4 = PageSize { name: "A4".into(), w_mm: 210.0, h_mm: 297.0 };
        let mut proj = Project::new_default(a4, w.landscape, 2027, 1, Lang::Hu);
        let mut cache = raster::ImageCache::new();
        for i in 0..crate::templates::names().len() {
            proj.pages[0] = crate::templates::build(i, pw, ph, Some((2027, 1)));
            let dl = crate::layout::render_page(&proj, 0, &|_: &str| None);
            let img = raster::rasterize(&dl, 6.0, 110, &mut cache);
            let ci = egui::ColorImage::from_rgba_unmultiplied([img.width() as usize, img.height() as usize], img.as_raw());
            w.previews.push(Some(ctx.load_texture(format!("wiz{i}"), ci, egui::TextureOptions::LINEAR)));
        }
        w.prev_landscape = Some(w.landscape);
    }

    fn wizard_create(&mut self) {
        let w = &self.wiz;
        let mut size = w.size.clone();
        size.w_mm = w.w;
        size.h_mm = w.h;
        let mut p = Project::new_default(size.clone(), w.landscape, w.year, w.month, w.lang);
        p.kind = w.kind;
        p.binding = w.binding;
        p.page_layout = w.layout;
        p.months = w.months;
        p.dpi = w.dpi;
        p.second_lang = w.second;
        p.rebuild_pages();
        let tpl = w.tpl;
        let photos = w.photos.clone();
        self.size_w = size.w_mm;
        self.size_h = size.h_mm;
        self.size_name = size.name.clone();
        self.proj = p;
        self.cur = 0;
        self.sel = None;
        let can_tpl = matches!(self.proj.kind, CalendarKind::Spiral | CalendarKind::Custom) && self.proj.page_layout == PageLayout::SamePage && self.proj.binding != Binding::SpiralCenter;
        if tpl > 0 && can_tpl {
            self.apply_builtin(tpl, true);
        }
        // photos into the photo slots, in order
        let mut it = photos.into_iter();
        for pg in self.proj.pages.iter_mut() {
            for l in pg.layers.iter_mut() {
                if let LayerKind::Photo(ph) = &mut l.kind {
                    if let Some(f) = it.next() {
                        ph.path = Some(f);
                    }
                }
            }
        }
        self.file = None;
        self.cache.clear();
        self.thumb_cache.clear();
        self.history.clear();
        self.redo.clear();
        self.last_snap = serde_json::to_string(&self.proj).unwrap_or_default();
        self.structure_changed();
        self.edited = false;
        self.status = crate::i18n::t("Új naptár létrehozva.").into();
    }

    fn wizard_window(&mut self, ctx: &egui::Context) {
        self.wizard_previews(ctx);
        let mut open = true;
        let mut create = false;
        let mut cancel = false;
        let sizes = all_sizes(&self.cfg);
        let inch = self.cfg.inch;
        egui::Window::new(crate::i18n::t("Új naptár")).open(&mut open).collapsible(false).anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0]).show(ctx, |ui| {
            ui.horizontal_top(|ui| {
              ui.vertical(|ui| {
                ui.set_width(360.0);
                ui.heading(crate::i18n::t("1. Naptártípus"));
                for k in KINDS {
                    ui.radio_value(&mut self.wiz.kind, k, kind_name(k));
                }
                if self.wiz.kind == CalendarKind::Spiral {
                    ui.horizontal(|ui| {
                        ui.radio_value(&mut self.wiz.layout, PageLayout::SamePage, crate::i18n::t("Fotó és rács egy oldalon"));
                    });
                    ui.radio_value(&mut self.wiz.layout, PageLayout::SeparatePages, crate::i18n::t("Fotó és rács külön oldalon"));
                }
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Kötés:"));
                    ui.radio_value(&mut self.wiz.binding, Binding::None, "nincs");
                    ui.radio_value(&mut self.wiz.binding, Binding::SpiralTop, crate::i18n::t("felső"));
                    ui.radio_value(&mut self.wiz.binding, Binding::SpiralCenter, crate::i18n::t("középső"));
                });
                ui.separator();
                ui.heading(crate::i18n::t("2. Méret és időszak"));
                egui::ComboBox::from_id_salt("wsize").selected_text(self.wiz.size.name.clone()).show_ui(ui, |ui| {
                    for s in &sizes {
                        if ui.selectable_label(self.wiz.size.name == s.name, &s.name).clicked() {
                            self.wiz.w = s.w_mm;
                            self.wiz.h = s.h_mm;
                            self.wiz.size = s.clone();
                        }
                    }
                });
                ui.horizontal(|ui| {
                    let (mut w, mut h) = (self.wiz.w, self.wiz.h);
                    len_edit(ui, &mut w, inch, 30.0..=2000.0);
                    ui.label("×");
                    len_edit(ui, &mut h, inch, 30.0..=2000.0);
                    if (w, h) != (self.wiz.w, self.wiz.h) {
                        self.wiz.w = w;
                        self.wiz.h = h;
                        self.wiz.size = PageSize { name: crate::i18n::t("Egyéni").into(), w_mm: w, h_mm: h };
                    }
                });
                ui.horizontal(|ui| {
                    ui.radio_value(&mut self.wiz.landscape, false, crate::i18n::t("Álló"));
                    ui.radio_value(&mut self.wiz.landscape, true, crate::i18n::t("Fekvő"));
                });
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Kezdés:"));
                    ui.add(egui::DragValue::new(&mut self.wiz.year).range(1900..=2099));
                    ui.add(egui::DragValue::new(&mut self.wiz.month).range(1..=12));
                    ui.label(crate::i18n::t("hónapok:"));
                    ui.add(egui::DragValue::new(&mut self.wiz.months).range(1..=36));
                });
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Felbontás:"));
                    egui::ComboBox::from_id_salt("wdpi").selected_text(format!("{} dpi", self.wiz.dpi)).show_ui(ui, |ui| {
                        for d in [72u32, 96, 200, 300, 600] {
                            ui.selectable_value(&mut self.wiz.dpi, d, format!("{d} dpi"));
                        }
                    });
                });
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Nyelv:"));
                    lang_combo(ui, "wlang", &mut self.wiz.lang);
                    ui.label(crate::i18n::t("második:"));
                    lang2_combo(ui, "wlang2", &mut self.wiz.second);
                });
                ui.separator();
                ui.heading(crate::i18n::t("3. Fotók"));
                ui.horizontal(|ui| {
                    if ui.button(crate::i18n::t("Fotók kiválasztása…")).clicked() {
                        let f = pick_images();
                        if !f.is_empty() {
                            self.wiz.photos = f;
                        }
                    }
                    ui.label(crate::tf!("{} kiválasztva", self.wiz.photos.len()));
                    if !self.wiz.photos.is_empty() && ui.small_button(crate::i18n::t("törlés")).clicked() {
                        self.wiz.photos.clear();
                    }
                });
                if self.wiz.kind == CalendarKind::Poster {
                    ui.small(crate::i18n::t("Poszternél az első fotó a főfotó."));
                }

              });
              ui.add_space(12.0);
              ui.vertical(|ui| {
                ui.set_width(400.0);
                ui.heading(crate::i18n::t("Sablon"));
                ui.small(if self.wiz.landscape { crate::i18n::t("Fekvő előnézetek") } else { crate::i18n::t("Álló előnézetek") });
                egui::ScrollArea::vertical().max_height(430.0).show(ui, |ui| {
                    ui.horizontal_wrapped(|ui| {
                        for (i, n) in crate::templates::names().iter().enumerate() {
                            ui.vertical(|ui| {
                                if let Some(Some(t)) = self.wiz.previews.get(i) {
                                    let sz = if self.wiz.landscape { egui::vec2(110.0, 78.0) } else { egui::vec2(78.0, 110.0) };
                                    let r = ui.add(egui::Image::new((t.id(), sz)).sense(egui::Sense::click()));
                                    if r.clicked() {
                                        self.wiz.tpl = i;
                                    }
                                }
                                ui.selectable_value(&mut self.wiz.tpl, i, crate::i18n::t(n));
                            });
                        }
                    });
                });
                if !matches!(self.wiz.kind, CalendarKind::Spiral | CalendarKind::Custom) || self.wiz.layout == PageLayout::SeparatePages || self.wiz.binding == Binding::SpiralCenter {
                    ui.small(crate::i18n::t("A sablon csak egy oldalas havi (spirál/egyéni, nem középső kötésű) naptárra érvényes."));
                }
              });
            });
            ui.separator();
            ui.horizontal(|ui| {
                if ui.button(crate::i18n::t("Létrehozás")).clicked() {
                    create = true;
                }
                if ui.button(crate::i18n::t("Mégse")).clicked() {
                    cancel = true;
                }
            });
        });
        if create {
            self.wizard_create();
            self.win.wizard = false;
        } else if cancel || !open {
            self.win.wizard = false;
        }
    }

    // ---- settings ---------------------------------------------------------------------------

    fn settings_window(&mut self, ctx: &egui::Context) {
        let mut open = self.win.settings;
        let sizes = all_sizes(&self.cfg);
        let inch = self.cfg.inch;
        egui::Window::new(crate::i18n::t("Naptár beállításai")).open(&mut open).show(ctx, |ui| {
            let mut rebuild = false;
            ui.small(crate::i18n::t("A méret / típus / kötés / hónapok módosítása újragenerálja az oldalakat (a fotók megmaradnak, az elrendezés alapra áll)."));
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Cím"));
                ui.text_edit_singleline(&mut self.proj.title);
            });
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Méret"));
                egui::ComboBox::from_id_salt("size").selected_text(self.proj.size.name.clone()).show_ui(ui, |ui| {
                    for s in &sizes {
                        if ui.selectable_label(self.proj.size.name == s.name, &s.name).clicked() {
                            self.size_w = s.w_mm;
                            self.size_h = s.h_mm;
                            self.proj.size = s.clone();
                            rebuild = true;
                        }
                    }
                });
            });
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Egyéni"));
                len_edit(ui, &mut self.size_w, inch, 30.0..=2000.0);
                ui.label("×");
                len_edit(ui, &mut self.size_h, inch, 30.0..=2000.0);
                if ui.button(crate::i18n::t("Alkalmaz")).clicked() {
                    let name = if inch { format!("{:.2}x{:.2} in", self.size_w / 25.4, self.size_h / 25.4) } else { format!("{:.0}x{:.0} mm", self.size_w, self.size_h) };
                    self.proj.size = PageSize { name, w_mm: self.size_w, h_mm: self.size_h };
                    rebuild = true;
                }
                if ui.button(crate::i18n::t("Mentés a listába")).clicked() {
                    let name = if inch { format!("{:.2}x{:.2} in", self.size_w / 25.4, self.size_h / 25.4) } else { format!("{:.0}x{:.0} mm", self.size_w, self.size_h) };
                    self.cfg.paper_sizes.push(PageSize { name, w_mm: self.size_w, h_mm: self.size_h });
                    self.cfg.save();
                }
            });
            ui.horizontal(|ui| {
                rebuild |= ui.radio_value(&mut self.proj.landscape, false, crate::i18n::t("Álló")).changed();
                rebuild |= ui.radio_value(&mut self.proj.landscape, true, crate::i18n::t("Fekvő")).changed();
                ui.checkbox(&mut self.cfg.inch, "inch");
            });
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Kezdő év"));
                rebuild |= ui.add(egui::DragValue::new(&mut self.proj.start_year).range(1900..=2099)).changed();
                ui.label(crate::i18n::t("hónap"));
                rebuild |= ui.add(egui::DragValue::new(&mut self.proj.start_month).range(1..=12)).changed();
                ui.label(crate::i18n::t("hónapok"));
                rebuild |= ui.add(egui::DragValue::new(&mut self.proj.months).range(1..=36)).changed();
            });
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Nyelv"));
                if lang_combo(ui, "lang", &mut self.proj.lang) {
                    self.touch();
                }
                ui.label(crate::i18n::t("második"));
                if lang2_combo(ui, "lang2", &mut self.proj.second_lang) {
                    self.touch();
                }
            });
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Felbontás"));
                egui::ComboBox::from_id_salt("dpi").selected_text(format!("{} dpi", self.proj.dpi)).show_ui(ui, |ui| {
                    for d in [72u32, 96, 150, 200, 300, 600] {
                        ui.selectable_value(&mut self.proj.dpi, d, format!("{d} dpi"));
                    }
                });
                ui.label(crate::i18n::t("Kifutó"));
                len_edit(ui, &mut self.proj.bleed_mm, inch, 0.0..=20.0);
            });
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Típus"));
                egui::ComboBox::from_id_salt("kind").selected_text(kind_name(self.proj.kind)).show_ui(ui, |ui| {
                    for k in KINDS {
                        rebuild |= ui.selectable_value(&mut self.proj.kind, k, kind_name(k)).changed();
                    }
                });
            });
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Kötés"));
                for (b, n) in [(Binding::None, crate::i18n::t("Nincs")), (Binding::SpiralTop, crate::i18n::t("Felső spirál")), (Binding::SpiralCenter, crate::i18n::t("Középső"))] {
                    rebuild |= ui.radio_value(&mut self.proj.binding, b, n).changed();
                }
            });
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Spirál-oldalak"));
                rebuild |= ui.radio_value(&mut self.proj.page_layout, PageLayout::SamePage, crate::i18n::t("Egy oldalon")).changed();
                rebuild |= ui.radio_value(&mut self.proj.page_layout, PageLayout::SeparatePages, crate::i18n::t("Külön oldalon")).changed();
            });
            if ui.button(crate::i18n::t("Újragenerálás")).clicked() {
                rebuild = true;
            }
            if rebuild {
                self.proj.rebuild_pages();
                self.cur = self.cur.min(self.proj.pages.len() - 1);
                self.sel = None;
                self.structure_changed();
            }
        });
        self.win.settings = open;
    }

    // ---- holidays ---------------------------------------------------------------------------

    fn holiday_window(&mut self, ctx: &egui::Context) {
        let mut open = self.win.holidays;
        let lang = self.proj.lang;
        let mut changed = false;
        let mut status: Option<String> = None;
        egui::Window::new(crate::i18n::t("Ünnepnapok")).open(&mut open).default_width(560.0).show(ctx, |ui| {
            ui.small(crate::i18n::t("Ellenőrizd a listát hivatalos forrással (különösen az évenként változó áthelyezett munkanapokat)."));
            // group bar
            ui.horizontal(|ui| {
                let n = self.proj.holiday_groups.len();
                self.hol_group = self.hol_group.min(n.saturating_sub(1));
                egui::ComboBox::from_id_salt("hg").selected_text(self.proj.holiday_groups.get(self.hol_group).map(|g| g.name.clone()).unwrap_or_default()).show_ui(ui, |ui| {
                    for i in 0..n {
                        let nm = self.proj.holiday_groups[i].name.clone();
                        ui.selectable_value(&mut self.hol_group, i, nm);
                    }
                });
                if ui.button(crate::i18n::t("Új csoport")).clicked() {
                    self.proj.holiday_groups.push(HolidayGroup::new(crate::i18n::t("Új csoport")));
                    self.hol_group = self.proj.holiday_groups.len() - 1;
                    changed = true;
                }
                if ui.button(crate::i18n::t("Másolás")).clicked() && n > 0 {
                    let mut g = self.proj.holiday_groups[self.hol_group].clone();
                    g.name.push_str(crate::i18n::t(" másolat"));
                    self.proj.holiday_groups.push(g);
                    self.hol_group = self.proj.holiday_groups.len() - 1;
                    changed = true;
                }
                if ui.button(crate::i18n::t("Törlés")).clicked() && n > 0 {
                    self.proj.holiday_groups.remove(self.hol_group);
                    changed = true;
                }
            });
            ui.horizontal(|ui| {
                if ui.button(crate::i18n::t("Export CSV…")).clicked() {
                    if let Some(p) = crate::platform::FileDialog::new().add_filter(crate::i18n::t("CSV"), &["csv"]).set_file_name("unnepek.csv").save_file() {
                        status = Some(match std::fs::write(&p, crate::holidays::export_csv(&self.proj.holiday_groups)) {
                            Ok(_) => crate::tf!("Exportálva: {}", p.display()),
                            Err(e) => crate::tf!("Hiba: {}", e),
                        });
                    }
                }
                if ui.button(crate::i18n::t("Import CSV / Excel…")).clicked() {
                    if let Some(p) = crate::platform::FileDialog::new().add_filter(crate::i18n::t("CSV / Excel"), &["csv", "xlsx", "xls", "ods"]).pick_file() {
                        let is_csv = p.extension().and_then(|e| e.to_str()).map(|e| e.eq_ignore_ascii_case("csv")).unwrap_or(false);
                        let res = if is_csv {
                            std::fs::read_to_string(&p).map(|t| crate::holidays::import_csv(&t)).map_err(|e| e.to_string())
                        } else {
                            crate::holidays::import_excel(&p)
                        };
                        match res {
                            Ok(g) => {
                                status = Some(crate::tf!("{} csoport importálva.", g.len()));
                                self.proj.holiday_groups.extend(g);
                                changed = true;
                            }
                            Err(e) => status = Some(crate::tf!("Import hiba: {}", e)),
                        }
                    }
                }
                ui.small(crate::i18n::t("Oszlopok: csoport; fajta(off|work|anniv); név HU; RO; EN; szabály; a; b; c"));
            });
            ui.separator();
            if let Some(g) = self.proj.holiday_groups.get_mut(self.hol_group) {
                ui.horizontal(|ui| {
                    changed |= ui.checkbox(&mut g.enabled, crate::i18n::t("Bekapcsolva")).changed();
                    changed |= ui.text_edit_singleline(&mut g.name).changed();
                });
                ui.horizontal(|ui| {
                    ui.label(crate::i18n::t("Csoport betűszíne"));
                    let mut on = g.font_color.is_some();
                    if ui.checkbox(&mut on, "").changed() {
                        g.font_color = if on { Some(Rgba::RED) } else { None };
                        changed = true;
                    }
                    if let Some(c) = &mut g.font_color {
                        changed |= rgba_edit(ui, c);
                    }
                    ui.label(crate::i18n::t("cellaszín"));
                    let mut on = g.cell_color.is_some();
                    if ui.checkbox(&mut on, "").changed() {
                        g.cell_color = if on { Some(Rgba(255, 235, 235, 255)) } else { None };
                        changed = true;
                    }
                    if let Some(c) = &mut g.cell_color {
                        changed |= rgba_edit(ui, c);
                    }
                });
                ui.horizontal(|ui| {
                    let mk = |name: &str, kind: EventKind, rule: DateRule| Event {
                        names: vec![(Lang::Hu, name.into()), (Lang::Ro, name.into()), (Lang::En, name.into())],
                        kind,
                        rule,
                        font_color: None,
                        cell_color: None,
                        photo: None,
                        from_year: None,
                    };
                    if ui.button(crate::i18n::t("+ Ünnep")).clicked() {
                        g.events.push(mk(crate::i18n::t("Új ünnep"), EventKind::DayOff, DateRule::Fixed { month: 1, day: 1 }));
                        changed = true;
                    }
                    if ui.button(crate::i18n::t("+ Ismétlődő esemény")).clicked() {
                        g.events.push(mk(crate::i18n::t("Új esemény"), EventKind::Workday, DateRule::Fixed { month: 1, day: 1 }));
                        changed = true;
                    }
                    if ui.button(crate::i18n::t("+ Születésnap / évforduló")).clicked() {
                        g.events.push(mk(crate::i18n::t("Születésnap"), EventKind::Anniversary, DateRule::Fixed { month: 1, day: 1 }));
                        changed = true;
                    }
                });
                egui::ScrollArea::vertical().max_height(380.0).show(ui, |ui| {
                    let mut del = None;
                    for (ei, e) in g.events.iter_mut().enumerate() {
                        egui::CollapsingHeader::new(format!("{} – {}", e.name(lang), rule_text(&e.rule))).id_salt(format!("ev{ei}")).show(ui, |ui| {
                            for l in [Lang::Hu, Lang::Ro, Lang::En] {
                                ui.horizontal(|ui| {
                                    ui.label(l.label());
                                    if !e.names.iter().any(|(x, _)| *x == l) {
                                        e.names.push((l, String::new()));
                                    }
                                    if let Some((_, nm)) = e.names.iter_mut().find(|(x, _)| *x == l) {
                                        changed |= ui.text_edit_singleline(nm).changed();
                                    }
                                });
                            }
                            ui.horizontal(|ui| {
                                egui::ComboBox::from_id_salt(format!("k{ei}"))
                                    .selected_text(match e.kind {
                                        EventKind::DayOff => crate::i18n::t("Szabadnap"),
                                        EventKind::Workday => crate::i18n::t("Munkanap"),
                                        EventKind::Anniversary => crate::i18n::t("Évforduló"),
                                    })
                                    .show_ui(ui, |ui| {
                                        changed |= ui.selectable_value(&mut e.kind, EventKind::DayOff, crate::i18n::t("Szabadnap")).changed();
                                        changed |= ui.selectable_value(&mut e.kind, EventKind::Workday, crate::i18n::t("Munkanap")).changed();
                                        changed |= ui.selectable_value(&mut e.kind, EventKind::Anniversary, crate::i18n::t("Évforduló")).changed();
                                    });
                                changed |= rule_edit(ui, ei, &mut e.rule);
                            });
                            ui.horizontal(|ui| {
                                let mut on = e.from_year.is_some();
                                if ui.checkbox(&mut on, crate::i18n::t("érvényes ettől az évtől")).changed() {
                                    e.from_year = if on { Some(2026) } else { None };
                                    changed = true;
                                }
                                if let Some(y) = &mut e.from_year {
                                    changed |= ui.add(egui::DragValue::new(y).range(1900..=2099)).changed();
                                }
                            });
                            ui.horizontal(|ui| {
                                ui.label(crate::i18n::t("Betűszín"));
                                let mut on = e.font_color.is_some();
                                if ui.checkbox(&mut on, "").changed() {
                                    e.font_color = if on { Some(Rgba::RED) } else { None };
                                    changed = true;
                                }
                                if let Some(c) = &mut e.font_color {
                                    changed |= rgba_edit(ui, c);
                                }
                                ui.label(crate::i18n::t("cellaszín"));
                                let mut on = e.cell_color.is_some();
                                if ui.checkbox(&mut on, "").changed() {
                                    e.cell_color = if on { Some(Rgba(255, 235, 235, 255)) } else { None };
                                    changed = true;
                                }
                                if let Some(c) = &mut e.cell_color {
                                    changed |= rgba_edit(ui, c);
                                }
                            });
                            ui.horizontal(|ui| {
                                ui.label(e.photo.clone().unwrap_or_else(|| crate::i18n::t("nincs fotó").into()));
                                if ui.small_button(crate::i18n::t("Fotó…")).clicked() {
                                    if let Some(f) = pick_image() {
                                        e.photo = Some(f);
                                        changed = true;
                                    }
                                }
                                if e.photo.is_some() && ui.small_button("✖").clicked() {
                                    e.photo = None;
                                    changed = true;
                                }
                            });
                            if ui.button(crate::i18n::t("Esemény törlése")).clicked() {
                                del = Some(ei);
                            }
                        });
                    }
                    if let Some(d) = del {
                        g.events.remove(d);
                        changed = true;
                    }
                });
            }
        });
        self.win.holidays = open;
        if let Some(s) = status {
            self.status = s;
        }
        if changed {
            self.structure_changed();
        }
    }

    // ---- language editor ----------------------------------------------------------------------

    fn lang_window(&mut self, ctx: &egui::Context) {
        let mut open = self.win.langs;
        let mut changed = false;
        egui::Window::new(crate::i18n::t("Nyelvszerkesztő")).open(&mut open).show(ctx, |ui| {
            ui.small(crate::i18n::t("A hónap- és napnevek átírhatók nyelvenként; a változtatás a projektben marad."));
            let mut cur = Lang::ALL[self.lang_edit.min(Lang::ALL.len() - 1)];
            egui::ComboBox::from_id_salt("le").selected_text(cur.label()).show_ui(ui, |ui| {
                for l in Lang::ALL {
                    ui.selectable_value(&mut cur, l, l.label());
                }
            });
            self.lang_edit = cur.idx();
            let has = self.proj.lang_overrides.iter().any(|o| o.lang == cur);
            ui.horizontal(|ui| {
                if !has && ui.button(crate::i18n::t("Szerkesztés indítása")).clicked() {
                    self.proj.lang_overrides.push(LangOverride::from_builtin(cur));
                    changed = true;
                }
                if has && ui.button(crate::i18n::t("Visszaállítás alapra")).clicked() {
                    self.proj.lang_overrides.retain(|o| o.lang != cur);
                    changed = true;
                }
            });
            if let Some(o) = self.proj.lang_overrides.iter_mut().find(|o| o.lang == cur) {
                egui::ScrollArea::vertical().max_height(420.0).show(ui, |ui| {
                    ui.label(crate::i18n::t("Hónapok"));
                    egui::Grid::new("lm").num_columns(2).show(ui, |ui| {
                        for (i, m) in o.months.iter_mut().enumerate() {
                            ui.label(format!("{}.", i + 1));
                            changed |= ui.text_edit_singleline(m).changed();
                            ui.end_row();
                        }
                    });
                    ui.label(crate::i18n::t("Napok (hétfőtől): rövid / teljes"));
                    egui::Grid::new("ld").num_columns(3).show(ui, |ui| {
                        for i in 0..7 {
                            ui.label(format!("{}.", i + 1));
                            changed |= ui.text_edit_singleline(&mut o.weekdays_short[i]).changed();
                            changed |= ui.text_edit_singleline(&mut o.weekdays[i]).changed();
                            ui.end_row();
                        }
                    });
                    ui.horizontal(|ui| {
                        ui.label(crate::i18n::t("Hét rövidítése"));
                        changed |= ui.text_edit_singleline(&mut o.week_short).changed();
                    });
                });
            }
        });
        self.win.langs = open;
        if changed {
            self.structure_changed();
        }
    }

    // ---- export / print -----------------------------------------------------------------------

    fn export_window(&mut self, ctx: &egui::Context) {
        let mut open = self.win.export;
        let sizes = all_sizes(&self.cfg);
        let inch = self.cfg.inch;
        let mut act = 0;
        egui::Window::new(crate::i18n::t("Export és nyomtatás")).open(&mut open).show(ctx, |ui| {
            let n = self.proj.pages.len();
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Papír"));
                let cur = self.proj.export.paper.as_ref().map(|p| p.name.clone()).unwrap_or_else(|| crate::i18n::t("Oldalméret (1 oldal = 1 lap)").into());
                egui::ComboBox::from_id_salt("paper").selected_text(cur).show_ui(ui, |ui| {
                    if ui.selectable_label(self.proj.export.paper.is_none(), crate::i18n::t("Oldalméret (1 oldal = 1 lap)")).clicked() {
                        self.proj.export.paper = None;
                    }
                    for s in &sizes {
                        if ui.selectable_label(self.proj.export.paper.as_ref().map(|p| &p.name) == Some(&s.name), &s.name).clicked() {
                            self.proj.export.paper = Some(s.clone());
                        }
                    }
                });
                if ui.small_button(crate::i18n::t("Papírméretek…")).clicked() {
                    self.win.papers = true;
                }
            });
            if self.proj.export.paper.is_some() {
                ui.horizontal(|ui| {
                    ui.radio_value(&mut self.proj.export.paper_landscape, false, crate::i18n::t("Álló papír"));
                    ui.radio_value(&mut self.proj.export.paper_landscape, true, crate::i18n::t("Fekvő papír"));
                });
                ui.checkbox(&mut self.proj.export.fit_pages, crate::i18n::t("Nagy oldalak kicsinyítése a papírra (arányosan)"));
                ui.small(crate::i18n::t("A papírméret nagyobb, mint az oldal: több oldal kerül egy lapra (margó és térköz szerint)."));
            }
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Margó"));
                len_edit(ui, &mut self.proj.export.margin_mm, inch, 0.0..=50.0);
                ui.label(crate::i18n::t("térköz"));
                len_edit(ui, &mut self.proj.export.spacing_mm, inch, 0.0..=50.0);
                ui.label(crate::i18n::t("kifutó"));
                len_edit(ui, &mut self.proj.bleed_mm, inch, 0.0..=20.0);
            });
            ui.checkbox(&mut self.proj.export.crop_marks, crate::i18n::t("Nyomtatási jelek (vágójelek)"));
            ui.checkbox(&mut self.proj.export.cmyk, crate::i18n::t("CMYK elrendezés (a vektor- és szövegszínek CMYK-ra, a fotók RGB-ben maradnak)"));
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Oldaltartomány"));
                ui.text_edit_singleline(&mut self.proj.export.page_range);
                ui.small(crate::tf!("pl. 1,3,5-12 (összesen {} oldal)", n));
            });
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Példányszám"));
                ui.add(egui::DragValue::new(&mut self.proj.export.copies).range(1..=99));
                ui.label(crate::i18n::t("felbontás"));
                egui::ComboBox::from_id_salt("edpi").selected_text(format!("{} dpi", self.proj.dpi)).show_ui(ui, |ui| {
                    for d in [72u32, 96, 150, 200, 300, 600] {
                        ui.selectable_value(&mut self.proj.dpi, d, format!("{d} dpi"));
                    }
                });
                ui.label(crate::i18n::t("JPEG"));
                ui.add(egui::DragValue::new(&mut self.proj.export.jpeg_quality).range(10..=100));
            });
            ui.separator();
            ui.horizontal(|ui| {
                if ui.button(crate::i18n::t("PDF mentése…")).clicked() {
                    act = 1;
                }
                if ui.button(crate::i18n::t("Nyomtatás a nyomtatóra")).clicked() {
                    act = 2;
                }
                if ui.button(crate::i18n::t("Képek (PNG/JPEG)…")).clicked() {
                    act = 3;
                }
            });
            ui.separator();
            ui.label(crate::i18n::t("Beállítás-készletek:"));
            ui.horizontal(|ui| {
                ui.text_edit_singleline(&mut self.preset_name);
                if ui.button(crate::i18n::t("Mentés")).clicked() {
                    self.cfg.export_presets.push((self.preset_name.clone(), self.proj.export.clone()));
                    self.cfg.save();
                }
            });
            let mut load = None;
            let mut del = None;
            for (i, (name, _)) in self.cfg.export_presets.iter().enumerate() {
                ui.horizontal(|ui| {
                    ui.label(name);
                    if ui.small_button(crate::i18n::t("Betöltés")).clicked() {
                        load = Some(i);
                    }
                    if ui.small_button("✖").clicked() {
                        del = Some(i);
                    }
                });
            }
            if let Some(i) = load {
                self.proj.export = self.cfg.export_presets[i].1.clone();
            }
            if let Some(i) = del {
                self.cfg.export_presets.remove(i);
                self.cfg.save();
            }
        });
        self.win.export = open;
        match act {
            1 => self.export_pdf(),
            2 => self.print_now(),
            3 => self.export_image(true),
            _ => {}
        }
    }

    // ---- paper sizes ------------------------------------------------------------------------------

    fn paper_window(&mut self, ctx: &egui::Context) {
        let mut open = self.win.papers;
        let inch = self.cfg.inch;
        let mut changed = false;
        egui::Window::new(crate::i18n::t("Papírméretek")).open(&mut open).show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Mértékegység:"));
                changed |= ui.radio_value(&mut self.cfg.inch, false, "mm").changed();
                changed |= ui.radio_value(&mut self.cfg.inch, true, "inch").changed();
            });
            ui.label(crate::i18n::t("Beépített méretek:"));
            for s in PageSize::presets() {
                ui.label(format!("{} – {:.1} × {:.1} mm", s.name, s.w_mm, s.h_mm));
            }
            ui.separator();
            ui.label(crate::i18n::t("Saját méretek:"));
            let mut del = None;
            for (i, s) in self.cfg.paper_sizes.iter_mut().enumerate() {
                ui.horizontal(|ui| {
                    changed |= ui.text_edit_singleline(&mut s.name).changed();
                    changed |= len_edit(ui, &mut s.w_mm, inch, 20.0..=3000.0);
                    ui.label("×");
                    changed |= len_edit(ui, &mut s.h_mm, inch, 20.0..=3000.0);
                    if ui.small_button("✖").clicked() {
                        del = Some(i);
                    }
                });
            }
            if let Some(i) = del {
                self.cfg.paper_sizes.remove(i);
                changed = true;
            }
            if ui.button(crate::i18n::t("+ Új méret")).clicked() {
                self.cfg.paper_sizes.push(PageSize { name: crate::i18n::t("Új méret").into(), w_mm: 200.0, h_mm: 280.0 });
                changed = true;
            }
        });
        self.win.papers = open;
        if changed {
            self.cfg.save();
        }
    }

    // ---- collage / styles --------------------------------------------------------------------------

    fn collage_window(&mut self, ctx: &egui::Context) {
        let mut open = self.win.collage;
        let mut create = false;
        egui::Window::new(crate::i18n::t("Fotókollázs")).open(&mut open).show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label(crate::i18n::t("Fotók száma"));
                ui.add(egui::DragValue::new(&mut self.collage_n).range(1..=9));
            });
            ui.horizontal(|ui| {
                if ui.button(crate::i18n::t("Fotók kiválasztása…")).clicked() {
                    self.collage_photos = pick_images();
                }
                ui.label(crate::tf!("{} kiválasztva", self.collage_photos.len()));
            });
            if ui.button(crate::i18n::t("Létrehozás az oldalon")).clicked() {
                create = true;
            }
        });
        if create {
            let photos = self.collage_photos.clone();
            self.add_collage(&photos, self.collage_n);
            open = false;
        }
        self.win.collage = open;
    }

    fn style_window(&mut self, ctx: &egui::Context) {
        let mut open = self.win.styles;
        let mut del = None;
        egui::Window::new(crate::i18n::t("Hónapstílusok")).open(&mut open).show(ctx, |ui| {
            ui.small(crate::i18n::t("Stílus alkalmazása: jelölj ki egy naptárrács-réteget, és a jobb oldali panelen válassz stílust. Új stílus ugyanott menthető."));
            ui.label(crate::i18n::t("Beépített:"));
            for s in crate::styles::builtin() {
                ui.label(format!("{} › {}", crate::i18n::tr(&s.category), crate::i18n::tr(&s.name)));
            }
            ui.separator();
            ui.label(crate::i18n::t("Saját:"));
            for (i, s) in self.cfg.styles.iter_mut().enumerate() {
                ui.horizontal(|ui| {
                    ui.label(&s.category);
                    ui.text_edit_singleline(&mut s.name);
                    if ui.small_button("✖").clicked() {
                        del = Some(i);
                    }
                });
            }
        });
        if let Some(i) = del {
            self.cfg.styles.remove(i);
            self.cfg.save();
        }
        self.win.styles = open;
    }
}

fn rule_text(r: &DateRule) -> String {
    match *r {
        DateRule::Fixed { month, day } => format!("{month}.{day}."),
        DateRule::Once { year, month, day } => format!("{year}.{month}.{day}."),
        DateRule::NthWeekday { month, nth, weekday } => crate::tf!("{}. hó {}. {}", month, nth, crate::i18n::t(["hétfő", "kedd", "szerda", "csütörtök", "péntek", "szombat", "vasárnap"][weekday as usize % 7])),
        DateRule::EasterWestern(o) => crate::tf!("Húsvét {} nap", format!("{o:+}")),
        DateRule::EasterOrthodox(o) => crate::tf!("Ortodox húsvét {} nap", format!("{o:+}")),
    }
}

fn rule_edit(ui: &mut egui::Ui, id: usize, r: &mut DateRule) -> bool {
    let mut changed = false;
    let mut kind = match r {
        DateRule::Fixed { .. } => 0,
        DateRule::Once { .. } => 1,
        DateRule::NthWeekday { .. } => 2,
        DateRule::EasterWestern(_) => 3,
        DateRule::EasterOrthodox(_) => 4,
    };
    let k0 = kind;
    let names = [crate::i18n::t("Minden évben (nap.hónap)"), crate::i18n::t("Egyszeri dátum"), crate::i18n::t("Hónap n-edik hétköznapja"), crate::i18n::t("Húsvét + n nap"), crate::i18n::t("Ortodox húsvét + n nap")];
    egui::ComboBox::from_id_salt(format!("rk{id}")).selected_text(names[kind]).show_ui(ui, |ui| {
        for (i, n) in names.iter().enumerate() {
            ui.selectable_value(&mut kind, i, *n);
        }
    });
    if kind != k0 {
        *r = match kind {
            0 => DateRule::Fixed { month: 1, day: 1 },
            1 => DateRule::Once { year: 2027, month: 1, day: 1 },
            2 => DateRule::NthWeekday { month: 1, nth: 1, weekday: 0 },
            3 => DateRule::EasterWestern(0),
            _ => DateRule::EasterOrthodox(0),
        };
        changed = true;
    }
    match r {
        DateRule::Fixed { month, day } => {
            changed |= ui.add(egui::DragValue::new(month).range(1..=12).prefix("hó ")).changed();
            changed |= ui.add(egui::DragValue::new(day).range(1..=31).prefix("nap ")).changed();
        }
        DateRule::Once { year, month, day } => {
            changed |= ui.add(egui::DragValue::new(year).range(1900..=2099)).changed();
            changed |= ui.add(egui::DragValue::new(month).range(1..=12)).changed();
            changed |= ui.add(egui::DragValue::new(day).range(1..=31)).changed();
        }
        DateRule::NthWeekday { month, nth, weekday } => {
            changed |= ui.add(egui::DragValue::new(month).range(1..=12).prefix("hó ")).changed();
            changed |= ui.add(egui::DragValue::new(nth).range(1..=5).prefix("n=")).changed();
            changed |= ui.add(egui::DragValue::new(weekday).range(0..=6).prefix(crate::i18n::t("hétköznap (0=hétfő) "))).changed();
        }
        DateRule::EasterWestern(o) | DateRule::EasterOrthodox(o) => {
            changed |= ui.add(egui::DragValue::new(o).range(-120..=120).suffix(" nap")).changed();
        }
    }
    changed
}
