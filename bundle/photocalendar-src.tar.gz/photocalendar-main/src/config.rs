//! Per-user settings stored next to the templates: custom paper sizes, saved month styles,
//! user templates and export presets.
use crate::model::*;
use crate::styles::NamedStyle;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct Config {
    #[serde(default)]
    pub templates: Vec<Template>,
    #[serde(default)]
    pub paper_sizes: Vec<PageSize>,
    #[serde(default)]
    pub styles: Vec<NamedStyle>,
    #[serde(default)]
    pub export_presets: Vec<(String, ExportSettings)>,
    /// true = show sizes in inches
    #[serde(default)]
    pub inch: bool,
    /// user-interface language
    #[serde(default)]
    pub ui_lang: crate::i18n::UiLang,
}

/// Internal storage directory handed over by the Android activity.
#[cfg(target_os = "android")]
pub static ANDROID_DIR: std::sync::OnceLock<PathBuf> = std::sync::OnceLock::new();

pub fn dir() -> PathBuf {
    #[cfg(target_os = "android")]
    {
        if let Some(d) = ANDROID_DIR.get() {
            return d.join("photocalendar");
        }
    }
    let base = std::env::var_os("APPDATA")
        .map(PathBuf::from)
        .or_else(|| std::env::var_os("XDG_CONFIG_HOME").map(PathBuf::from))
        .or_else(|| std::env::var_os("HOME").map(|h| PathBuf::from(h).join(".config")))
        .unwrap_or_else(|| PathBuf::from("."));
    base.join("photocalendar")
}

pub fn path() -> PathBuf {
    dir().join("config.json")
}

impl Config {
    pub fn load() -> Config {
        let existing = std::fs::read_to_string(path()).ok().and_then(|s| serde_json::from_str::<Config>(&s).ok());
        let first_run = existing.is_none();
        let mut cfg: Config = existing.unwrap_or_default();
        if first_run {
            // first start: pick the UI language from the system locale
            let loc = std::env::var("LC_ALL").or_else(|_| std::env::var("LANG")).unwrap_or_default().to_lowercase();
            cfg.ui_lang = if loc.starts_with("ro") { crate::i18n::UiLang::Ro } else if loc.starts_with("en") { crate::i18n::UiLang::En } else { crate::i18n::UiLang::Hu };
        }
        // migrate the old templates.json
        if cfg.templates.is_empty() {
            if let Some(t) = std::fs::read_to_string(dir().join("templates.json")).ok().and_then(|s| serde_json::from_str(&s).ok()) {
                cfg.templates = t;
            }
        }
        cfg
    }

    pub fn save(&self) {
        let _ = std::fs::create_dir_all(dir());
        if let Ok(s) = serde_json::to_string_pretty(self) {
            let _ = std::fs::write(path(), s);
        }
    }
}

pub const MM_PER_INCH: f32 = 25.4;
