fn main() -> eframe::Result {
    photocalendar::gui::run()
}
