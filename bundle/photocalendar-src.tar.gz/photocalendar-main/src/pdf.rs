//! Vector PDF export of DrawLists (any page size). Text is embedded (Liberation Sans),
//! photos are cropped and downsampled to the target DPI and stored as JPEG.
use crate::draw::{Cmd, DrawList};
use crate::font;
use crate::model::{Align, Rgba};
use crate::raster::ImageCache;
use ab_glyph::{Font as _, ScaleFont};
use printpdf::*;
use std::collections::HashMap;

const MM_PT: f32 = 72.0 / 25.4;

static CMYK: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

fn col(c: Rgba) -> Color {
    if CMYK.load(std::sync::atomic::Ordering::Relaxed) {
        // naive RGB -> CMYK (no colour profile); good enough for print previews, not for colour-critical work
        let (r, g, b) = (c.0 as f32 / 255.0, c.1 as f32 / 255.0, c.2 as f32 / 255.0);
        let k = 1.0 - r.max(g).max(b);
        let d = (1.0 - k).max(1e-6);
        return Color::Cmyk(Cmyk { c: (1.0 - r - k) / d, m: (1.0 - g - k) / d, y: (1.0 - b - k) / d, k, icc_profile: None });
    }
    Color::Rgb(Rgb { r: c.0 as f32 / 255.0, g: c.1 as f32 / 255.0, b: c.2 as f32 / 255.0, icc_profile: None })
}

struct Ctx<'a> {
    doc: PdfDocument,
    /// The embedded fonts, by (family, bold) as asked for in the drawing.
    fonts: HashMap<(String, bool), FontId>,
    alphas: HashMap<u8, ExtendedGraphicsStateId>,
    images: HashMap<String, XObjectId>,
    cache: &'a mut ImageCache,
    dpi: f32,
}

impl Ctx<'_> {
    /// The PDF font for a family: embedded once, on first use.
    fn font_id(&mut self, family: &str, bold: bool) -> FontId {
        let key = (family.to_string(), bold);
        if let Some(id) = self.fonts.get(&key) {
            return id.clone();
        }
        let face = font::pdf_face(family, bold);
        let parsed = ParsedFont::from_bytes(face.data, 0, &mut Vec::new())
            .or_else(|| ParsedFont::from_bytes(if bold { font::BOLD_TTF } else { font::REGULAR_TTF }, 0, &mut Vec::new()))
            .expect("font");
        let id = self.doc.add_font(&parsed);
        self.fonts.insert(key, id.clone());
        id
    }

    fn alpha_gs(&mut self, a: u8) -> ExtendedGraphicsStateId {
        if let Some(id) = self.alphas.get(&a) {
            return id.clone();
        }
        let f = a as f32 / 255.0;
        let gs = ExtendedGraphicsState::default().with_current_fill_alpha(f).with_current_stroke_alpha(f);
        let id = self.doc.add_graphics_state(gs);
        self.alphas.insert(a, id.clone());
        id
    }
}

fn pt(h_mm: f32, x_mm: f32, y_mm: f32) -> Point {
    Point { x: Pt(x_mm * MM_PT), y: Pt((h_mm - y_mm) * MM_PT) }
}

fn lp(p: Point) -> LinePoint {
    LinePoint { p, bezier: false }
}

fn with_alpha(ctx: &mut Ctx, ops: &mut Vec<Op>, a: u8, body: impl FnOnce(&mut Vec<Op>)) {
    if a < 255 {
        let gs = ctx.alpha_gs(a);
        ops.push(Op::SaveGraphicsState);
        ops.push(Op::LoadGraphicsState { gs });
        body(ops);
        ops.push(Op::RestoreGraphicsState);
    } else {
        body(ops);
    }
}

fn rect_ops(h: f32, r: crate::model::RectMm, mode: PaintMode) -> Op {
    Op::DrawRectangle {
        rectangle: printpdf::Rect {
            x: Pt(r.x * MM_PT),
            y: Pt((h - r.y - r.h) * MM_PT),
            width: Pt(r.w * MM_PT),
            height: Pt(r.h * MM_PT),
            mode: Some(mode),
            winding_order: None,
        },
    }
}

fn page_ops(ctx: &mut Ctx, dl: &DrawList) -> Vec<Op> {
    cmds_ops(ctx, &dl.cmds, dl.h_mm)
}

fn cmds_ops(ctx: &mut Ctx, cmds: &[Cmd], h: f32) -> Vec<Op> {
    let mut ops: Vec<Op> = Vec::new();
    for cmd in cmds {
        match cmd {
            Cmd::Group { rot_deg, cx, cy, cmds: inner } => {
                let phi = -rot_deg.to_radians();
                let (sn, cs) = phi.sin_cos();
                let (px, py) = (cx * MM_PT, (h - cy) * MM_PT);
                ops.push(Op::SaveGraphicsState);
                ops.push(Op::SetTransformationMatrix { matrix: CurTransMat::Raw([cs, sn, -sn, cs, px - px * cs + py * sn, py - px * sn - py * cs]) });
                let inner_ops = cmds_ops(ctx, inner, h);
                ops.extend(inner_ops);
                ops.push(Op::RestoreGraphicsState);
            }
            Cmd::Rect { r, fill, stroke } => {
                if let Some(c) = fill {
                    with_alpha(ctx, &mut ops, c.3, |ops| {
                        ops.push(Op::SetFillColor { col: col(*c) });
                        ops.push(rect_ops(h, *r, PaintMode::Fill));
                    });
                }
                if let Some((c, w)) = stroke {
                    with_alpha(ctx, &mut ops, c.3, |ops| {
                        ops.push(Op::SetOutlineColor { col: col(*c) });
                        ops.push(Op::SetOutlineThickness { pt: Pt(w * MM_PT) });
                        ops.push(rect_ops(h, *r, PaintMode::Stroke));
                    });
                }
            }
            Cmd::Gradient { r, from, to, vertical } => {
                // Approximated by thin solid strips (vector, resolution independent enough).
                let n = 96;
                for i in 0..n {
                    let t = (i as f32 + 0.5) / n as f32;
                    let m = |a: u8, b: u8| (a as f32 + (b as f32 - a as f32) * t) as u8;
                    let c = Rgba(m(from.0, to.0), m(from.1, to.1), m(from.2, to.2), m(from.3, to.3));
                    let strip = if *vertical {
                        crate::model::RectMm { x: r.x, y: r.y + r.h * i as f32 / n as f32, w: r.w, h: r.h / n as f32 + 0.05 }
                    } else {
                        crate::model::RectMm { x: r.x + r.w * i as f32 / n as f32, y: r.y, w: r.w / n as f32 + 0.05, h: r.h }
                    };
                    with_alpha(ctx, &mut ops, c.3, |ops| {
                        ops.push(Op::SetFillColor { col: col(c) });
                        ops.push(rect_ops(h, strip, PaintMode::Fill));
                    });
                }
            }
            Cmd::Ellipse { r, fill, stroke } => {
                let n = 72;
                let (cx, cy, rx, ry) = (r.x + r.w / 2.0, r.y + r.h / 2.0, r.w / 2.0, r.h / 2.0);
                let pts: Vec<LinePoint> = (0..n)
                    .map(|i| {
                        let a = i as f32 / n as f32 * std::f32::consts::TAU;
                        lp(pt(h, cx + rx * a.cos(), cy + ry * a.sin()))
                    })
                    .collect();
                let poly = |mode| Polygon { rings: vec![PolygonRing { points: pts.clone() }], mode, winding_order: WindingOrder::NonZero };
                if let Some(c) = fill {
                    with_alpha(ctx, &mut ops, c.3, |ops| {
                        ops.push(Op::SetFillColor { col: col(*c) });
                        ops.push(Op::DrawPolygon { polygon: poly(PaintMode::Fill) });
                    });
                }
                if let Some((c, w)) = stroke {
                    with_alpha(ctx, &mut ops, c.3, |ops| {
                        ops.push(Op::SetOutlineColor { col: col(*c) });
                        ops.push(Op::SetOutlineThickness { pt: Pt(w * MM_PT) });
                        ops.push(Op::DrawPolygon { polygon: poly(PaintMode::Stroke) });
                    });
                }
            }
            Cmd::Polygon { rings, fill } => {
                with_alpha(ctx, &mut ops, fill.3, |ops| {
                    ops.push(Op::SetFillColor { col: col(*fill) });
                    let poly = Polygon {
                        rings: rings.iter().map(|g| PolygonRing { points: g.iter().map(|(x, y)| lp(pt(h, *x, *y))).collect() }).collect(),
                        mode: PaintMode::Fill,
                        winding_order: WindingOrder::EvenOdd,
                    };
                    ops.push(Op::DrawPolygon { polygon: poly });
                });
            }
            Cmd::Line { x0, y0, x1, y1, color, width_mm } => {
                with_alpha(ctx, &mut ops, color.3, |ops| {
                    ops.push(Op::SetOutlineColor { col: col(*color) });
                    ops.push(Op::SetOutlineThickness { pt: Pt(width_mm * MM_PT) });
                    ops.push(Op::DrawLine { line: printpdf::Line { points: vec![lp(pt(h, *x0, *y0)), lp(pt(h, *x1, *y1))], is_closed: false } });
                });
            }
            Cmd::Text { r, text, size_mm, bold, color, align, font: family, .. } => {
                if text.is_empty() {
                    continue;
                }
                let size_pt = size_mm * MM_PT;
                let face = font::pdf_face(family, *bold);
                let f = &face.font;
                let sf = f.as_scaled(ab_glyph::PxScale::from(size_pt));
                let tw_mm = font::text_width(text, size_pt, *bold, &face.family) / MM_PT;
                let x = match align {
                    Align::Left => r.x,
                    Align::Center => r.x + (r.w - tw_mm) / 2.0,
                    Align::Right => r.x + r.w - tw_mm,
                };
                // baseline: centre the ascent/descent box on the rectangle centre
                let cy_pt = (h - (r.y + r.h / 2.0)) * MM_PT;
                let base = cy_pt - (sf.ascent() + sf.descent()) / 2.0;
                let font_id = ctx.font_id(family, *bold);
                with_alpha(ctx, &mut ops, color.3, |ops| {
                    ops.push(Op::StartTextSection);
                    ops.push(Op::SetFillColor { col: col(*color) });
                    ops.push(Op::SetFont { font: PdfFontHandle::External(font_id), size: Pt(size_pt) });
                    ops.push(Op::SetTextCursor { pos: Point { x: Pt(x * MM_PT), y: Pt(base) } });
                    ops.push(Op::ShowText { items: vec![TextItem::Text(text.clone())] });
                    ops.push(Op::EndTextSection);
                });
            }
            Cmd::Image { path, dest, crop, opacity, mask, fx } => {
                // target pixel size for the requested DPI, never upscaled
                let Some(src) = ctx.cache.get(path) else { eprintln!("pdf: no image {path}"); continue };
                let (sw, sh) = (src.width() as f32, src.height() as f32);
                let cx = (crop.0 * sw).round().clamp(0.0, sw - 1.0) as u32;
                let cy = (crop.1 * sh).round().clamp(0.0, sh - 1.0) as u32;
                let cw = (((crop.2 - crop.0) * sw).round() as u32).clamp(1, src.width() - cx);
                let ch = (((crop.3 - crop.1) * sh).round() as u32).clamp(1, src.height() - cy);
                let want_w = (dest.w / 25.4 * ctx.dpi).round().max(1.0) as u32;
                let want_h = (dest.h / 25.4 * ctx.dpi).round().max(1.0) as u32;
                let (tw, th) = (want_w.min(cw), want_h.min(ch));
                let mut piece_rgba = src.crop_imm(cx, cy, cw, ch).resize_exact(tw, th, ::image::imageops::FilterType::Lanczos3).to_rgba8();
                crate::raster::apply_fx(&mut piece_rgba, *fx);
                let piece = ::image::DynamicImage::ImageRgba8(piece_rgba);
                let key = format!("{path}|{cx},{cy},{cw},{ch}|{tw}x{th}|{}|{:?}", (*opacity * 100.0) as u32, fx);
                let id = if let Some(id) = ctx.images.get(&key) {
                    id.clone()
                } else {
                    let mut bytes: Vec<u8> = Vec::new();
                    if *opacity < 0.999 {
                        let mut rgba = piece.to_rgba8();
                        for p in rgba.pixels_mut() {
                            p.0[3] = (p.0[3] as f32 * opacity) as u8;
                        }
                        ::image::DynamicImage::ImageRgba8(rgba)
                            .write_to(&mut std::io::Cursor::new(&mut bytes), ::image::ImageFormat::Png)
                            .ok();
                    } else {
                        let rgb = piece.to_rgb8();
                        ::image::codecs::jpeg::JpegEncoder::new_with_quality(&mut bytes, 92).encode_image(&rgb).ok();
                    }
                    let raw = match RawImage::decode_from_bytes(&bytes, &mut Vec::new()) { Ok(r) => r, Err(e) => { eprintln!("pdf image decode: {e}"); continue } };
                    let id = ctx.doc.add_image(&raw);
                    ctx.images.insert(key, id.clone());
                    id
                };
                // dpi chosen so that tw pixels span exactly dest.w
                let dpi = tw as f32 / (dest.w / 25.4);
                // XObject scale for non-uniform stretching if aspect differs slightly
                let natural_h_mm = th as f32 / dpi * 25.4;
                let sy = dest.h / natural_h_mm;
                if let Some(rings) = mask {
                    ops.push(Op::SaveGraphicsState);
                    let poly = Polygon {
                        rings: rings.iter().map(|g| PolygonRing { points: g.iter().map(|(x, y)| lp(pt(h, *x, *y))).collect() }).collect(),
                        mode: PaintMode::Clip,
                        winding_order: WindingOrder::EvenOdd,
                    };
                    ops.push(Op::DrawPolygon { polygon: poly });
                }
                ops.push(Op::UseXobject {
                    id,
                    transform: XObjectTransform {
                        translate_x: Some(Pt(dest.x * MM_PT)),
                        translate_y: Some(Pt((h - dest.y - dest.h) * MM_PT)),
                        scale_x: Some(1.0),
                        scale_y: Some(sy),
                        dpi: Some(dpi),
                        ..Default::default()
                    },
                });
                if mask.is_some() {
                    ops.push(Op::RestoreGraphicsState);
                }
            }
        }
    }
    ops
}

/// Builds one PDF with one page per DrawList. `dpi` is the image resolution (72..600).
pub fn export_pdf(pages: &[DrawList], title: &str, dpi: f32, cache: &mut ImageCache, cmyk: bool) -> Vec<u8> {
    CMYK.store(cmyk, std::sync::atomic::Ordering::Relaxed);
    let doc = PdfDocument::new(title);
    let mut ctx = Ctx { doc, fonts: HashMap::new(), alphas: HashMap::new(), images: HashMap::new(), cache, dpi };
    let mut pdf_pages = Vec::new();
    for dl in pages {
        let ops = page_ops(&mut ctx, dl);
        pdf_pages.push(PdfPage::new(Mm(dl.w_mm), Mm(dl.h_mm), ops));
    }
    let mut doc = ctx.doc;
    doc.with_pages(pdf_pages).save(&PdfSaveOptions::default(), &mut Vec::new())
}
