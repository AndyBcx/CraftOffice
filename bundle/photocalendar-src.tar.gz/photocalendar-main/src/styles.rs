//! Month Style library: named, categorised grid styles. Built-in styles are generated here
//! (original designs); users can save the style of any grid layer under a category and name.
use crate::model::*;
use serde::{Deserialize, Serialize};

pub const CATEGORIES: [&str; 7] = ["Klasszikus", "Egysoros", "Dekoratív", "Táblázat", "Havi tervező", "Heti tervező", "Saját"];

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct NamedStyle {
    pub category: String,
    pub name: String,
    pub style: GridStyle,
}

fn c(r: u8, g: u8, b: u8) -> Rgba {
    Rgba(r, g, b, 255)
}

pub fn builtin() -> Vec<NamedStyle> {
    let mk = |cat: &str, name: &str, style: GridStyle| NamedStyle { category: cat.into(), name: name.into(), style };
    let mut v = vec![];

    v.push(mk("Klasszikus", "Klasszikus", GridStyle::default()));
    let mut s = GridStyle::default();
    s.week_starts_monday = false;
    s.arrangement = GridArrangement::TableHorizontal;
    v.push(mk("Klasszikus", "Vasárnap-kezdetű", s));
    let mut s = GridStyle::default();
    s.show_week_numbers = true;
    v.push(mk("Klasszikus", "Hétszámokkal", s));

    let mut s = GridStyle::default();
    s.arrangement = GridArrangement::Row;
    s.hide_border = true;
    v.push(mk("Egysoros", "Egy sor", s));
    let mut s = GridStyle::default();
    s.arrangement = GridArrangement::Column1;
    v.push(mk("Egysoros", "Oszlop (nap + név)", s));
    let mut s = GridStyle::default();
    s.arrangement = GridArrangement::Column2;
    v.push(mk("Egysoros", "Oszlop (nap + hét napja)", s));

    let mut s = GridStyle::default();
    s.show_month_name = true;
    s.month_header.background = Fill::Color(c(70, 110, 170));
    s.month_header.color = Rgba::WHITE;
    s.weekday_names.background = Fill::Color(c(225, 235, 248));
    s.weekend_names.background = Fill::Color(c(250, 225, 225));
    s.cell_shape = ShapeKind::RoundedRect;
    s.weekends_holidays.background = Fill::Color(c(255, 235, 235));
    s.weekdays.background = Fill::Color(c(245, 248, 253));
    s.hide_border = true;
    v.push(mk("Dekoratív", "Kék szalag", s));
    let mut s = GridStyle::default();
    s.show_month_name = true;
    s.month_header.background = Fill::Gradient { from: c(240, 140, 60), to: c(250, 190, 90), vertical: false };
    s.month_header.color = Rgba::WHITE;
    s.cell_shape = ShapeKind::Circle;
    s.weekends_holidays.background = Fill::Color(c(255, 225, 190));
    s.hide_border = true;
    v.push(mk("Dekoratív", "Narancs körök", s));
    let mut s = GridStyle::default();
    s.show_month_name = true;
    s.cell_shape = ShapeKind::Heart;
    s.weekends_holidays.background = Fill::Color(c(255, 205, 220));
    s.month_header.color = c(190, 40, 80);
    s.hide_border = true;
    v.push(mk("Dekoratív", "Szívek", s));

    let mut s = GridStyle::default();
    s.arrangement = GridArrangement::TableVertical;
    s.odd_row = Fill::Color(Rgba(240, 240, 240, 255));
    v.push(mk("Táblázat", "Csíkos tábla (függőleges)", s));
    let mut s = GridStyle::default();
    s.arrangement = GridArrangement::TableHorizontal;
    s.odd_row = Fill::Color(Rgba(236, 242, 250, 255));
    s.even_row = Fill::Color(Rgba(255, 255, 255, 255));
    s.show_week_numbers = true;
    v.push(mk("Táblázat", "Csíkos tábla (vízszintes)", s));

    let mut s = GridStyle::default();
    s.hide_empty_cells = true;
    s.show_month_name = true;
    s.show_holiday_names = true;
    s.weekdays.size = 0.2;
    s.weekends_holidays.size = 0.2;
    s.weekdays.align = Align::Left;
    s.weekends_holidays.align = Align::Left;
    v.push(mk("Havi tervező", "Havi tervező (nagy cellák)", s));
    let mut s = GridStyle::default();
    s.hide_empty_cells = true;
    s.show_week_numbers = true;
    s.show_holiday_names = false;
    v.push(mk("Havi tervező", "Havi tervező hétszámokkal", s));

    let mut s = GridStyle::default();
    s.arrangement = GridArrangement::WeekTable;
    s.show_week_numbers = true;
    v.push(mk("Heti tervező", "Heti táblázat", s));
    let mut s = GridStyle::default();
    s.arrangement = GridArrangement::WeekColumn;
    s.show_week_numbers = true;
    v.push(mk("Heti tervező", "Heti oszlopok", s));
    v
}
