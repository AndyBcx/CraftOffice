//! Platform glue: file dialogs and storage locations.
//! Desktop uses `rfd`. Android has no native dialog crate, so there the dialogs fall back to
//! fixed app/media folders (a Storage Access Framework picker via JNI is the proper next step).
use std::path::PathBuf;

/// Test hook: when `PHOTOCALENDAR_PICK` names a folder, the desktop dialogs answer from it without a window
/// (pick = files in that folder, save = file in that folder). Used for automated UI tests.
#[cfg(not(target_os = "android"))]
fn pick_dir() -> Option<PathBuf> {
    std::env::var_os("PHOTOCALENDAR_PICK").map(PathBuf::from)
}

#[cfg(not(target_os = "android"))]
pub struct FileDialog(rfd::FileDialog, String);

#[cfg(not(target_os = "android"))]
impl FileDialog {
    pub fn new() -> Self {
        FileDialog(rfd::FileDialog::new(), String::new())
    }
    pub fn add_filter(self, name: &str, ext: &[&str]) -> Self {
        FileDialog(self.0.add_filter(name, ext), self.1)
    }
    pub fn set_file_name(self, name: &str) -> Self {
        FileDialog(self.0.set_file_name(name), name.to_string())
    }
    pub fn save_file(self) -> Option<PathBuf> {
        if let Some(d) = pick_dir() {
            return Some(d.join(if self.1.is_empty() { "out" } else { &self.1 }));
        }
        self.0.save_file()
    }
    fn listing(d: &PathBuf) -> Vec<PathBuf> {
        let mut v: Vec<PathBuf> = std::fs::read_dir(d).map(|r| r.flatten().map(|e| e.path()).filter(|p| p.is_file()).collect()).unwrap_or_default();
        v.sort();
        v
    }
    pub fn pick_file(self) -> Option<PathBuf> {
        if let Some(d) = pick_dir() {
            return Self::listing(&d).into_iter().next();
        }
        self.0.pick_file()
    }
    pub fn pick_files(self) -> Option<Vec<PathBuf>> {
        if let Some(d) = pick_dir() {
            return Some(Self::listing(&d));
        }
        self.0.pick_files()
    }
}

#[cfg(target_os = "android")]
pub struct FileDialog {
    exts: Vec<String>,
    name: String,
}

#[cfg(target_os = "android")]
impl FileDialog {
    pub fn new() -> Self {
        FileDialog { exts: vec![], name: "naptar".into() }
    }
    pub fn add_filter(mut self, _name: &str, ext: &[&str]) -> Self {
        self.exts = ext.iter().map(|e| e.to_string()).collect();
        self
    }
    pub fn set_file_name(mut self, name: &str) -> Self {
        self.name = name.into();
        self
    }
    /// Saves into the app's export folder.
    pub fn save_file(self) -> Option<PathBuf> {
        let d = crate::config::dir().join("exports");
        std::fs::create_dir_all(&d).ok()?;
        Some(d.join(self.name))
    }
    fn candidates(&self) -> Vec<PathBuf> {
        let mut roots = vec![crate::config::dir().join("import")];
        for r in ["/storage/emulated/0/Pictures", "/storage/emulated/0/DCIM/Camera", "/storage/emulated/0/Download", "/sdcard/Pictures", "/sdcard/DCIM/Camera"] {
            roots.push(PathBuf::from(r));
        }
        let mut out = vec![];
        for r in roots {
            if let Ok(rd) = std::fs::read_dir(&r) {
                for e in rd.flatten() {
                    let p = e.path();
                    let ok = p.extension().and_then(|x| x.to_str()).map(|x| self.exts.is_empty() || self.exts.iter().any(|e| e.eq_ignore_ascii_case(x))).unwrap_or(false);
                    if ok {
                        out.push(p);
                    }
                }
            }
        }
        out.sort_by_key(|p| std::cmp::Reverse(std::fs::metadata(p).and_then(|m| m.modified()).ok()));
        out
    }
    /// Newest matching file in the known folders.
    pub fn pick_file(self) -> Option<PathBuf> {
        self.candidates().into_iter().next()
    }
    /// The 30 newest matching files.
    pub fn pick_files(self) -> Option<Vec<PathBuf>> {
        let v: Vec<_> = self.candidates().into_iter().take(30).collect();
        if v.is_empty() { None } else { Some(v) }
    }
}
