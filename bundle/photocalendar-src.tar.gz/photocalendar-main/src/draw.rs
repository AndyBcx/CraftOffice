//! Backend-independent drawing commands. One layout produces a DrawList; the
//! egui preview, the PDF writer and the PNG rasteriser all consume it, so what
//! you see is what you print.
use crate::model::{Align, RectMm, Rgba};

#[derive(Clone, Debug)]
pub enum Cmd {
    Rect { r: RectMm, fill: Option<Rgba>, stroke: Option<(Rgba, f32)> },
    /// Vertical colour gradient (top -> bottom) or horizontal (left -> right).
    Gradient { r: RectMm, from: Rgba, to: Rgba, vertical: bool },
    Ellipse { r: RectMm, fill: Option<Rgba>, stroke: Option<(Rgba, f32)> },
    Line { x0: f32, y0: f32, x1: f32, y1: f32, color: Rgba, width_mm: f32 },
    /// Text inside box `r`; vertically centred, horizontally per `align`.
    Text { r: RectMm, text: String, size_mm: f32, bold: bool, italic: bool, color: Rgba, align: Align },
    /// Image file drawn into `dest`; `crop` = (u0, v0, u1, v1) in 0..1 of the source.
    Image {
        path: String,
        dest: RectMm,
        crop: (f32, f32, f32, f32),
        opacity: f32,
        /// Optional clipping outline (even-odd rings in mm), e.g. a photo mask shape.
        mask: Option<Vec<Vec<(f32, f32)>>>,
        /// (brightness, contrast, saturation), each -1..1; (0,0,0) = unchanged.
        fx: (f32, f32, f32),
    },
    /// Commands drawn rotated (clockwise, degrees) around (cx, cy), all in mm.
    Group { rot_deg: f32, cx: f32, cy: f32, cmds: Vec<Cmd> },
    /// Filled polygon with several rings (even-odd rule).
    Polygon { rings: Vec<Vec<(f32, f32)>>, fill: Rgba },
}

#[derive(Clone, Debug, Default)]
pub struct DrawList {
    pub w_mm: f32,
    pub h_mm: f32,
    pub cmds: Vec<Cmd>,
}

impl DrawList {
    pub fn new(w_mm: f32, h_mm: f32) -> DrawList {
        DrawList { w_mm, h_mm, cmds: Vec::new() }
    }
    pub fn push(&mut self, c: Cmd) {
        self.cmds.push(c);
    }
}
