//! Project file format: versioned JSON, input checks on load, and the pictures packed into the
//! file so a project can be moved to another computer in one piece. Everything stays local.
use crate::model::*;
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

/// The format this program writes. Older files (without a version) are read as version 1.
pub const FORMAT_VERSION: u32 = 2;

/// A picture packed into the project file.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct EmbeddedImage {
    /// The path the project referred to when it was saved.
    pub path: String,
    /// The file's bytes, base64.
    pub data: String,
}

const B64: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

pub fn b64_encode(data: &[u8]) -> String {
    let mut out = String::with_capacity(data.len().div_ceil(3) * 4);
    for c in data.chunks(3) {
        let n = (c[0] as u32) << 16 | (*c.get(1).unwrap_or(&0) as u32) << 8 | *c.get(2).unwrap_or(&0) as u32;
        for i in 0..4 {
            if i <= c.len() {
                out.push(B64[(n >> (18 - 6 * i) & 63) as usize] as char);
            } else {
                out.push('=');
            }
        }
    }
    out
}

pub fn b64_decode(s: &str) -> Option<Vec<u8>> {
    let mut val = [255u8; 256];
    for (i, &c) in B64.iter().enumerate() {
        val[c as usize] = i as u8;
    }
    let bytes: Vec<u8> = s.bytes().filter(|b| !b.is_ascii_whitespace()).collect();
    if bytes.len() % 4 != 0 {
        return None;
    }
    let mut out = Vec::with_capacity(bytes.len() / 4 * 3);
    for q in bytes.chunks(4) {
        let mut n = 0u32;
        let mut pad = 0;
        for &b in q {
            n <<= 6;
            if b == b'=' {
                pad += 1;
            } else {
                let v = val[b as usize];
                if v == 255 || pad > 0 {
                    return None;
                }
                n |= v as u32;
            }
        }
        out.push((n >> 16) as u8);
        if pad < 2 {
            out.push((n >> 8) as u8);
        }
        if pad < 1 {
            out.push(n as u8);
        }
    }
    Some(out)
}

/// Every picture path the project uses (photos, clipart/logo files, backgrounds, fills, day photos).
pub fn image_paths(p: &Project) -> Vec<String> {
    let mut v: Vec<String> = Vec::new();
    let mut add = |s: &str| {
        if !s.is_empty() && !v.iter().any(|x| x == s) {
            v.push(s.to_string());
        }
    };
    let fill = |f: &Fill, add: &mut dyn FnMut(&str)| {
        if let Fill::Image(s) = f {
            add(s);
        }
    };
    for pg in &p.pages {
        if let Background::Image { path, .. } = &pg.background {
            add(path);
        }
        for l in &pg.layers {
            match &l.kind {
                LayerKind::Photo(ph) => {
                    if let Some(s) = &ph.path {
                        add(s);
                    }
                }
                LayerKind::Image { path, .. } => add(path),
                LayerKind::Shape(s) => fill(&s.fill, &mut add),
                LayerKind::Text(t) => fill(&t.fill, &mut add),
                _ => {}
            }
        }
    }
    for d in &p.day_photos {
        add(&d.path);
    }
    for g in &p.holiday_groups {
        for e in &g.events {
            if let Some(s) = &e.photo {
                add(s);
            }
        }
    }
    v
}

/// Replace picture paths everywhere in the project.
pub fn remap_paths(p: &mut Project, map: &dyn Fn(&str) -> Option<String>) {
    let fix = |s: &mut String| {
        if let Some(n) = map(s) {
            *s = n;
        }
    };
    let fix_fill = |f: &mut Fill| {
        if let Fill::Image(s) = f {
            if let Some(n) = map(s) {
                *s = n;
            }
        }
    };
    for pg in &mut p.pages {
        if let Background::Image { path, .. } = &mut pg.background {
            fix(path);
        }
        for l in &mut pg.layers {
            match &mut l.kind {
                LayerKind::Photo(ph) => {
                    if let Some(s) = &mut ph.path {
                        fix(s);
                    }
                }
                LayerKind::Image { path, .. } => fix(path),
                LayerKind::Shape(s) => fix_fill(&mut s.fill),
                LayerKind::Text(t) => fix_fill(&mut t.fill),
                _ => {}
            }
        }
    }
    for d in &mut p.day_photos {
        fix(&mut d.path);
    }
    for g in &mut p.holiday_groups {
        for e in &mut g.events {
            if let Some(s) = &mut e.photo {
                fix(s);
            }
        }
    }
}

/// Keep loaded values in range, so a damaged or hand-edited file can't break the program.
/// Returns what had to be corrected.
pub fn validate(p: &mut Project) -> Vec<String> {
    let mut fixed = Vec::new();
    let mut fix = |cond: bool, what: &str| {
        if cond {
            fixed.push(what.to_string());
        }
    };
    fix(!(1..=12).contains(&p.start_month), "kezdő hónap");
    p.start_month = p.start_month.clamp(1, 12);
    fix(!(1583..=9999).contains(&p.start_year), "kezdő év");
    p.start_year = p.start_year.clamp(1583, 9999);
    fix(!(1..=120).contains(&p.months), "hónapok száma");
    p.months = p.months.clamp(1, 120);
    fix(!(36..=1200).contains(&p.dpi), "felbontás");
    p.dpi = p.dpi.clamp(36, 1200);
    let ok_mm = |v: f32| v.is_finite() && (10.0..=3000.0).contains(&v);
    fix(!ok_mm(p.size.w_mm) || !ok_mm(p.size.h_mm), "lapméret");
    if !ok_mm(p.size.w_mm) || !ok_mm(p.size.h_mm) {
        p.size = PageSize::presets().into_iter().find(|s| s.name.starts_with("A4")).unwrap_or_else(|| PageSize::presets()[0].clone());
    }
    fix(!p.bleed_mm.is_finite() || !(0.0..=20.0).contains(&p.bleed_mm), "kifutó");
    p.bleed_mm = if p.bleed_mm.is_finite() { p.bleed_mm.clamp(0.0, 20.0) } else { 0.0 };
    p.export.jpeg_quality = p.export.jpeg_quality.clamp(10, 100);
    p.export.copies = p.export.copies.clamp(1, 99);
    let mut bad_layers = 0;
    for pg in &mut p.pages {
        if let Some((y, m)) = &mut pg.month {
            *m = (*m).clamp(1, 12);
            *y = (*y).clamp(1583, 9999);
        }
        for l in &mut pg.layers {
            let r = &mut l.rect;
            if ![r.x, r.y, r.w, r.h, l.rotation_deg].iter().all(|v| v.is_finite()) || r.w <= 0.0 || r.h <= 0.0 {
                bad_layers += 1;
                *r = RectMm { x: 0.0, y: 0.0, w: r.w.abs().max(1.0).min(3000.0), h: r.h.abs().max(1.0).min(3000.0) };
                if !r.w.is_finite() || !r.h.is_finite() {
                    *r = RectMm { x: 0.0, y: 0.0, w: 50.0, h: 50.0 };
                }
                if !l.rotation_deg.is_finite() {
                    l.rotation_deg = 0.0;
                }
            }
        }
    }
    fix(bad_layers > 0, "rétegméretek");
    for g in &mut p.holiday_groups {
        g.events.retain(|e| match e.rule {
            crate::holidays::DateRule::Fixed { month, day } | crate::holidays::DateRule::Once { month, day, .. } => (1..=12).contains(&month) && (1..=31).contains(&day),
            crate::holidays::DateRule::NthWeekday { month, nth, weekday } => (1..=12).contains(&month) && (1..=5).contains(&nth) && weekday < 7,
            _ => true,
        });
    }
    fixed
}

/// The JSON envelope: version first, so a newer file is recognised before anything else is read.
#[derive(Deserialize)]
struct Probe {
    #[serde(default)]
    format_version: Option<u32>,
}

pub enum LoadError {
    Io(std::io::Error),
    /// Made by a newer PhotoCalendar.
    TooNew(u32),
    Bad(String),
}

impl std::fmt::Display for LoadError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            LoadError::Io(e) => write!(f, "{e}"),
            LoadError::TooNew(v) => write!(f, "{}", crate::tf!("A fájl egy újabb programverzióval készült ({}. formátum); frissítsd a PhotoCalendart.", v)),
            LoadError::Bad(e) => write!(f, "{}", crate::tf!("A fájl sérült vagy nem PhotoCalendar-projekt: {}", e)),
        }
    }
}

/// Read a project. Packed pictures are written to `<file name>_kepek/` beside the project (only
/// those that are missing there) and the project then refers to them.
pub fn load(path: &Path) -> Result<(Project, Vec<String>), LoadError> {
    let s = std::fs::read_to_string(path).map_err(LoadError::Io)?;
    let probe: Probe = serde_json::from_str(&s).map_err(|e| LoadError::Bad(e.to_string()))?;
    let ver = probe.format_version.unwrap_or(1);
    if ver > FORMAT_VERSION {
        return Err(LoadError::TooNew(ver));
    }
    let mut p: Project = serde_json::from_str(&s).map_err(|e| LoadError::Bad(e.to_string()))?;
    if p.pages.is_empty() {
        p.rebuild_pages();
    }
    let mut notes = validate(&mut p);
    if !p.embedded_images.is_empty() {
        let dir = images_dir(path);
        let _ = std::fs::create_dir_all(&dir);
        let mut map: Vec<(String, String)> = Vec::new();
        for (i, e) in std::mem::take(&mut p.embedded_images).into_iter().enumerate() {
            // keep the original when it is still there (same computer)
            if Path::new(&e.path).is_file() {
                continue;
            }
            let name = Path::new(&e.path).file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_else(|| format!("kep{i}"));
            let target = dir.join(format!("{i:03}_{}", sanitize(&name)));
            if !target.is_file() {
                match b64_decode(&e.data) {
                    Some(bytes) => {
                        if std::fs::write(&target, bytes).is_err() {
                            notes.push(crate::tf!("kép nem írható: {}", target.display()));
                            continue;
                        }
                    }
                    None => {
                        notes.push(crate::tf!("sérült beágyazott kép: {}", name));
                        continue;
                    }
                }
            }
            map.push((e.path, target.to_string_lossy().to_string()));
        }
        remap_paths(&mut p, &|s| map.iter().find(|(a, _)| a == s).map(|(_, b)| b.clone()));
    }
    // fonts this computer lacks are drawn with a free stand-in of the same widths
    if let Ok(js) = serde_json::to_string(&p) {
        let mut seen: Vec<String> = Vec::new();
        for cap in js.split("\"font\":\"").skip(1) {
            if let Some(name) = cap.split('"').next() {
                if !name.is_empty() && !seen.iter().any(|x| x == name) {
                    seen.push(name.to_string());
                    let (real, sub) = crate::font::resolve(name);
                    if sub {
                        notes.push(crate::tf!("{} betű helyett {}", name, real));
                    }
                }
            }
        }
    }
    p.format_version = FORMAT_VERSION;
    Ok((p, notes))
}

fn sanitize(s: &str) -> String {
    s.chars().map(|c| if c.is_alphanumeric() || ".-_".contains(c) { c } else { '_' }).collect()
}

pub fn images_dir(project: &Path) -> PathBuf {
    let stem = project.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| "naptar".into());
    project.with_file_name(format!("{stem}_kepek"))
}

/// Write a project. With `pack`, every picture it uses goes into the file too. Returns the
/// pictures that could not be read (they stay as paths).
pub fn save(p: &Project, path: &Path, pack: bool) -> std::io::Result<Vec<String>> {
    let mut out = p.clone();
    out.format_version = FORMAT_VERSION;
    out.embedded_images.clear();
    let mut missing = Vec::new();
    if pack {
        for s in image_paths(p) {
            match std::fs::read(&s) {
                Ok(b) => out.embedded_images.push(EmbeddedImage { path: s, data: b64_encode(&b) }),
                Err(_) => missing.push(s),
            }
        }
    }
    let s = serde_json::to_string_pretty(&out).map_err(std::io::Error::other)?;
    // write beside, then replace: a full disk never leaves half a project
    let tmp = path.with_extension("json.tmp");
    std::fs::write(&tmp, s)?;
    std::fs::rename(&tmp, path)?;
    Ok(missing)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn base64_round_trip() {
        for n in 0..20 {
            let data: Vec<u8> = (0..n).map(|i| (i * 37 + 5) as u8).collect();
            assert_eq!(b64_decode(&b64_encode(&data)).unwrap(), data);
        }
        assert_eq!(b64_encode(b"Man"), "TWFu");
        assert_eq!(b64_encode(b"Ma"), "TWE=");
        assert!(b64_decode("T@==").is_none());
    }

    #[test]
    fn save_pack_and_load_back() {
        let dir = std::env::temp_dir().join(format!("pc-proj-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let img = dir.join("foto.png");
        image::RgbaImage::from_pixel(4, 3, image::Rgba([10, 20, 30, 255])).save(&img).unwrap();
        let size = PageSize::presets().into_iter().find(|s| s.name.starts_with("A4")).unwrap();
        let mut p = Project::new_default(size, false, 2027, 1, crate::cal::Lang::Hu);
        for pg in &mut p.pages {
            for l in &mut pg.layers {
                if let LayerKind::Photo(ph) = &mut l.kind {
                    ph.path = Some(img.to_string_lossy().to_string());
                }
            }
        }
        let file = dir.join("naptar.json");
        assert!(save(&p, &file, true).unwrap().is_empty());
        // the picture is gone from its place: the packed copy is used
        std::fs::remove_file(&img).unwrap();
        let (q, notes) = load(&file).unwrap_or_else(|e| panic!("{e}"));
        assert!(notes.is_empty(), "{notes:?}");
        assert_eq!(q.pages.len(), p.pages.len());
        let paths = image_paths(&q);
        assert!(!paths.is_empty());
        for s in paths {
            assert!(s.contains("naptar_kepek"), "{s}");
            assert!(Path::new(&s).is_file());
        }
        assert_eq!(q.format_version, FORMAT_VERSION);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn newer_and_damaged_files_are_refused_and_values_checked() {
        let dir = std::env::temp_dir().join(format!("pc-proj2-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let f = dir.join("uj.json");
        std::fs::write(&f, r#"{"format_version": 99}"#).unwrap();
        assert!(matches!(load(&f), Err(LoadError::TooNew(99))));
        std::fs::write(&f, "nem json").unwrap();
        assert!(matches!(load(&f), Err(LoadError::Bad(_))));
        let size = PageSize::presets()[0].clone();
        let mut p = Project::new_default(size, false, 2027, 1, crate::cal::Lang::Hu);
        p.start_month = 14;
        p.dpi = 5;
        p.months = 0;
        let fixed = validate(&mut p);
        assert_eq!((p.start_month, p.dpi, p.months), (12, 36, 1));
        assert_eq!(fixed.len(), 3);
        let _ = std::fs::remove_dir_all(&dir);
    }
}

#[cfg(test)]
mod export_checks {
    use crate::model::*;

    #[test]
    fn a4_at_300_dpi_is_2480_by_3508() {
        let a4 = PageSize::presets().into_iter().find(|s| s.name.starts_with("A4")).unwrap();
        for landscape in [false, true] {
            let mut p = Project::new_default(a4.clone(), landscape, 2027, 1, crate::cal::Lang::Hu);
            p.dpi = 300;
            let dims = |_: &str| None;
            let dl = crate::layout::render_page(&p, 0, &dims);
            let mut cache = crate::raster::ImageCache::new();
            let img = crate::raster::rasterize(&dl, 300.0, 12000, &mut cache);
            let want = if landscape { (3508, 2480) } else { (2480, 3508) };
            assert_eq!((img.width(), img.height()), want);
        }
    }

    #[test]
    fn every_kind_builds_its_pages() {
        let a4 = PageSize::presets().into_iter().find(|s| s.name.starts_with("A4")).unwrap();
        for (kind, pages) in [(CalendarKind::Monthly, 1), (CalendarKind::Quarterly, 4), (CalendarKind::TwoYear, 1), (CalendarKind::ThreeYear, 1), (CalendarKind::Spiral, 12), (CalendarKind::Poster, 1)] {
            let mut p = Project::new_default(a4.clone(), false, 2027, 1, crate::cal::Lang::Hu);
            p.kind = kind;
            p.rebuild_pages();
            assert_eq!(p.pages.len(), pages, "{kind:?}");
            let grids: usize = p.pages.iter().flat_map(|pg| &pg.layers).filter(|l| matches!(l.kind, LayerKind::Grid(_))).count();
            let want = match kind {
                CalendarKind::TwoYear => 24,
                CalendarKind::ThreeYear => 36,
                CalendarKind::Monthly => 1,
                _ => 12,
            };
            assert_eq!(grids, want, "{kind:?}");
            // every page lays out (missing photos are empty slots, not errors)
            let dims = |_: &str| None;
            for i in 0..p.pages.len() {
                let _ = crate::layout::render_page(&p, i, &dims);
            }
        }
    }

    #[test]
    fn the_new_templates_build() {
        let n = crate::templates::names().len();
        assert!(crate::templates::names().contains(&"Hullámok"));
        for i in 0..n {
            let pg = crate::templates::build(i, 210.0, 297.0, Some((2027, 3)));
            assert!(!pg.layers.is_empty());
        }
    }
}

#[cfg(test)]
mod font_checks {
    #[test]
    fn the_pdf_embeds_the_chosen_fonts() {
        let a4 = crate::model::PageSize::presets().into_iter().find(|s| s.name.starts_with("A4")).unwrap();
        let mut p = crate::model::Project::new_default(a4, false, 2027, 3, crate::cal::Lang::Hu);
        p.pages[0] = crate::templates::build(10, 210.0, 297.0, Some((2027, 3)));
        let dims = |_: &str| None;
        let dl = crate::layout::render_page(&p, 0, &dims);
        let mut cache = crate::raster::ImageCache::new();
        let pdf = crate::pdf::export_pdf(&[dl.clone()], "t", 72.0, &mut cache, false);
        // printpdf names embedded fonts by a hash: the default font (photo placeholder) plus
        // Lora regular and bold make three
        let hay = String::from_utf8_lossy(&pdf);
        let fonts: std::collections::HashSet<&str> = hay.split("/BaseFont").skip(1).filter_map(|x| x.split_whitespace().next()).collect();
        assert!(fonts.len() >= 3, "{fonts:?}");
        if std::env::var("PC_SHOW").is_ok() {
            crate::raster::rasterize(&dl, 60.0, 2000, &mut cache).save("/tmp/font_tpl.png").unwrap();
        }
    }
}
