//! Page generators for each calendar type / binding / page layout. They only
//! build ordinary layers, so every generated element stays editable.
use crate::model::*;

pub fn r(x: f32, y: f32, w: f32, h: f32) -> RectMm {
    RectMm { x, y, w, h }
}

pub fn text(name: &str, rect: RectMm, t: &str, size_pt: f32, bold: bool, align: Align) -> Layer {
    let color = Rgba(40, 40, 40, 255);
    layer(
        name,
        rect,
        LayerKind::Text(TextLayer {
            text: t.into(),
            font_size_pt: size_pt,
            bold,
            color,
            align,
            opacity: 1.0,
            italic: false,
            drop_shadow: false,
            fill: Fill::Color(color),
            outline: None,
        }),
    )
}

pub fn photo(rect: RectMm) -> Layer {
    layer("Fotó", rect, LayerKind::Photo(PhotoLayer::empty()))
}

pub fn grid(name: &str, rect: RectMm, fixed: Option<(i32, u32)>, mini: bool) -> Layer {
    let mut st = GridStyle::default();
    if mini {
        st.show_month_name = true;
        st.show_holiday_names = false;
        st.background = Fill::None;
    }
    layer(name, rect, LayerKind::Grid(GridLayer { fixed_month: fixed, style: st }))
}

fn holes(rect: RectMm, vertical: bool) -> Layer {
    let len = if vertical { rect.h } else { rect.w };
    let count = (len / 12.7).round().max(2.0) as u32;
    layer("Kötés (spirál)", rect, LayerKind::Holes { count, diameter_mm: 3.5, vertical, color: Rgba(90, 90, 90, 255) })
}

pub fn title_pt(h_mm: f32) -> f32 {
    (h_mm * 0.55 / 0.3528).clamp(8.0, 60.0)
}

fn month_list(p: &Project) -> Vec<(i32, u32)> {
    let n = match p.kind {
        CalendarKind::Monthly => 1,
        CalendarKind::TwoYear => 24,
        CalendarKind::ThreeYear => 36,
        _ => p.months.max(1),
    };
    let (mut y, mut m) = (p.start_year, p.start_month.clamp(1, 12));
    let mut v = vec![];
    for _ in 0..n {
        v.push((y, m));
        m += 1;
        if m > 12 {
            m = 1;
            y += 1;
        }
    }
    v
}

fn page(month: Option<(i32, u32)>, layers: Vec<Layer>) -> Page {
    Page { month, background: Background::Color(Rgba::WHITE), layers }
}

/// Single month, photo + title + grid, inside `area` (the whole page minus the binding band).
fn same_page(area: RectMm, ym: (i32, u32)) -> Vec<Layer> {
    let mut pg = default_month_page(area.w, area.h, ym.0, ym.1);
    for l in pg.layers.iter_mut() {
        l.rect.x += area.x;
        l.rect.y += area.y;
    }
    pg.layers
}

/// Spiral-center: the page is split along its middle; photo half + title/grid half.
fn center_page(w: f32, h: f32, ym: (i32, u32)) -> Vec<Layer> {
    let m = w.min(h) * 0.05;
    let mut v = vec![];
    if w >= h {
        let hw = w / 2.0;
        let th = h * 0.10;
        v.push(photo(r(m, m, hw - m - 4.0, h - 2.0 * m)));
        v.push(text("Hónap címe", r(hw + 4.0, m, hw - m - 4.0, th), "{month} {year}", title_pt(th), true, Align::Center));
        v.push(grid("Naptárrács", r(hw + 4.0, m + th * 1.2, hw - m - 4.0, h - 2.0 * m - th * 1.2), None, false));
        v.push(holes(r(hw - 2.0, m, 4.0, h - 2.0 * m), true));
    } else {
        let hh = h / 2.0;
        let th = hh * 0.12;
        v.push(photo(r(m, m, w - 2.0 * m, hh - m - 4.0)));
        v.push(text("Hónap címe", r(m, hh + 4.0, w - 2.0 * m, th), "{month} {year}", title_pt(th), true, Align::Center));
        v.push(grid("Naptárrács", r(m, hh + 4.0 + th * 1.2, w - 2.0 * m, hh - m - 4.0 - th * 1.2), None, false));
        v.push(holes(r(m, hh - 2.0, w - 2.0 * m, 4.0), false));
    }
    let _ = ym;
    v
}

fn separate_pages(area: RectMm, ym: (i32, u32), bind: Vec<Layer>) -> [Page; 2] {
    let m = area.w.min(area.h) * 0.05;
    let th = area.h * 0.07;
    let mut a = vec![
        photo(r(area.x + m, area.y + m, area.w - 2.0 * m, area.h - 3.0 * m - th)),
        text("Hónap címe", r(area.x + m, area.y + area.h - m - th, area.w - 2.0 * m, th), "{month} {year}", title_pt(th), true, Align::Center),
    ];
    a.extend(bind.iter().cloned());
    let th2 = area.h * 0.08;
    let mut b = vec![
        text("Hónap címe", r(area.x + m, area.y + m, area.w - 2.0 * m, th2), "{month} {year}", title_pt(th2), true, Align::Center),
        grid("Naptárrács", r(area.x + m, area.y + m + th2 * 1.2, area.w - 2.0 * m, area.h - 2.0 * m - th2 * 1.2), None, false),
    ];
    b.extend(bind);
    [page(Some(ym), a), page(Some(ym), b)]
}

fn desk_page(w: f32, h: f32, ym: (i32, u32)) -> Vec<Layer> {
    let m = w.min(h) * 0.04;
    let ph = h * 0.46;
    let th = h * 0.07;
    vec![
        photo(r(m, m, w - 2.0 * m, ph - m)),
        layer(
            "Hajtás",
            r(0.0, ph + (h - ph) * 0.0 - 0.15, w, 0.3),
            LayerKind::Shape(ShapeLayer { kind: ShapeKind::Rectangle, fill: Fill::Color(Rgba(160, 160, 160, 255)), outline: None, opacity: 1.0, drop_shadow: false }),
        ),
        text("Hónap címe", r(m, ph + m * 0.5, w - 2.0 * m, th), "{month} {year}", title_pt(th), true, Align::Center),
        grid("Naptárrács", r(m, ph + m * 0.5 + th * 1.15, w - 2.0 * m, h - ph - m * 0.5 - th * 1.15 - m), None, false),
    ]
    .into_iter()
    .map(|l| {
        let _ = ym;
        l
    })
    .collect()
}

/// Whole period on one sheet: photo + title + mini month grids (poster / pocket).
fn poster_page(w: f32, h: f32, months: &[(i32, u32)], photo_frac: f32) -> Page {
    let m = w.min(h) * 0.04;
    let (y0, y1) = (months[0].0, months[months.len() - 1].0);
    let title = if y0 == y1 { format!("{y0}") } else { format!("{y0}–{y1}") };
    let n = months.len();
    let landscape = w > h;
    let mut v = vec![];
    let (photo_r, grid_area, title_r);
    if landscape {
        let pw = (w - 3.0 * m) * (photo_frac + 0.1);
        photo_r = r(m, m, pw, h - 2.0 * m);
        let gx = 2.0 * m + pw;
        let th = h * 0.09;
        title_r = r(gx, m, w - gx - m, th);
        grid_area = r(gx, m + th * 1.1, w - gx - m, h - 2.0 * m - th * 1.1);
    } else {
        let ph = (h - 3.0 * m) * photo_frac;
        photo_r = r(m, m, w - 2.0 * m, ph);
        let th = h * 0.06;
        title_r = r(m, 2.0 * m + ph, w - 2.0 * m, th);
        grid_area = r(m, 2.0 * m + ph + th * 1.1, w - 2.0 * m, h - m - (2.0 * m + ph + th * 1.1));
    }
    v.push(photo(photo_r));
    v.push(text("Évszám", title_r, &title, title_pt(title_r.h), true, Align::Center));
    let cols = match (n, landscape) {
        (0..=3, _) => n.max(1),
        (_, true) if n > 24 => 6,
        (_, true) => 4,
        (_, false) if n > 24 => 4,
        _ => 3,
    };
    let rows = n.div_ceil(cols);
    let gap = m * 0.6;
    let cw = (grid_area.w - gap * (cols as f32 - 1.0)) / cols as f32;
    let ch = (grid_area.h - gap * (rows as f32 - 1.0)) / rows as f32;
    for (i, ym) in months.iter().enumerate() {
        let (c, rw) = (i % cols, i / cols);
        v.push(grid(
            &format!("Hónap {}", i + 1),
            r(grid_area.x + c as f32 * (cw + gap), grid_area.y + rw as f32 * (ch + gap), cw, ch),
            Some(*ym),
            true,
        ));
    }
    page(None, v)
}

fn planner_page(w: f32, h: f32, area_y: f32, ym: (i32, u32)) -> Vec<Layer> {
    let m = w.min(h) * 0.05;
    let th = h * 0.07;
    vec![
        text("Hónap címe", r(m, area_y + m, w - 2.0 * m, th), "{month} {year}", title_pt(th), true, Align::Center),
        grid("Naptárrács", r(m, area_y + m + th * 1.2, w - 2.0 * m, h - area_y - 2.0 * m - th * 1.2), None, false),
    ]
    .into_iter()
    .map(|l| {
        let _ = ym;
        l
    })
    .collect()
}

pub fn generate_pages(p: &Project) -> Vec<Page> {
    let (w, h) = p.page_dims_mm();
    let months = month_list(p);
    // keep already placed photos, in order
    let old: Vec<String> = p
        .pages
        .iter()
        .flat_map(|pg| pg.layers.iter())
        .filter_map(|l| match &l.kind {
            LayerKind::Photo(ph) => ph.path.clone(),
            _ => None,
        })
        .collect();

    let top_band = if p.binding == Binding::SpiralTop { (h * 0.05).clamp(10.0, 18.0) } else { 0.0 };
    let area = r(0.0, top_band, w, h - top_band);
    let top_holes = || {
        let m = w.min(h) * 0.05;
        holes(r(m, top_band * 0.25, w - 2.0 * m, top_band * 0.5), false)
    };
    let mut pages: Vec<Page> = vec![];
    match p.kind {
        CalendarKind::Poster => pages.push(poster_page(w, h, &months, 0.45)),
        CalendarKind::TwoYear | CalendarKind::ThreeYear => pages.push(poster_page(w, h, &months, 0.25)),
        CalendarKind::Quarterly => {
            for q in months.chunks(3) {
                let mut pg = poster_page(w, h, q, 0.5);
                // the page's title is the quarter's months, not only the year
                for l in pg.layers.iter_mut() {
                    if let LayerKind::Text(t) = &mut l.kind {
                        if l.name == "Évszám" {
                            t.text = if q.len() > 1 { format!("{{month:{}}} – {{month:{}}} {}", q[0].1, q[q.len() - 1].1, q[0].0) } else { format!("{}", q[0].0) };
                        }
                    }
                }
                pages.push(pg);
            }
        }
        CalendarKind::Monthly => {
            let ym = months[0];
            let mut l = same_page(area, ym);
            if top_band > 0.0 {
                l.push(top_holes());
            }
            pages.push(page(Some(ym), l));
        }
        CalendarKind::Pocket => pages.push(poster_page(w, h, &months, 0.30)),
        CalendarKind::Planner => {
            for ym in &months {
                let mut l = planner_page(w, h, top_band, *ym);
                if top_band > 0.0 {
                    l.push(top_holes());
                }
                pages.push(page(Some(*ym), l));
            }
        }
        CalendarKind::Desk => {
            for ym in &months {
                pages.push(page(Some(*ym), desk_page(w, h, *ym)));
            }
        }
        CalendarKind::Spiral | CalendarKind::Custom => {
            for ym in &months {
                if p.binding == Binding::SpiralCenter {
                    pages.push(page(Some(*ym), center_page(w, h, *ym)));
                } else if p.page_layout == PageLayout::SeparatePages {
                    let bind = if top_band > 0.0 { vec![top_holes()] } else { vec![] };
                    pages.extend(separate_pages(area, *ym, bind));
                } else {
                    let mut l = same_page(area, *ym);
                    if top_band > 0.0 {
                        l.push(top_holes());
                    }
                    pages.push(page(Some(*ym), l));
                }
            }
        }
    }
    let mut it = old.into_iter();
    for pg in pages.iter_mut() {
        for l in pg.layers.iter_mut() {
            if let LayerKind::Photo(ph) = &mut l.kind {
                if let Some(f) = it.next() {
                    ph.path = Some(f);
                }
            }
        }
    }
    pages
}
