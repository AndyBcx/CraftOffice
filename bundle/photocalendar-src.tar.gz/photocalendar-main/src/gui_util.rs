//! Shared egui helper widgets and option lists.
use crate::model::*;
use eframe::egui;

pub fn rgba_edit(ui: &mut egui::Ui, c: &mut Rgba) -> bool {
    let mut a = [c.0, c.1, c.2, c.3];
    if ui.color_edit_button_srgba_unmultiplied(&mut a).changed() {
        *c = Rgba(a[0], a[1], a[2], a[3]);
        return true;
    }
    false
}

pub fn pick_image() -> Option<String> {
    crate::platform::FileDialog::new()
        .add_filter(crate::i18n::t("Képek"), &["png", "jpg", "jpeg", "bmp", "gif", "webp", "tif", "tiff"])
        .pick_file()
        .map(|f| f.to_string_lossy().to_string())
}

pub fn pick_images() -> Vec<String> {
    crate::platform::FileDialog::new()
        .add_filter(crate::i18n::t("Képek"), &["png", "jpg", "jpeg", "bmp", "gif", "webp", "tif", "tiff"])
        .pick_files()
        .unwrap_or_default()
        .into_iter()
        .map(|f| f.to_string_lossy().to_string())
        .collect()
}

/// Fill editor: none / colour / gradient / picture.
pub fn fill_edit(ui: &mut egui::Ui, label: &str, f: &mut Fill) -> bool {
    let before = f.clone();
    ui.horizontal(|ui| {
        ui.label(label);
        let mut kind = match f {
            Fill::None => 0,
            Fill::Color(_) => 1,
            Fill::Gradient { .. } => 2,
            Fill::Image(_) => 3,
        };
        let k0 = kind;
        let names = [crate::i18n::t("Nincs"), crate::i18n::t("Szín"), crate::i18n::t("Színátmenet"), crate::i18n::t("Textúra")];
        egui::ComboBox::from_id_salt(label).selected_text(names[kind]).show_ui(ui, |ui| {
            for (i, n) in names.iter().enumerate() {
                ui.selectable_value(&mut kind, i, *n);
            }
        });
        if kind != k0 {
            *f = match kind {
                0 => Fill::None,
                1 => Fill::Color(Rgba(255, 255, 255, 255)),
                2 => Fill::Gradient { from: Rgba(255, 255, 255, 255), to: Rgba(200, 200, 200, 255), vertical: true },
                _ => Fill::Image(String::new()),
            };
        }
        match f {
            Fill::Color(c) => {
                rgba_edit(ui, c);
            }
            Fill::Gradient { from, to, vertical } => {
                rgba_edit(ui, from);
                rgba_edit(ui, to);
                ui.selectable_value(vertical, true, crate::i18n::t("függ."));
                ui.selectable_value(vertical, false, crate::i18n::t("vízsz."));
            }
            Fill::Image(p) => {
                if ui.button(crate::i18n::t("Tallózás…")).clicked() {
                    if let Some(f) = pick_image() {
                        *p = f;
                    }
                }
            }
            Fill::None => {}
        }
    });
    *f != before
}

pub fn outline_edit(ui: &mut egui::Ui, o: &mut Option<(Rgba, f32)>) -> bool {
    let before = *o;
    ui.horizontal(|ui| {
        let mut on = o.is_some();
        if ui.checkbox(&mut on, crate::i18n::t("Körvonal")).changed() {
            *o = if on { Some((Rgba::BLACK, 0.3)) } else { None };
        }
        if let Some((c, w)) = o {
            rgba_edit(ui, c);
            ui.add(egui::DragValue::new(w).speed(0.05).range(0.05..=10.0).suffix(" mm"));
        }
    });
    *o != before
}

pub fn align_edit(ui: &mut egui::Ui, a: &mut Align) -> bool {
    ui.horizontal(|ui| {
        let mut c = false;
        c |= ui.selectable_value(a, Align::Left, crate::i18n::t("Balra")).changed();
        c |= ui.selectable_value(a, Align::Center, crate::i18n::t("Középre")).changed();
        c |= ui.selectable_value(a, Align::Right, crate::i18n::t("Jobbra")).changed();
        c
    })
    .inner
}

/// Length edit in mm or inch.
pub fn len_edit(ui: &mut egui::Ui, v: &mut f32, inch: bool, range: std::ops::RangeInclusive<f32>) -> bool {
    if inch {
        let mut x = *v / 25.4;
        let r = ui.add(egui::DragValue::new(&mut x).speed(0.02).range(range.start() / 25.4..=range.end() / 25.4).suffix(" in"));
        if r.changed() {
            *v = x * 25.4;
        }
        r.changed()
    } else {
        ui.add(egui::DragValue::new(v).speed(0.5).range(range).suffix(" mm")).changed()
    }
}

pub fn shape_name(k: ShapeKind) -> &'static str {
    match k {
        ShapeKind::Circle => crate::i18n::t("Kör"),
        ShapeKind::Ellipse => crate::i18n::t("Ellipszis"),
        ShapeKind::Square => crate::i18n::t("Négyzet"),
        ShapeKind::Rectangle => crate::i18n::t("Téglalap"),
        ShapeKind::RoundedRect => crate::i18n::t("Lekerekített téglalap"),
        ShapeKind::Triangle => crate::i18n::t("Háromszög"),
        ShapeKind::Star => crate::i18n::t("Csillag"),
        ShapeKind::Arrow => crate::i18n::t("Nyíl"),
        ShapeKind::Heart => crate::i18n::t("Szív"),
        ShapeKind::Cross => crate::i18n::t("Kereszt"),
        ShapeKind::Ring => crate::i18n::t("Gyűrű"),
        ShapeKind::Flower => crate::i18n::t("Virág"),
        ShapeKind::Sun => crate::i18n::t("Nap"),
        ShapeKind::Cloud => crate::i18n::t("Felhő"),
        ShapeKind::Moon => crate::i18n::t("Hold"),
        ShapeKind::Tree => crate::i18n::t("Fenyő"),
        ShapeKind::Leaf => crate::i18n::t("Levél"),
        ShapeKind::Snowflake => crate::i18n::t("Hópehely"),
        ShapeKind::Drop => crate::i18n::t("Csepp"),
        ShapeKind::House => crate::i18n::t("Ház"),
        ShapeKind::Butterfly => crate::i18n::t("Pillangó"),
        ShapeKind::Frame => crate::i18n::t("Képkeret"),
        ShapeKind::Wave => crate::i18n::t("Hullám"),
    }
}

pub const SHAPES: [ShapeKind; 23] = [
    ShapeKind::Circle,
    ShapeKind::Ellipse,
    ShapeKind::Square,
    ShapeKind::Rectangle,
    ShapeKind::RoundedRect,
    ShapeKind::Triangle,
    ShapeKind::Star,
    ShapeKind::Arrow,
    ShapeKind::Heart,
    ShapeKind::Cross,
    ShapeKind::Ring,
    ShapeKind::Flower,
    ShapeKind::Sun,
    ShapeKind::Cloud,
    ShapeKind::Moon,
    ShapeKind::Tree,
    ShapeKind::Leaf,
    ShapeKind::Snowflake,
    ShapeKind::Drop,
    ShapeKind::House,
    ShapeKind::Butterfly,
    ShapeKind::Frame,
    ShapeKind::Wave,
];

pub const MASKS: [ShapeKind; 8] = [
    ShapeKind::Circle,
    ShapeKind::Ellipse,
    ShapeKind::RoundedRect,
    ShapeKind::Triangle,
    ShapeKind::Star,
    ShapeKind::Heart,
    ShapeKind::Flower,
    ShapeKind::Leaf,
];

pub const CELL_SHAPES: [ShapeKind; 6] = [
    ShapeKind::Rectangle,
    ShapeKind::RoundedRect,
    ShapeKind::Circle,
    ShapeKind::Heart,
    ShapeKind::Star,
    ShapeKind::Flower,
];

pub fn arr_name(a: GridArrangement) -> &'static str {
    match a {
        GridArrangement::TableVertical => crate::i18n::t("Táblázat (függőleges)"),
        GridArrangement::TableHorizontal => crate::i18n::t("Táblázat (vízszintes)"),
        GridArrangement::Row => crate::i18n::t("Egy sor"),
        GridArrangement::Column1 => crate::i18n::t("Oszlop 1"),
        GridArrangement::Column2 => crate::i18n::t("Oszlop 2"),
        GridArrangement::Column3 => crate::i18n::t("Oszlop 3"),
        GridArrangement::WeekTable => crate::i18n::t("Heti táblázat"),
        GridArrangement::WeekColumn => crate::i18n::t("Heti oszlopok"),
    }
}

pub const ARRS: [GridArrangement; 8] = [
    GridArrangement::TableVertical,
    GridArrangement::TableHorizontal,
    GridArrangement::Row,
    GridArrangement::Column1,
    GridArrangement::Column2,
    GridArrangement::Column3,
    GridArrangement::WeekTable,
    GridArrangement::WeekColumn,
];

pub fn kind_name(k: CalendarKind) -> &'static str {
    match k {
        CalendarKind::Poster => crate::i18n::t("Poszter (egész év egy lapon)"),
        CalendarKind::Spiral => crate::i18n::t("Spirálkötött (havi lapok)"),
        CalendarKind::Desk => crate::i18n::t("Asztali"),
        CalendarKind::Pocket => crate::i18n::t("Zsebnaptár"),
        CalendarKind::Planner => crate::i18n::t("Havi tervező"),
        CalendarKind::Custom => crate::i18n::t("Egyéni"),
        CalendarKind::Monthly => crate::i18n::t("Havi (egy hónap)"),
        CalendarKind::Quarterly => crate::i18n::t("Negyedéves (3 hónap oldalanként)"),
        CalendarKind::TwoYear => crate::i18n::t("Kétéves (24 hónap egy lapon)"),
        CalendarKind::ThreeYear => crate::i18n::t("Hároméves (36 hónap egy lapon)"),
    }
}

pub const KINDS: [CalendarKind; 10] = [
    CalendarKind::Spiral,
    CalendarKind::Monthly,
    CalendarKind::Quarterly,
    CalendarKind::TwoYear,
    CalendarKind::ThreeYear,
    CalendarKind::Poster,
    CalendarKind::Desk,
    CalendarKind::Pocket,
    CalendarKind::Planner,
    CalendarKind::Custom,
];

/// Font picker: the built-in free fonts first, then the ones installed on this computer.
/// A font missing here shows which free stand-in is drawn instead.
pub fn font_edit(ui: &mut egui::Ui, id: &str, family: &mut String) -> bool {
    let mut changed = false;
    let shown = if family.trim().is_empty() { crate::font::DEFAULT_FAMILY.to_string() } else { family.clone() };
    let (real, substituted) = crate::font::resolve(&shown);
    ui.horizontal(|ui| {
        ui.label(crate::i18n::t("Betűtípus"));
        egui::ComboBox::from_id_salt(id).selected_text(shown.clone()).width(170.0).height(420.0).show_ui(ui, |ui| {
            let (builtin, system) = crate::font::families();
            ui.label(egui::RichText::new(crate::i18n::t("Beépített (szabad) betűk")).small().weak());
            for f in &builtin {
                if ui.selectable_label(*family == *f || (family.is_empty() && f == crate::font::DEFAULT_FAMILY), f).clicked() {
                    *family = f.clone();
                    changed = true;
                }
            }
            if !system.is_empty() {
                ui.separator();
                ui.label(egui::RichText::new(crate::i18n::t("A gépen telepített betűk")).small().weak());
                for f in &system {
                    if ui.selectable_label(*family == *f, f).clicked() {
                        *family = f.clone();
                        changed = true;
                    }
                }
            }
        });
    });
    if substituted {
        ui.small(crate::tf!("Ez a betű nincs ezen a gépen; helyette: {}", real));
    }
    changed
}
