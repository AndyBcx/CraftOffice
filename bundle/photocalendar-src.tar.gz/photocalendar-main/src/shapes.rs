//! Outlines of the built-in shapes as polygon rings (mm), used for shape layers,
//! photo masks, shadows and clipping in every backend.
use crate::model::{RectMm, ShapeKind};
use std::f32::consts::{PI, TAU};

pub type Ring = Vec<(f32, f32)>;

fn ellipse(r: RectMm, n: usize) -> Ring {
    let (cx, cy, rx, ry) = (r.x + r.w / 2.0, r.y + r.h / 2.0, r.w / 2.0, r.h / 2.0);
    (0..n).map(|i| {
        let a = i as f32 / n as f32 * TAU;
        (cx + rx * a.cos(), cy + ry * a.sin())
    }).collect()
}

fn square_in(r: RectMm) -> RectMm {
    let d = r.w.min(r.h);
    RectMm { x: r.x + (r.w - d) / 2.0, y: r.y + (r.h - d) / 2.0, w: d, h: d }
}

fn unit(r: RectMm, pts: &[(f32, f32)]) -> Ring {
    pts.iter().map(|(u, v)| (r.x + u * r.w, r.y + v * r.h)).collect()
}

fn circle_u(cx: f32, cy: f32, rad: f32) -> Ring {
    (0..48).map(|i| {
        let a = i as f32 / 48.0 * TAU;
        (cx + rad * a.cos(), cy + rad * a.sin())
    }).collect()
}

fn ellipse_u(cx: f32, cy: f32, rx: f32, ry: f32) -> Ring {
    (0..48).map(|i| {
        let a = i as f32 / 48.0 * TAU;
        (cx + rx * a.cos(), cy + ry * a.sin())
    }).collect()
}

fn rot_rect_u(angle: f32, len: f32, thick: f32) -> Ring {
    let (c, s) = (angle.cos(), angle.sin());
    [(-len / 2.0, -thick / 2.0), (len / 2.0, -thick / 2.0), (len / 2.0, thick / 2.0), (-len / 2.0, thick / 2.0)]
        .iter().map(|(x, y)| (0.5 + x * c - y * s, 0.5 + x * s + y * c)).collect()
}

/// Independent parts (each filled on its own, so overlapping parts do not cancel out).
pub fn parts(kind: ShapeKind, r: RectMm) -> Vec<Vec<Ring>> {
    let u = |ring: Ring| -> Vec<Ring> { vec![unit(r, &ring)] };
    match kind {
        ShapeKind::Cloud => vec![
            u(circle_u(0.28, 0.62, 0.2)),
            u(circle_u(0.5, 0.45, 0.26)),
            u(circle_u(0.72, 0.6, 0.21)),
            u(vec![(0.28, 0.62), (0.72, 0.6), (0.9, 0.8), (0.1, 0.82)]),
            u(vec![(0.1, 0.6), (0.9, 0.6), (0.9, 0.82), (0.1, 0.82)]),
        ],
        ShapeKind::Tree => vec![
            u(vec![(0.5, 0.0), (0.85, 0.38), (0.15, 0.38)]),
            u(vec![(0.5, 0.18), (0.9, 0.62), (0.1, 0.62)]),
            u(vec![(0.5, 0.38), (0.95, 0.85), (0.05, 0.85)]),
            u(vec![(0.43, 0.85), (0.57, 0.85), (0.57, 1.0), (0.43, 1.0)]),
        ],
        ShapeKind::Snowflake => (0..3).map(|i| u(rot_rect_u(i as f32 * PI / 3.0, 1.0, 0.08))).collect(),
        ShapeKind::House => vec![
            u(vec![(0.15, 0.45), (0.85, 0.45), (0.85, 1.0), (0.15, 1.0)]),
            u(vec![(0.05, 0.48), (0.5, 0.05), (0.95, 0.48)]),
        ],
        ShapeKind::Butterfly => vec![
            u(ellipse_u(0.27, 0.32, 0.25, 0.28)),
            u(ellipse_u(0.73, 0.32, 0.25, 0.28)),
            u(ellipse_u(0.32, 0.7, 0.2, 0.22)),
            u(ellipse_u(0.68, 0.7, 0.2, 0.22)),
            u(ellipse_u(0.5, 0.5, 0.04, 0.36)),
        ],
        _ => vec![outline(kind, r)],
    }
}

pub fn outline(kind: ShapeKind, r: RectMm) -> Vec<Ring> {
    match kind {
        ShapeKind::Cloud | ShapeKind::Tree | ShapeKind::Snowflake | ShapeKind::House | ShapeKind::Butterfly => {
            parts(kind, r).into_iter().flatten().collect()
        }
        ShapeKind::Sun => {
            let mut p = vec![];
            for i in 0..24 {
                let a = i as f32 * TAU / 24.0;
                let rr = if i % 2 == 0 { 0.5 } else { 0.34 };
                p.push((0.5 + rr * a.cos(), 0.5 + rr * a.sin()));
            }
            vec![unit(square_in(r), &p)]
        }
        ShapeKind::Moon => {
            let n = 96;
            let outer: Vec<(f32, f32)> = (0..n).map(|i| { let a = i as f32 / n as f32 * TAU; (0.5 + 0.5 * a.cos(), 0.5 + 0.5 * a.sin()) }).collect();
            let inner: Vec<(f32, f32)> = (0..n).map(|i| { let a = i as f32 / n as f32 * TAU; (0.7 + 0.42 * a.cos(), 0.4 + 0.42 * a.sin()) }).collect();
            let inside = |p: (f32, f32), c: (f32, f32), rad: f32| (p.0 - c.0).powi(2) + (p.1 - c.1).powi(2) < rad * rad;
            let start = (0..n).find(|&i| inside(outer[i], (0.7, 0.4), 0.42)).unwrap_or(0);
            let mut ring: Vec<(f32, f32)> = vec![];
            for k in 0..n {
                let p = outer[(start + k) % n];
                if !inside(p, (0.7, 0.4), 0.42) {
                    ring.push(p);
                }
            }
            let mut inn: Vec<(f32, f32)> = inner.into_iter().filter(|p| inside(*p, (0.5, 0.5), 0.5)).collect();
            // order so that the inner arc connects from the last outer point back to the first
            let (fe, le) = (ring[0], ring[ring.len() - 1]);
            let d = |a: (f32, f32), b: (f32, f32)| (a.0 - b.0).powi(2) + (a.1 - b.1).powi(2);
            if inn.is_empty() { return vec![unit(square_in(r), &ring)]; }
            if d(inn[0], le) > d(inn[inn.len() - 1], le) { inn.reverse(); }
            let _ = fe;
            ring.extend(inn);
            vec![unit(square_in(r), &ring)]
        }
        ShapeKind::Leaf => {
            let n = 40;
            let prof = |t: f32| 0.42 * (PI * t).sin().abs().powf(0.8) * (1.0 - 0.3 * t);
            let mut p: Vec<(f32, f32)> = (0..=n).map(|i| { let t = i as f32 / n as f32; (t, 0.5 - prof(t)) }).collect();
            p.extend((1..n).rev().map(|i| { let t = i as f32 / n as f32; (t, 0.5 + prof(t)) }));
            vec![unit(r, &p)]
        }
        ShapeKind::Drop => {
            let mut p = vec![(0.5, 0.0)];
            for k in 0..=60 {
                let a = (-60.0 + k as f32 * 300.0 / 60.0).to_radians();
                p.push((0.5 + 0.34 * a.cos(), 0.66 + 0.34 * a.sin()));
            }
            vec![unit(r, &p)]
        }
        ShapeKind::Frame => {
            let t = (r.w.min(r.h) * 0.06).max(0.5);
            vec![
                vec![(r.x, r.y), (r.x + r.w, r.y), (r.x + r.w, r.y + r.h), (r.x, r.y + r.h)],
                vec![(r.x + t, r.y + t), (r.x + r.w - t, r.y + t), (r.x + r.w - t, r.y + r.h - t), (r.x + t, r.y + r.h - t)],
            ]
        }
        ShapeKind::Circle => vec![ellipse(square_in(r), 96)],
        ShapeKind::Ellipse => vec![ellipse(r, 96)],
        ShapeKind::Ring => {
            let o = square_in(r);
            let i = RectMm { x: o.x + o.w * 0.2, y: o.y + o.h * 0.2, w: o.w * 0.6, h: o.h * 0.6 };
            vec![ellipse(o, 96), ellipse(i, 96)]
        }
        ShapeKind::Square => {
            let s = square_in(r);
            vec![unit(s, &[(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)])]
        }
        ShapeKind::Rectangle => vec![unit(r, &[(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)])],
        ShapeKind::RoundedRect => {
            let rad = r.w.min(r.h) * 0.18;
            let mut v = vec![];
            let corners = [(r.x + r.w - rad, r.y + rad, -PI / 2.0), (r.x + r.w - rad, r.y + r.h - rad, 0.0), (r.x + rad, r.y + r.h - rad, PI / 2.0), (r.x + rad, r.y + rad, PI)];
            for (cx, cy, a0) in corners {
                for k in 0..=12 {
                    let a = a0 + k as f32 / 12.0 * (PI / 2.0);
                    v.push((cx + rad * a.cos(), cy + rad * a.sin()));
                }
            }
            vec![v]
        }
        ShapeKind::Triangle => vec![unit(r, &[(0.5, 0.0), (1.0, 1.0), (0.0, 1.0)])],
        ShapeKind::Star => {
            let mut p = vec![];
            for i in 0..10 {
                let a = -PI / 2.0 + i as f32 * PI / 5.0;
                let rr = if i % 2 == 0 { 0.5 } else { 0.21 };
                p.push((0.5 + rr * a.cos(), 0.53 + rr * a.sin()));
            }
            vec![unit(r, &p)]
        }
        ShapeKind::Arrow => vec![unit(r, &[(0.0, 0.33), (0.58, 0.33), (0.58, 0.05), (1.0, 0.5), (0.58, 0.95), (0.58, 0.67), (0.0, 0.67)])],
        ShapeKind::Heart => {
            let n = 96;
            let raw: Vec<(f32, f32)> = (0..n).map(|i| {
                let t = i as f32 / n as f32 * TAU;
                (16.0 * t.sin().powi(3), -(13.0 * t.cos() - 5.0 * (2.0 * t).cos() - 2.0 * (3.0 * t).cos() - (4.0 * t).cos()))
            }).collect();
            let (minx, maxx) = raw.iter().fold((f32::MAX, f32::MIN), |a, p| (a.0.min(p.0), a.1.max(p.0)));
            let (miny, maxy) = raw.iter().fold((f32::MAX, f32::MIN), |a, p| (a.0.min(p.1), a.1.max(p.1)));
            let p: Vec<_> = raw.iter().map(|(x, y)| ((x - minx) / (maxx - minx), (y - miny) / (maxy - miny))).collect();
            vec![unit(r, &p)]
        }
        ShapeKind::Cross => {
            let (a, b) = (0.33, 0.67);
            vec![unit(r, &[(a, 0.0), (b, 0.0), (b, a), (1.0, a), (1.0, b), (b, b), (b, 1.0), (a, 1.0), (a, b), (0.0, b), (0.0, a), (a, a)])]
        }
        ShapeKind::Flower => {
            let n = 144;
            let p: Vec<_> = (0..n).map(|i| {
                let a = i as f32 / n as f32 * TAU;
                let rr = 0.5 * (0.62 + 0.38 * (6.0 * a).cos().abs().powf(0.7));
                (0.5 + rr * a.cos(), 0.5 + rr * a.sin())
            }).collect();
            vec![unit(r, &p)]
        }
    }
}

/// Even-odd coverage mask over the pixel box `(x0,y0,w,h)` for rings given in mm and scale `s` px/mm.
/// Values 0..=255 with 4x vertical supersampling and exact horizontal coverage.
pub fn coverage(rings: &[Ring], s: f32, x0: i32, y0: i32, w: u32, h: u32) -> Vec<u8> {
    let mut out = vec![0u8; (w * h) as usize];
    let sub = 4;
    let mut acc = vec![0f32; w as usize];
    for py in 0..h {
        acc.iter_mut().for_each(|a| *a = 0.0);
        for k in 0..sub {
            let y = (y0 + py as i32) as f32 + (k as f32 + 0.5) / sub as f32;
            let mut xs: Vec<f32> = vec![];
            for ring in rings {
                let n = ring.len();
                for i in 0..n {
                    let (ax, ay) = (ring[i].0 * s, ring[i].1 * s);
                    let (bx, by) = (ring[(i + 1) % n].0 * s, ring[(i + 1) % n].1 * s);
                    if (ay <= y && by > y) || (by <= y && ay > y) {
                        xs.push(ax + (y - ay) / (by - ay) * (bx - ax));
                    }
                }
            }
            xs.sort_by(|a, b| a.partial_cmp(b).unwrap());
            for pair in xs.chunks(2) {
                if pair.len() < 2 {
                    break;
                }
                let (l, r) = (pair[0] - x0 as f32, pair[1] - x0 as f32);
                let (ci0, ci1) = (l.floor().max(0.0) as i32, (r.ceil() as i32).min(w as i32));
                for cx in ci0..ci1 {
                    let ov = (r.min(cx as f32 + 1.0) - l.max(cx as f32)).max(0.0);
                    acc[cx as usize] += ov / sub as f32;
                }
            }
        }
        for x in 0..w as usize {
            out[py as usize * w as usize + x] = (acc[x].clamp(0.0, 1.0) * 255.0) as u8;
        }
    }
    out
}

pub fn bbox(rings: &[Ring]) -> RectMm {
    let (mut x0, mut y0, mut x1, mut y1) = (f32::MAX, f32::MAX, f32::MIN, f32::MIN);
    for p in rings.iter().flatten() {
        x0 = x0.min(p.0);
        y0 = y0.min(p.1);
        x1 = x1.max(p.0);
        y1 = y1.max(p.1);
    }
    RectMm { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }
}
