//! Turns a page (background + layers) into a DrawList.
use crate::cal::{self, Lang};
use crate::draw::{Cmd, DrawList};
use crate::font;
use crate::shapes;
use crate::holidays::{self, EventKind};
use crate::model::*;

/// Looks up the pixel size of an image file.
pub type DimsFn<'a> = &'a dyn Fn(&str) -> Option<(u32, u32)>;

const PT_MM: f32 = 25.4 / 72.0;

pub fn render_page(project: &Project, page_index: usize, dims: DimsFn) -> DrawList {
    let (w, h) = project.page_dims_mm();
    let mut dl = DrawList::new(w, h);
    let Some(page) = project.pages.get(page_index) else { return dl };
    let full = RectMm { x: 0.0, y: 0.0, w, h };

    match &page.background {
        Background::Color(c) => dl.push(Cmd::Rect { r: full, fill: Some(*c), stroke: None }),
        Background::Gradient { top, bottom } => {
            dl.push(Cmd::Gradient { r: full, from: *top, to: *bottom, vertical: true })
        }
        Background::Image { path, lighten, fit } => {
            if let Some(d) = dims(path) {
                let (dest, crop) = match fit {
                    BgFit::Fill => (full, cover_crop(d, full, 1.0, 0.0, 0.0)),
                    BgFit::Stretch => (full, (0.0, 0.0, 1.0, 1.0)),
                    BgFit::Fit => (contain_rect(d, full), (0.0, 0.0, 1.0, 1.0)),
                };
                dl.push(Cmd::Image { path: path.clone(), dest, crop, opacity: 1.0, mask: None, fx: (0.0, 0.0, 0.0) });
            }
            if *lighten {
                dl.push(Cmd::Rect { r: full, fill: Some(Rgba(255, 255, 255, 140)), stroke: None });
            }
        }
    }

    for layer in page.layers.iter().filter(|l| l.visible) {
        let start = dl.cmds.len();
        match &layer.kind {
            LayerKind::Photo(p) => photo(&mut dl, layer.rect, p, dims),
            LayerKind::Text(t) => text_layer(&mut dl, layer.rect, t, page.month, project),
            LayerKind::Image { path, opacity } => {
                if let Some(d) = dims(path) {
                    let dest = contain_rect(d, layer.rect);
                    dl.push(Cmd::Image { path: path.clone(), dest, crop: (0.0, 0.0, 1.0, 1.0), opacity: *opacity, mask: None, fx: (0.0, 0.0, 0.0) });
                }
            }
            LayerKind::Shape(s) => shape(&mut dl, layer.rect, s),
            LayerKind::Holes { count, diameter_mm, vertical, color } => {
                let r = layer.rect;
                let n = (*count).max(1);
                for i in 0..n {
                    let t = (i as f32 + 0.5) / n as f32;
                    let (cx, cy) = if *vertical { (r.x + r.w / 2.0, r.y + r.h * t) } else { (r.x + r.w * t, r.y + r.h / 2.0) };
                    let d = *diameter_mm;
                    dl.push(Cmd::Ellipse {
                        r: RectMm { x: cx - d / 2.0, y: cy - d / 2.0, w: d, h: d },
                        fill: Some(Rgba(255, 255, 255, 255)),
                        stroke: Some((*color, 0.3)),
                    });
                }
            }
            LayerKind::Grid(g) => {
                let month = g.fixed_month.or(page.month);
                if let Some((y, m)) = month {
                    grid(&mut dl, layer.rect, &g.style, y, m, project, dims);
                }
            }
        }
        if layer.rotation_deg != 0.0 {
            rotate_cmds(&mut dl.cmds, start, layer.rect, layer.rotation_deg);
        }
    }
    dl
}

/// Wraps the commands from index `start` into a rotated group (clockwise, degrees, around the layer centre).
fn rotate_cmds(cmds: &mut Vec<Cmd>, start: usize, rect: RectMm, deg: f32) {
    let inner: Vec<Cmd> = cmds.drain(start..).collect();
    cmds.push(Cmd::Group { rot_deg: deg, cx: rect.x + rect.w / 2.0, cy: rect.y + rect.h / 2.0, cmds: inner });
}

/// Source crop (u0,v0,u1,v1) so that the image covers `dest` (cover fit), with zoom and pan.
pub fn cover_crop(img: (u32, u32), dest: RectMm, zoom: f32, pan_x: f32, pan_y: f32) -> (f32, f32, f32, f32) {
    let (iw, ih) = (img.0.max(1) as f32, img.1.max(1) as f32);
    let img_ar = iw / ih;
    let dst_ar = dest.w / dest.h.max(0.0001);
    let (mut cw, mut ch) = if img_ar > dst_ar { (dst_ar / img_ar, 1.0) } else { (1.0, img_ar / dst_ar) };
    let z = zoom.max(1.0);
    cw /= z;
    ch /= z;
    let cx = 0.5 + pan_x.clamp(-1.0, 1.0) * (1.0 - cw) * 0.5;
    let cy = 0.5 + pan_y.clamp(-1.0, 1.0) * (1.0 - ch) * 0.5;
    (cx - cw / 2.0, cy - ch / 2.0, cx + cw / 2.0, cy + ch / 2.0)
}

fn contain_rect(img: (u32, u32), r: RectMm) -> RectMm {
    let ar = img.0.max(1) as f32 / img.1.max(1) as f32;
    let (w, h) = if ar > r.w / r.h { (r.w, r.w / ar) } else { (r.h * ar, r.h) };
    RectMm { x: r.x + (r.w - w) / 2.0, y: r.y + (r.h - h) / 2.0, w, h }
}

fn inset(r: RectMm, d: f32) -> RectMm {
    RectMm { x: r.x + d, y: r.y + d, w: (r.w - 2.0 * d).max(0.1), h: (r.h - 2.0 * d).max(0.1) }
}

fn ring_lines(dl: &mut DrawList, rings: &[Vec<(f32, f32)>], c: Rgba, w: f32) {
    ring_lines_v(&mut dl.cmds, rings, c, w);
}

fn ring_lines_v(v: &mut Vec<Cmd>, rings: &[Vec<(f32, f32)>], c: Rgba, w: f32) {
    for ring in rings {
        let n = ring.len();
        for i in 0..n {
            let (a, b) = (ring[i], ring[(i + 1) % n]);
            v.push(Cmd::Line { x0: a.0, y0: a.1, x1: b.0, y1: b.1, color: c, width_mm: w });
        }
    }
}

fn photo(dl: &mut DrawList, r: RectMm, p: &PhotoLayer, dims: DimsFn) {
    let masked = p.mask.filter(|k| !matches!(k, ShapeKind::Rectangle));
    let outer = masked.map(|k| shapes::outline(k, r));
    if p.drop_shadow {
        match &outer {
            Some(rings) => {
                let sh: Vec<_> = rings.iter().map(|g| g.iter().map(|(x, y)| (x + 1.2, y + 1.2)).collect()).collect();
                dl.push(Cmd::Polygon { rings: sh, fill: Rgba(0, 0, 0, 70) });
            }
            None => dl.push(Cmd::Rect { r: RectMm { x: r.x + 1.2, y: r.y + 1.2, w: r.w, h: r.h }, fill: Some(Rgba(0, 0, 0, 70)), stroke: None }),
        }
    }
    if p.frame_mm > 0.0 {
        match &outer {
            Some(rings) => dl.push(Cmd::Polygon { rings: rings.clone(), fill: p.frame_color }),
            None => dl.push(Cmd::Rect { r, fill: Some(p.frame_color), stroke: None }),
        }
    }
    let inner = inset(r, p.frame_mm);
    let inner_rings = masked.map(|k| shapes::outline(k, inner));
    let fx = (p.brightness, p.contrast, p.saturation);
    match p.path.as_deref().and_then(|path| dims(path).map(|d| (path, d))) {
        Some((path, d)) => dl.push(Cmd::Image {
            path: path.to_string(),
            dest: inner,
            crop: cover_crop(d, inner, p.zoom, p.pan_x, p.pan_y),
            opacity: p.opacity,
            mask: inner_rings.clone(),
            fx,
        }),
        None => {
            match &inner_rings {
                Some(rings) => dl.push(Cmd::Polygon { rings: rings.clone(), fill: Rgba(200, 200, 200, 255) }),
                None => dl.push(Cmd::Rect { r: inner, fill: Some(Rgba(200, 200, 200, 255)), stroke: None }),
            }
            dl.push(Cmd::Text {
                r: inner,
                text: "Fotó".into(),
                size_mm: (inner.h * 0.12).min(inner.w * 0.2),
                bold: true,
                italic: false,
                color: Rgba(120, 120, 120, 255),
                align: Align::Center,
            });
        }
    }
    if let Some((c, wmm)) = p.outline {
        match &outer {
            Some(rings) => ring_lines(dl, rings, c, wmm),
            None => dl.push(Cmd::Rect { r, fill: None, stroke: Some((c, wmm)) }),
        }
    }
}

pub fn tokens(text: &str, month: Option<(i32, u32)>, project: &Project) -> String {
    let Some((y, m)) = month else {
        // free page: month tokens have nothing to show
        return text.replace("{month_year}", "").replace("{month}", "").replace("{year}", "");
    };
    let lang = project.lang;
    let two = match project.second_lang.filter(|l2| *l2 != lang) {
        Some(l2) => format!("{} / {}", project.month_name(lang, m), project.month_name(l2, m)),
        None => project.month_name(lang, m),
    };
    text.replace("{month_year}", &format!("{} {}", two, y))
        .replace("{month}", &two)
        .replace("{year}", &y.to_string())
}

fn avg_color(path: &str) -> Option<Rgba> {
    let im = image::open(path).ok()?.thumbnail(8, 8).to_rgb8();
    let n = (im.width() * im.height()).max(1) as u32;
    let (mut r, mut g, mut b) = (0u32, 0u32, 0u32);
    for p in im.pixels() {
        r += p.0[0] as u32;
        g += p.0[1] as u32;
        b += p.0[2] as u32;
    }
    Some(Rgba((r / n) as u8, (g / n) as u8, (b / n) as u8, 255))
}

fn lerp_c(a: Rgba, b: Rgba, t: f32) -> Rgba {
    let m = |x: u8, y: u8| (x as f32 + (y as f32 - x as f32) * t.clamp(0.0, 1.0)) as u8;
    Rgba(m(a.0, b.0), m(a.1, b.1), m(a.2, b.2), m(a.3, b.3))
}

fn text_layer(dl: &mut DrawList, r: RectMm, t: &TextLayer, month: Option<(i32, u32)>, project: &Project) {
    let text = tokens(&t.text, month, project);
    let lines: Vec<&str> = text.split('\n').collect();
    let size = t.font_size_pt * PT_MM;
    let line_h = size * 1.25;
    let total = line_h * lines.len() as f32;
    let alpha = |c: Rgba| Rgba(c.0, c.1, c.2, (c.3 as f32 * t.opacity) as u8);
    let base = match &t.fill {
        Fill::Color(c) => *c,
        Fill::Image(p) => avg_color(p).unwrap_or(t.color),
        _ => t.color,
    };
    let mut y = r.y + (r.h - total) / 2.0;
    let nl = lines.len();
    for (li, l) in lines.into_iter().enumerate() {
        let lr = RectMm { x: r.x, y, w: r.w, h: line_h };
        if t.drop_shadow {
            let sr = RectMm { x: lr.x + size * 0.05, y: lr.y + size * 0.05, ..lr };
            dl.push(Cmd::Text { r: sr, text: l.into(), size_mm: size, bold: t.bold, italic: t.italic, color: Rgba(0, 0, 0, 90), align: t.align });
        }
        if let Some((oc, ow)) = t.outline {
            let d = ow.max(0.05);
            for k in 0..8 {
                let a = k as f32 * std::f32::consts::FRAC_PI_4;
                let orr = RectMm { x: lr.x + d * a.cos(), y: lr.y + d * a.sin(), ..lr };
                dl.push(Cmd::Text { r: orr, text: l.into(), size_mm: size, bold: t.bold, italic: t.italic, color: alpha(oc), align: t.align });
            }
        }
        match &t.fill {
            Fill::Gradient { from, to, vertical } => {
                let tw = font::text_width(l, size, t.bold);
                let x0 = match t.align {
                    Align::Left => lr.x,
                    Align::Center => lr.x + (lr.w - tw) / 2.0,
                    Align::Right => lr.x + lr.w - tw,
                };
                if *vertical {
                    let tt = if nl > 1 { li as f32 / (nl - 1) as f32 } else { 0.0 };
                    dl.push(Cmd::Text { r: lr, text: l.into(), size_mm: size, bold: t.bold, italic: t.italic, color: alpha(lerp_c(*from, *to, tt)), align: t.align });
                } else {
                    let mut prefix = String::new();
                    for ch in l.chars() {
                        let px = font::text_width(&prefix, size, t.bold);
                        let cw = font::text_width(&ch.to_string(), size, t.bold);
                        let col = lerp_c(*from, *to, (px + cw / 2.0) / tw.max(0.001));
                        let cr = RectMm { x: x0 + px, y: lr.y, w: cw * 1.5 + 1.0, h: lr.h };
                        dl.push(Cmd::Text { r: cr, text: ch.to_string(), size_mm: size, bold: t.bold, italic: t.italic, color: alpha(col), align: Align::Left });
                        prefix.push(ch);
                    }
                }
            }
            _ => dl.push(Cmd::Text { r: lr, text: l.into(), size_mm: size, bold: t.bold, italic: t.italic, color: alpha(base), align: t.align }),
        }
        y += line_h;
    }
}


fn shape(dl: &mut DrawList, r: RectMm, s: &ShapeLayer) {
    let fill = match &s.fill {
        Fill::Color(c) => Some(Rgba(c.0, c.1, c.2, (c.3 as f32 * s.opacity) as u8)),
        Fill::Gradient { from, .. } => Some(Rgba(from.0, from.1, from.2, (from.3 as f32 * s.opacity) as u8)),
        _ => None,
    };
    let rings = shapes::outline(s.kind, r);
    if s.drop_shadow {
        let sh: Vec<_> = rings.iter().map(|g| g.iter().map(|(x, y)| (x + 1.2, y + 1.2)).collect()).collect();
        dl.push(Cmd::Polygon { rings: sh, fill: Rgba(0, 0, 0, 70) });
    }
    if matches!(s.kind, ShapeKind::Rectangle) {
        if let Fill::Gradient { from, to, vertical } = &s.fill {
            dl.push(Cmd::Gradient { r, from: *from, to: *to, vertical: *vertical });
            if let Some((c, w)) = s.outline {
                dl.push(Cmd::Rect { r, fill: None, stroke: Some((c, w)) });
            }
            return;
        }
        dl.push(Cmd::Rect { r, fill, stroke: s.outline });
        return;
    }
    if let Some(f) = fill {
        for part in shapes::parts(s.kind, r) {
            dl.push(Cmd::Polygon { rings: part, fill: f });
        }
    }
    if let Some((c, w)) = s.outline {
        for part in shapes::parts(s.kind, r) {
            ring_lines(dl, &part, c, w);
        }
    }
}

fn cell_text(project: &Project, template: &str, lang: Lang, y: i32, m: u32, day: u32, wd: u32) -> String {
    let (wy, wk) = cal::iso_week(y, m, day);
    let _ = wy;
    template
        .replace("[&MonthName]", &project.month_name(lang, m))
        .replace("[&Month]", &m.to_string())
        .replace("[&Year]", &y.to_string())
        .replace("[&DayNameShort]", &project.weekday_short(lang, wd))
        .replace("[&DayName]", &project.weekday_name(lang, wd))
        .replace("[&Day]", &day.to_string())
        .replace("[&WeekShort]", &project.week_short(lang))
        .replace("[&Week]", &wk.to_string())
}

fn fill_cmd(dl: &mut DrawList, r: RectMm, f: &Fill) {
    match f {
        Fill::None | Fill::Image(_) => {}
        Fill::Color(c) => dl.push(Cmd::Rect { r, fill: Some(*c), stroke: None }),
        Fill::Gradient { from, to, vertical } => dl.push(Cmd::Gradient { r, from: *from, to: *to, vertical: *vertical }),
    }
}

/// Background fill in the given cell shape (plain rectangle or a decorative shape).
fn fill_shape(dl: &mut DrawList, r: RectMm, f: &Fill, kind: ShapeKind) {
    match (f, kind) {
        (Fill::Color(c), k) if !matches!(k, ShapeKind::Rectangle) => {
            let d = r.w.min(r.h) * 0.06;
            let rings = shapes::outline(k, inset(r, d));
            dl.push(Cmd::Polygon { rings, fill: *c });
        }
        _ => fill_cmd(dl, r, f),
    }
}

fn styled_text(dl: &mut DrawList, r: RectMm, st: &CellStyle, text: String, size_mm: f32) {
    if text.is_empty() {
        return;
    }
    fill_cmd(dl, r, &st.background);
    if st.frame_width_mm > 0.0 && st.frame_color.3 > 0 {
        let (x0, y0, x1, y1) = (r.x, r.y, r.x + r.w, r.y + r.h);
        let sides = [(x0, y0, x1, y0), (x1, y0, x1, y1), (x0, y1, x1, y1), (x0, y0, x0, y1)];
        for (i, (ax, ay, bx, by)) in sides.iter().enumerate() {
            if st.borders[i] {
                dl.push(Cmd::Line { x0: *ax, y0: *ay, x1: *bx, y1: *by, color: st.frame_color, width_mm: st.frame_width_mm });
            }
        }
    }
    let text = match &st.extra_text {
        Some(x) if !x.is_empty() => format!("{text} {x}"),
        _ => text,
    };
    let pad = size_mm * 0.15;
    let box_r = RectMm { x: r.x + pad, y: r.y, w: (r.w - 2.0 * pad).max(0.1), h: r.h };
    let size = font::fit_size(&text, size_mm, box_r.w, st.bold);
    if st.underline {
        let tw = font::text_width(&text, size, st.bold);
        let x = match st.align {
            Align::Left => box_r.x,
            Align::Center => box_r.x + (box_r.w - tw) / 2.0,
            Align::Right => box_r.x + box_r.w - tw,
        };
        let y = box_r.y + box_r.h / 2.0 + size * 0.42;
        dl.push(Cmd::Line { x0: x, y0: y, x1: x + tw, y1: y, color: st.color, width_mm: (size * 0.06).max(0.1) });
    }
    dl.push(Cmd::Text { r: box_r, text, size_mm: size, bold: st.bold, italic: st.italic, color: st.color, align: st.align });
}

fn grid(dl: &mut DrawList, area: RectMm, st0: &GridStyle, year: i32, month: u32, project: &Project, dims: DimsFn) {
    let forced;
    let st = if matches!(st0.arrangement, GridArrangement::WeekColumn | GridArrangement::WeekTable) && !st0.show_week_numbers {
        forced = GridStyle { show_week_numbers: true, ..st0.clone() };
        &forced
    } else {
        st0
    };
    let lang = project.lang;
    let groups = &project.holiday_groups;
    fill_cmd(dl, area, &st.background);

    // --- header and day-name rows -------------------------------------------------
    let mut top = area.y;
    if st.show_month_name {
        let hh = area.h * 0.11;
        let r = RectMm { x: area.x, y: top, w: area.w, h: hh };
        let mut text = cell_text(project, &st.month_header.text, lang, year, month, 1, 0);
        if let Some(l2) = project.second_lang.filter(|l2| *l2 != lang) {
            if st.month_header.text.contains("[&MonthName]") {
                text = text.replacen(&project.month_name(lang, month), &format!("{} / {}", project.month_name(lang, month), project.month_name(l2, month)), 1);
            }
        }
        styled_text(dl, r, &st.month_header, text, hh * st.month_header.size.max(0.2) * 1.4);
        top += hh;
    }

    let first_wd = {
        let wd = cal::weekday(year, month, 1);
        if st.week_starts_monday { wd } else { (wd + 1) % 7 }
    };
    let ndays = cal::days_in_month(year, month);
    let weeks = ((first_wd + ndays + 6) / 7) as usize;
    let rows_shown = if st.hide_empty_cells { weeks } else { 6 };
    let day_wd = |day: u32| -> u32 {
        let wd = cal::weekday(year, month, day);
        wd // 0 = Monday (real weekday)
    };
    let col_of = |day: u32| -> usize { ((first_wd + day - 1) % 7) as usize };
    let row_of = |day: u32| -> usize { ((first_wd + day - 1) / 7) as usize };
    let real_wd_of_col = |c: usize| -> u32 { if st.week_starts_monday { c as u32 } else { (c as u32 + 6) % 7 } };

    // Day cell appearance shared by all arrangements.
    let day_cell = |dl: &mut DrawList, r: RectMm, day: u32, row: usize| {
        let wd = day_wd(day);
        let evs = holidays::events_on(groups, year, month, day);
        let off = evs.iter().find(|e| e.event.kind == EventKind::DayOff);
        let is_hol = st.highlight_holidays && off.is_some();
        let is_sat = st.highlight_saturday && wd == 5;
        let is_sun = st.highlight_sunday && wd == 6;
        let style = if is_hol || is_sat || is_sun { &st.weekends_holidays } else { &st.weekdays };
        // row background
        fill_cmd(dl, r, if row % 2 == 0 { &st.even_row } else { &st.odd_row });
        // picture attached to this day (Photo to Cell) or to a holiday/event
        let pic: Option<String> = project
            .day_photos
            .iter()
            .find(|d| d.year == year && d.month == month && d.day == day)
            .map(|d| d.path.clone())
            .or_else(|| evs.iter().find_map(|e| e.event.photo.clone().filter(|p| !p.is_empty())));
        if let Some(path) = pic {
            if let Some(d) = dims(&path) {
                dl.push(Cmd::Image { path, dest: r, crop: cover_crop(d, r, 1.0, 0.0, 0.0), opacity: 1.0, mask: None, fx: (0.0, 0.0, 0.0) });
            }
        }
        fill_shape(dl, r, &style.background, st.cell_shape);
        let mut color = style.color;
        if is_sat && !is_hol {
            color = Rgba(40, 60, 170, 255);
        }
        if is_hol {
            let e = off.unwrap();
            color = e.event.font_color.or(e.group.font_color).unwrap_or(Rgba::RED);
            if let Some(c) = e.event.cell_color.or(e.group.cell_color) {
                fill_shape(dl, r, &Fill::Color(c), st.cell_shape);
            }
        }
        let size = (r.h * style.size.max(0.1) * 1.6).min(r.w * 0.5);
        let nb = RectMm { x: r.x, y: r.y + r.h * 0.04, w: r.w - size * 0.2, h: size * 1.3 };
        let mut s = style.clone();
        s.color = color;
        s.align = Align::Right;
        s.background = Fill::None;
        styled_text(dl, nb, &s, cell_text(project, &style.text, lang, year, month, day, wd), size);
        if st.show_moon_phases {
            if let Some(q) = cal::moon_quarter_on(year, month, day) {
                let d = (r.h * 0.2).min(r.w * 0.25).max(1.5);
                let ic = RectMm { x: r.x + r.w * 0.06, y: r.y + r.h * 0.06, w: d, h: d };
                let dark = Rgba(70, 70, 90, 255);
                let light = Rgba(250, 235, 150, 255);
                match q {
                    0 => dl.push(Cmd::Ellipse { r: ic, fill: Some(dark), stroke: Some((dark, 0.2)) }),
                    2 => dl.push(Cmd::Ellipse { r: ic, fill: Some(light), stroke: Some((dark, 0.2)) }),
                    _ => {
                        dl.push(Cmd::Ellipse { r: ic, fill: Some(dark), stroke: None });
                        let (cx, cy, rad) = (ic.x + d / 2.0, ic.y + d / 2.0, d / 2.0);
                        let pts: Vec<(f32, f32)> = (0..=24)
                            .map(|i| {
                                let a = -std::f32::consts::FRAC_PI_2 + i as f32 * std::f32::consts::PI / 24.0;
                                let sx = if q == 1 { 1.0 } else { -1.0 };
                                (cx + sx * rad * a.cos(), cy + rad * a.sin())
                            })
                            .collect();
                        dl.push(Cmd::Polygon { rings: vec![pts], fill: light });
                    }
                }
            }
        }
        if st.show_holiday_names {
            let mut y = r.y + nb.h + r.h * 0.04;
            let mut seen: Vec<String> = Vec::new();
            for e in evs.iter() {
                let nm = e.event.name(lang).to_string();
                if seen.contains(&nm) {
                    continue;
                }
                seen.push(nm);
                let hs = (r.h * 0.15).min(r.w * 0.16).max(1.8);
                let hr = RectMm { x: r.x, y, w: r.w, h: hs * 1.3 };
                let mut hst = style.clone();
                hst.bold = false;
                hst.size = 0.1;
                hst.color = e.event.font_color.or(e.group.font_color).unwrap_or(color);
                hst.align = Align::Left;
                hst.background = Fill::None;
                styled_text(dl, hr, &hst, seen.last().cloned().unwrap_or_default(), hs);
                y += hs * 1.3;
                if y > r.y + r.h {
                    break;
                }
            }
        }
        let _ = (is_sun,);
    };

    let line = |dl: &mut DrawList, x0: f32, y0: f32, x1: f32, y1: f32| {
        if !st.hide_border {
            dl.push(Cmd::Line { x0, y0, x1, y1, color: st.line_color, width_mm: 0.15 });
        }
    };

    // Weekly planner arrangements: tables with week numbers always on.
    let arr = match st.arrangement {
        GridArrangement::WeekColumn => GridArrangement::TableVertical,
        GridArrangement::WeekTable => GridArrangement::TableHorizontal,
        a => a,
    };
    match arr {
        GridArrangement::TableVertical => {
            // rows = weekdays, columns = weeks
            let name_w = if st.show_day_names { area.w * 0.10 } else { 0.0 };
            let wk_h = if st.show_week_numbers { area.h * 0.05 } else { 0.0 };
            let cw = (area.w - name_w) / weeks.max(1) as f32;
            let ch = (area.y + area.h - top - wk_h) / 7.0;
            for c in 0..7 {
                let rr = RectMm { x: area.x, y: top + wk_h + c as f32 * ch, w: name_w, h: ch };
                if st.show_day_names {
                    let real = real_wd_of_col(c);
                    let ns = if real >= 5 { &st.weekend_names } else { &st.weekday_names };
                    styled_text(dl, rr, ns, cell_text(project, &ns.text, lang, year, month, 1, real), ch * ns.size.max(0.2));
                }
            }
            for day in 1..=ndays {
                let r = RectMm { x: area.x + name_w + row_of(day) as f32 * cw, y: top + wk_h + col_of(day) as f32 * ch, w: cw, h: ch };
                day_cell(dl, r, day, col_of(day));
            }
            for i in 0..=7 {
                let y = top + wk_h + i as f32 * ch;
                line(dl, area.x, y, area.x + area.w, y);
            }
            for i in 0..=weeks {
                let x = area.x + name_w + i as f32 * cw;
                line(dl, x, top + wk_h, x, top + wk_h + 7.0 * ch);
            }
        }
        GridArrangement::Row => {
            let cw = area.w / ndays as f32;
            let ch = (area.y + area.h - top).min(area.h * 0.25);
            for day in 1..=ndays {
                let r = RectMm { x: area.x + (day - 1) as f32 * cw, y: top, w: cw, h: ch };
                day_cell(dl, r, day, 0);
                if st.show_day_names {
                    let wd = day_wd(day);
                    let ns = if wd >= 5 { &st.weekend_names } else { &st.weekday_names };
                    let rr = RectMm { x: r.x, y: r.y + ch, w: cw, h: ch * 0.4 };
                    styled_text(dl, rr, ns, cell_text(project, &ns.text, lang, year, month, day, wd), ch * 0.25);
                }
                line(dl, r.x, top, r.x, top + ch * 1.4);
            }
        }
        GridArrangement::Column1 | GridArrangement::Column2 | GridArrangement::Column3 => {
            // one row per day: number, weekday name, holiday names
            let ch = (area.y + area.h - top) / ndays as f32;
            for day in 1..=ndays {
                let wd = day_wd(day);
                let y = top + (day - 1) as f32 * ch;
                let rn = RectMm { x: area.x, y, w: area.w * 0.10, h: ch };
                let ns = if wd >= 5 { &st.weekend_names } else { &st.weekday_names };
                // number
                let cell = RectMm { x: area.x, y, w: area.w, h: ch };
                let evs = holidays::events_on(groups, year, month, day);
                let off = evs.iter().find(|e| e.event.kind == EventKind::DayOff);
                let is_off = (st.highlight_holidays && off.is_some()) || (st.highlight_saturday && wd == 5) || (st.highlight_sunday && wd == 6);
                let mut num_style = if is_off { st.weekends_holidays.clone() } else { st.weekdays.clone() };
                if let Some(e) = off {
                    if st.highlight_holidays {
                        num_style.color = e.event.font_color.or(e.group.font_color).unwrap_or(Rgba::RED);
                    }
                }
                fill_cmd(dl, cell, if (day as usize) % 2 == 0 { &st.even_row } else { &st.odd_row });
                num_style.align = Align::Right;
                styled_text(dl, rn, &num_style, day.to_string(), ch * 0.55);
                let rd = RectMm { x: area.x + area.w * 0.11, y, w: area.w * 0.14, h: ch };
                let mut ds = ns.clone();
                ds.align = Align::Left;
                ds.color = num_style.color;
                styled_text(dl, rd, &ds, project.weekday_short(lang, wd), ch * 0.45);
                if st.show_holiday_names {
                    let names: Vec<&str> = evs.iter().map(|e| e.event.name(lang)).collect();
                    let rh = RectMm { x: area.x + area.w * 0.26, y, w: area.w * 0.72, h: ch };
                    let mut hs = st.weekdays.clone();
                    hs.align = Align::Left;
                    hs.bold = false;
                    hs.color = num_style.color;
                    styled_text(dl, rh, &hs, names.join(", "), ch * 0.4);
                }
                line(dl, area.x, y + ch, area.x + area.w, y + ch);
            }
        }
        // TableHorizontal, WeekTable (until week tables are implemented)
        _ => {
            let wn_w = if st.show_week_numbers { area.w * 0.08 } else { 0.0 };
            let names_h = if st.show_day_names { area.h * 0.06 } else { 0.0 };
            let cw = (area.w - wn_w) / 7.0;
            let ch = (area.y + area.h - top - names_h) / rows_shown as f32;
            if st.show_day_names {
                for c in 0..7 {
                    let real = real_wd_of_col(c);
                    let ns = if real >= 5 { &st.weekend_names } else { &st.weekday_names };
                    let rr = RectMm { x: area.x + wn_w + c as f32 * cw, y: top, w: cw, h: names_h };
                    styled_text(dl, rr, ns, cell_text(project, &ns.text, lang, year, month, 1, real), names_h * ns.size.max(0.2) * 1.8);
                }
                if st.show_week_numbers {
                    let rr = RectMm { x: area.x, y: top, w: wn_w, h: names_h };
                    styled_text(dl, rr, &st.week_numbers_header, cell_text(project, &st.week_numbers_header.text, lang, year, month, 1, 0), names_h * 0.5);
                }
            }
            let gy = top + names_h;
            for day in 1..=ndays {
                let r = RectMm { x: area.x + wn_w + col_of(day) as f32 * cw, y: gy + row_of(day) as f32 * ch, w: cw, h: ch };
                day_cell(dl, r, day, row_of(day));
            }
            if st.show_week_numbers {
                for row in 0..weeks {
                    let day = (row as u32 * 7 + 1).saturating_sub(first_wd).max(1).min(ndays);
                    let rr = RectMm { x: area.x, y: gy + row as f32 * ch, w: wn_w, h: ch };
                    styled_text(dl, rr, &st.week_numbers, cell_text(project, &st.week_numbers.text, lang, year, month, day, 0), ch * 0.25);
                }
            }
            for i in 0..=rows_shown {
                let y = gy + i as f32 * ch;
                line(dl, area.x, y, area.x + area.w, y);
            }
            for i in 0..=7 {
                let x = area.x + wn_w + i as f32 * cw;
                line(dl, x, gy, x, gy + rows_shown as f32 * ch);
            }
        }
    }
}
