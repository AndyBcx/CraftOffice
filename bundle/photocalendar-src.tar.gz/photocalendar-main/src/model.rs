//! Document model: a project is a list of pages; a page is a background plus
//! ordered layers (back to front). Templates are just saved page layouts, so
//! everything (including templates) is editable and serialisable to JSON.
use crate::cal::Lang;
use crate::holidays::HolidayGroup;
use serde::{Deserialize, Serialize};

/// Rectangle in millimetres, relative to the page's top-left corner.
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq)]
pub struct RectMm {
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq)]
pub struct Rgba(pub u8, pub u8, pub u8, pub u8);

impl Rgba {
    pub const BLACK: Rgba = Rgba(0, 0, 0, 255);
    pub const WHITE: Rgba = Rgba(255, 255, 255, 255);
    pub const RED: Rgba = Rgba(200, 30, 30, 255);
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq)]
pub enum Align {
    Left,
    Center,
    Right,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PageSize {
    pub name: String,
    pub w_mm: f32,
    pub h_mm: f32,
}

impl PageSize {
    pub fn presets() -> Vec<PageSize> {
        let p = |n: &str, w: f32, h: f32| PageSize { name: n.into(), w_mm: w, h_mm: h };
        vec![
            p("A6", 105.0, 148.0),
            p("A5", 148.0, 210.0),
            p("A4", 210.0, 297.0),
            p("A3", 297.0, 420.0),
            p("A2", 420.0, 594.0),
            p("Letter", 215.9, 279.4),
            p("Legal", 215.9, 355.6),
            p("Tabloid 11x17 in", 279.4, 431.8),
            p("12x18 in", 304.8, 457.2),
            p("150x210 mm", 150.0, 210.0),
            p("200x300 mm", 200.0, 300.0),
            p("4x6 in", 101.6, 152.4),
        ]
    }
}

/// What a text layer shows. Tokens are replaced when rendering:
/// {month} {year} {month_year}
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TextLayer {
    pub text: String,
    /// Font family ("" = the default, Liberation Sans). A family missing on this computer is
    /// drawn with a free stand-in of the same widths.
    #[serde(default)]
    pub font: String,
    pub font_size_pt: f32,
    pub bold: bool,
    pub color: Rgba,
    pub align: Align,
    pub opacity: f32,
    pub italic: bool,
    pub drop_shadow: bool,
    pub fill: Fill,
    pub outline: Option<(Rgba, f32)>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PhotoLayer {
    /// Path of the image file; None = empty placeholder slot ("Add photo").
    pub path: Option<String>,
    /// 1.0 = cover-fit; larger zooms in.
    pub zoom: f32,
    /// Pan in [-1, 1] on each axis.
    pub pan_x: f32,
    pub pan_y: f32,
    pub frame_mm: f32,
    pub frame_color: Rgba,
    pub drop_shadow: bool,
    pub outline: Option<(Rgba, f32)>,
    /// Mask shape (e.g. "ellipse", "heart"); None = rectangle.
    pub mask: Option<ShapeKind>,
    pub opacity: f32,
    pub brightness: f32,
    pub contrast: f32,
    pub saturation: f32,
}

impl PhotoLayer {
    pub fn empty() -> PhotoLayer {
        PhotoLayer {
            path: None,
            zoom: 1.0,
            pan_x: 0.0,
            pan_y: 0.0,
            frame_mm: 0.0,
            frame_color: Rgba::WHITE,
            drop_shadow: false,
            outline: None,
            mask: None,
            opacity: 1.0,
            brightness: 0.0,
            contrast: 0.0,
            saturation: 0.0,
        }
    }
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum ShapeKind {
    Circle,
    Ellipse,
    Square,
    Rectangle,
    RoundedRect,
    Triangle,
    Star,
    Arrow,
    Heart,
    Cross,
    Ring,
    Flower,
    Sun,
    Cloud,
    Moon,
    Tree,
    Leaf,
    Snowflake,
    Drop,
    House,
    Butterfly,
    /// Rectangular picture-frame border.
    Frame,
    /// A band with a wavy top edge (decoration along the page).
    Wave,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ShapeLayer {
    pub kind: ShapeKind,
    pub fill: Fill,
    pub outline: Option<(Rgba, f32)>,
    pub opacity: f32,
    pub drop_shadow: bool,
}

/// Fill used for backgrounds of cells, shapes, text.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub enum Fill {
    None,
    Color(Rgba),
    Gradient { from: Rgba, to: Rgba, vertical: bool },
    /// Texture / image file chosen by the user.
    Image(String),
}

/// Style of one kind of calendar cell (month header, weekday names, days, ...).
/// `text` may contain tokens: [&MonthName] [&Month] [&Year] [&DayNameShort]
/// [&DayName] [&Day] [&Week] [&WeekShort].
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CellStyle {
    pub text: String,
    pub font: String,
    /// Relative size (fraction of the cell height).
    pub size: f32,
    pub bold: bool,
    pub italic: bool,
    pub underline: bool,
    pub align: Align,
    pub color: Rgba,
    pub extra_text: Option<String>,
    pub frame_width_mm: f32,
    pub frame_color: Rgba,
    /// Border sides: left, right, top, bottom.
    pub borders: [bool; 4],
    pub background: Fill,
}

impl CellStyle {
    pub fn new(text: &str, size: f32, bold: bool, color: Rgba) -> CellStyle {
        CellStyle {
            text: text.into(),
            font: "Liberation Sans".into(),
            size,
            bold,
            italic: false,
            underline: false,
            align: Align::Center,
            color,
            extra_text: None,
            frame_width_mm: 0.0,
            frame_color: Rgba::BLACK,
            borders: [true; 4],
            background: Fill::None,
        }
    }
}

/// How the days of a month are arranged.
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum GridArrangement {
    TableVertical,
    TableHorizontal,
    /// All days in one row.
    Row,
    /// All days in a column (variants differ in what is shown next to the date).
    Column1,
    Column2,
    Column3,
    WeekTable,
    WeekColumn,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct GridStyle {
    pub arrangement: GridArrangement,
    pub month_header: CellStyle,
    pub weekday_names: CellStyle,
    pub weekend_names: CellStyle,
    pub weekdays: CellStyle,
    pub weekends_holidays: CellStyle,
    pub week_numbers: CellStyle,
    pub week_numbers_header: CellStyle,
    pub background: Fill,
    pub odd_row: Fill,
    pub even_row: Fill,
    pub hide_empty_cells: bool,
    pub show_month_name: bool,
    pub show_day_names: bool,
    pub show_week_numbers: bool,
    pub hide_border: bool,
    pub line_color: Rgba,
    pub show_holiday_names: bool,
    pub highlight_holidays: bool,
    pub highlight_saturday: bool,
    pub highlight_sunday: bool,
    pub week_starts_monday: bool,
    pub show_moon_phases: bool,
    /// Shape of the day-cell background (Rectangle = plain cell, Circle/RoundedRect ... = decorative).
    #[serde(default = "default_cell_shape")]
    pub cell_shape: ShapeKind,
}

fn default_cell_shape() -> ShapeKind {
    ShapeKind::Rectangle
}

impl Default for GridStyle {
    fn default() -> Self {
        let dark = Rgba(30, 30, 30, 255);
        let grey = Rgba(110, 110, 110, 255);
        let mut weekends = CellStyle::new("[&Day]", 0.30, true, dark);
        weekends.color = Rgba::RED;
        GridStyle {
            arrangement: GridArrangement::TableHorizontal,
            month_header: CellStyle::new("[&MonthName]", 0.60, true, dark),
            weekday_names: CellStyle::new("[&DayNameShort]", 0.35, true, grey),
            weekend_names: CellStyle::new("[&DayNameShort]", 0.35, true, Rgba::RED),
            weekdays: CellStyle::new("[&Day]", 0.30, false, dark),
            weekends_holidays: weekends,
            week_numbers: CellStyle::new("[&Week]", 0.25, false, grey),
            week_numbers_header: CellStyle::new("[&WeekShort]", 0.25, true, grey),
            background: Fill::Color(Rgba(255, 255, 255, 230)),
            odd_row: Fill::None,
            even_row: Fill::None,
            hide_empty_cells: false,
            show_month_name: false,
            show_day_names: true,
            show_week_numbers: false,
            hide_border: false,
            line_color: Rgba(90, 90, 90, 255),
            show_holiday_names: true,
            highlight_holidays: true,
            highlight_saturday: true,
            highlight_sunday: true,
            week_starts_monday: true,
            show_moon_phases: false,
            cell_shape: ShapeKind::Rectangle,
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct GridLayer {
    /// None = follow the page's month; Some = fixed (year, month).
    pub fixed_month: Option<(i32, u32)>,
    pub style: GridStyle,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum LayerKind {
    Photo(PhotoLayer),
    Text(TextLayer),
    /// Clipart / logo picture from a file (user-supplied only).
    Image { path: String, opacity: f32 },
    Shape(ShapeLayer),
    Grid(GridLayer),
    /// Row (or column) of binding holes / spiral marks, evenly spaced inside the layer rectangle.
    Holes { count: u32, diameter_mm: f32, vertical: bool, color: Rgba },
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Layer {
    pub name: String,
    pub rect: RectMm,
    pub rotation_deg: f32,
    pub visible: bool,
    pub locked: bool,
    pub kind: LayerKind,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum Background {
    Color(Rgba),
    Gradient { top: Rgba, bottom: Rgba },
    Image {
        path: String,
        lighten: bool,
        #[serde(default)]
        fit: BgFit,
    },
}

/// How a background picture is fitted to the page.
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, Default)]
pub enum BgFit {
    /// Cover the page, cropping the overflow.
    #[default]
    Fill,
    /// Whole picture visible, bars where it does not fit.
    Fit,
    /// Stretch to the page, ignoring the aspect ratio.
    Stretch,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Page {
    /// None = cover / free page; Some((y, m)) = month page.
    pub month: Option<(i32, u32)>,
    pub background: Background,
    /// Back to front.
    pub layers: Vec<Layer>,
}

/// A template is a named page layout (without month binding), editable and
/// savable like any other page.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Template {
    pub name: String,
    pub portrait_page: Page,
    /// Page size the template was made for (layer rectangles are scaled when applied to another size).
    #[serde(default)]
    pub w_mm: f32,
    #[serde(default)]
    pub h_mm: f32,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LangOverride {
    pub lang: Lang,
    pub months: Vec<String>,
    pub weekdays_short: Vec<String>,
    pub weekdays: Vec<String>,
    pub week_short: String,
}

impl LangOverride {
    /// Starts from the built-in names of `lang`.
    pub fn from_builtin(lang: Lang) -> LangOverride {
        LangOverride {
            lang,
            months: (1..=12).map(|m| crate::cal::month_name(lang, m).to_string()).collect(),
            weekdays_short: (0..7).map(|d| crate::cal::weekday_short(lang, d).to_string()).collect(),
            weekdays: (0..7).map(|d| crate::cal::weekday_name(lang, d).to_string()).collect(),
            week_short: crate::cal::week_short(lang).to_string(),
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DayPhoto {
    pub year: i32,
    pub month: u32,
    pub day: u32,
    /// Picture of the cell; empty = none (only a colour).
    pub path: String,
    /// Background colour of this one day cell.
    #[serde(default)]
    pub color: Option<Rgba>,
}

/// Print / PDF export layout.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ExportSettings {
    /// Paper size; None = each page on a sheet of its own size.
    pub paper: Option<PageSize>,
    pub paper_landscape: bool,
    pub margin_mm: f32,
    pub spacing_mm: f32,
    pub crop_marks: bool,
    pub cmyk: bool,
    /// "1,3,5-12"; empty = all pages
    pub page_range: String,
    pub copies: u32,
    pub jpeg_quality: u8,
    /// Shrink pages that do not fit on the paper (N-up / print-to-fit).
    #[serde(default)]
    pub fit_pages: bool,
}

impl Default for ExportSettings {
    fn default() -> Self {
        ExportSettings { paper: None, paper_landscape: false, margin_mm: 0.0, spacing_mm: 0.0, crop_marks: false, cmyk: false, page_range: String::new(), copies: 1, jpeg_quality: 92, fit_pages: false }
    }
}

/// Calendar type. Decides the default page size, layout and binding.
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum CalendarKind {
    /// Poster: the whole year on one sheet, with a main photo.
    Poster,
    /// Spiral-bound (wall) calendar, one month per page / spread.
    Spiral,
    /// Desk (tent) calendar: panels fold into a stand.
    Desk,
    /// Pocket calendar: small card, whole year or few pages.
    Pocket,
    /// Monthly planner: grid-only pages.
    Planner,
    /// A single month on one page (photo, title, grid).
    Monthly,
    /// Quarterly: three months per page with a photo (4 pages a year).
    Quarterly,
    /// Two years (24 months) on one sheet.
    TwoYear,
    /// Three years (36 months) on one sheet.
    ThreeYear,
    /// Anything else, built freely from layers.
    Custom,
}

/// Spiral-bound calendars: photo and month grid on separate pages
/// (a photo page followed by a grid page) or both on the same page.
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum PageLayout {
    SeparatePages,
    SamePage,
}

/// Where the binding is. Reserves a margin and draws punch holes / spiral marks.
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum Binding {
    None,
    /// Spiral/hole strip along the top edge of the page.
    SpiralTop,
    /// Binding in the middle: each month is a spread (photo half + grid half)
    /// folded or bound along the centre line.
    SpiralCenter,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Project {
    /// File format version (see `projfile::FORMAT_VERSION`); files without it are version 1.
    #[serde(default = "format_v1")]
    pub format_version: u32,
    /// Pictures packed into the project file ("Mentés képekkel együtt").
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub embedded_images: Vec<crate::projfile::EmbeddedImage>,
    /// User edits of month / weekday names per language (Language Editor).
    #[serde(default)]
    pub lang_overrides: Vec<LangOverride>,
    /// Pictures attached to single days (Photo to Cell).
    #[serde(default)]
    pub day_photos: Vec<DayPhoto>,
    /// Export / print layout settings.
    #[serde(default)]
    pub export: ExportSettings,
    pub title: String,
    pub kind: CalendarKind,
    pub binding: Binding,
    pub page_layout: PageLayout,
    /// Number of month pages (12 by default, free to change).
    pub months: u32,
    pub size: PageSize,
    pub landscape: bool,
    pub bleed_mm: f32,
    pub dpi: u32,
    pub start_year: i32,
    pub start_month: u32,
    pub lang: Lang,
    pub second_lang: Option<Lang>,
    pub holiday_groups: Vec<HolidayGroup>,
    pub pages: Vec<Page>,
}

fn format_v1() -> u32 {
    1
}

impl Project {
    fn ov(&self, lang: Lang) -> Option<&LangOverride> {
        self.lang_overrides.iter().find(|o| o.lang == lang)
    }
    pub fn month_name(&self, lang: Lang, m: u32) -> String {
        self.ov(lang).and_then(|o| o.months.get((m.clamp(1, 12) - 1) as usize).cloned()).unwrap_or_else(|| crate::cal::month_name(lang, m).to_string())
    }
    pub fn weekday_short(&self, lang: Lang, wd: u32) -> String {
        self.ov(lang).and_then(|o| o.weekdays_short.get((wd % 7) as usize).cloned()).unwrap_or_else(|| crate::cal::weekday_short(lang, wd).to_string())
    }
    pub fn weekday_name(&self, lang: Lang, wd: u32) -> String {
        self.ov(lang).and_then(|o| o.weekdays.get((wd % 7) as usize).cloned()).unwrap_or_else(|| crate::cal::weekday_name(lang, wd).to_string())
    }
    pub fn week_short(&self, lang: Lang) -> String {
        self.ov(lang).map(|o| o.week_short.clone()).unwrap_or_else(|| crate::cal::week_short(lang).to_string())
    }

    pub fn page_dims_mm(&self) -> (f32, f32) {
        if self.landscape {
            (self.size.h_mm.max(self.size.w_mm), self.size.h_mm.min(self.size.w_mm))
        } else {
            (self.size.h_mm.min(self.size.w_mm), self.size.h_mm.max(self.size.w_mm))
        }
    }

    pub fn save(&self, path: &std::path::Path) -> std::io::Result<()> {
        crate::projfile::save(self, path, false).map(|_| ())
    }

    pub fn load(path: &std::path::Path) -> std::io::Result<Project> {
        crate::projfile::load(path).map(|(p, _)| p).map_err(|e| std::io::Error::other(e.to_string()))
    }
}

pub fn layer(name: &str, rect: RectMm, kind: LayerKind) -> Layer {
    Layer { name: name.into(), rect, rotation_deg: 0.0, visible: true, locked: false, kind }
}

/// Built-in original template: photo on top, title, grid below (portrait) —
/// or photo left / grid right when the page is landscape. All coordinates are
/// derived from the page size so any size works.
pub fn default_month_page(w: f32, h: f32, y: i32, m: u32) -> Page {
    let margin = w.min(h) * 0.05;
    let landscape = w > h;
    let (photo, title, grid) = if landscape {
        let pw = (w - 3.0 * margin) * 0.52;
        let gx = margin * 2.0 + pw;
        let gw = w - gx - margin;
        (
            RectMm { x: margin, y: margin, w: pw, h: h - 2.0 * margin },
            RectMm { x: gx, y: margin, w: gw, h: h * 0.10 },
            RectMm { x: gx, y: margin + h * 0.12, w: gw, h: h - 2.0 * margin - h * 0.12 },
        )
    } else {
        let ph = (h - 3.0 * margin) * 0.50;
        (
            RectMm { x: margin, y: margin, w: w - 2.0 * margin, h: ph },
            RectMm { x: margin, y: margin * 2.0 + ph, w: w - 2.0 * margin, h: h * 0.07 },
            RectMm {
                x: margin,
                y: margin * 2.0 + ph + h * 0.08,
                w: w - 2.0 * margin,
                h: h - margin - (margin * 2.0 + ph + h * 0.08),
            },
        )
    };
    let size_pt = (title.h * 0.55 / 0.3528).clamp(10.0, 60.0);
    Page {
        month: Some((y, m)),
        background: Background::Color(Rgba::WHITE),
        layers: vec![
            layer(
                "Fotó",
                photo,
                LayerKind::Photo(PhotoLayer::empty()),
            ),
            layer(
                "Hónap címe",
                title,
                LayerKind::Text(TextLayer {
                    font: String::new(),
                    text: "{month} {year}".into(),
                    font_size_pt: size_pt,
                    bold: true,
                    color: Rgba(40, 40, 40, 255),
                    align: Align::Center,
                    opacity: 1.0,
                    italic: false,
                    drop_shadow: false,
                    fill: Fill::Color(Rgba(40, 40, 40, 255)),
                    outline: None,
                }),
            ),
            layer("Naptárrács", grid, LayerKind::Grid(GridLayer { fixed_month: None, style: GridStyle::default() })),
        ],
    }
}

impl Project {
    /// New 12-month wall/spiral calendar with the built-in layout and the
    /// Hungarian + Romanian holiday groups.
    pub fn new_default(size: PageSize, landscape: bool, year: i32, month: u32, lang: Lang) -> Project {
        let mut p = Project {
            title: "Új naptár".into(),
            kind: CalendarKind::Spiral,
            binding: Binding::None,
            page_layout: PageLayout::SamePage,
            months: 12,
            size,
            landscape,
            bleed_mm: 0.0,
            dpi: 300,
            start_year: year,
            start_month: month,
            lang,
            second_lang: None,
            holiday_groups: vec![crate::holidays::builtin_hungary(), crate::holidays::builtin_romania()],
            pages: vec![],
            lang_overrides: vec![],
            day_photos: vec![],
            export: ExportSettings::default(),
            format_version: crate::projfile::FORMAT_VERSION,
            embedded_images: vec![],
        };
        p.rebuild_pages();
        p
    }

    /// Regenerates the pages from the current settings (calendar type, binding, size ...).
    /// Photos already placed are kept, in order.
    pub fn rebuild_pages(&mut self) {
        self.pages = crate::generate::generate_pages(self);
    }
}

impl GridStyle {
    /// Change every text style of the grid (month header, day names, days, week numbers).
    pub fn for_each_cell_style(&mut self, mut f: impl FnMut(&mut CellStyle)) {
        for cs in [&mut self.month_header, &mut self.weekday_names, &mut self.weekend_names, &mut self.weekdays, &mut self.weekends_holidays, &mut self.week_numbers, &mut self.week_numbers_header] {
            f(cs);
        }
    }
}
