//! Holiday groups: editable, rule-based, per-country. Built-in groups are only
//! starting data and MUST be verified against the official lists before printing.
use crate::cal::{self, Lang};
use crate::model::Rgba;
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum EventKind {
    /// Non-working day (usually highlighted).
    DayOff,
    /// Observance on a working day.
    Workday,
    /// Birthday / anniversary: shown by name, never highlighted as a day off.
    Anniversary,
    /// Name day (entered by the user, there is no built-in name-day list): shown by name.
    NameDay,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum DateRule {
    /// Same date every year.
    Fixed { month: u32, day: u32 },
    /// One specific date.
    Once { year: i32, month: u32, day: u32 },
    /// n-th weekday of a month (weekday 0 = Monday, n = 1..5).
    NthWeekday { month: u32, nth: u32, weekday: u32 },
    /// Offset in days from Western (Gregorian) Easter Sunday.
    EasterWestern(i32),
    /// Offset in days from Orthodox Easter Sunday.
    EasterOrthodox(i32),
}

impl DateRule {
    /// Resolve to (month, day) in the given year, if it falls in that year.
    pub fn resolve(&self, year: i32) -> Option<(u32, u32)> {
        match *self {
            DateRule::Fixed { month, day } => {
                if day <= cal::days_in_month(year, month) {
                    Some((month, day))
                } else {
                    None
                }
            }
            DateRule::Once { year: y, month, day } => (y == year).then_some((month, day)),
            DateRule::NthWeekday { month, nth, weekday } => {
                let first = cal::weekday(year, month, 1);
                let d = 1 + (7 + weekday - first) % 7 + 7 * (nth - 1);
                (d <= cal::days_in_month(year, month)).then_some((month, d))
            }
            DateRule::EasterWestern(off) => {
                let (y, m, d) = cal::from_days(cal::easter_western(year) + off as i64);
                (y == year).then_some((m, d))
            }
            DateRule::EasterOrthodox(off) => {
                let (y, m, d) = cal::from_days(cal::easter_orthodox(year) + off as i64);
                (y == year).then_some((m, d))
            }
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Event {
    /// Names per language; the first entry is the fallback.
    pub names: Vec<(Lang, String)>,
    pub kind: EventKind,
    pub rule: DateRule,
    pub font_color: Option<Rgba>,
    pub cell_color: Option<Rgba>,
    /// Optional picture shown in the day cell.
    pub photo: Option<String>,
    /// The event only applies from this year on (e.g. a newly declared holiday).
    #[serde(default)]
    pub from_year: Option<i32>,
}

impl Event {
    pub fn name(&self, lang: Lang) -> &str {
        self.names
            .iter()
            .find(|(l, _)| *l == lang)
            .or_else(|| self.names.first())
            .map(|(_, n)| n.as_str())
            .unwrap_or("")
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct HolidayGroup {
    pub name: String,
    pub enabled: bool,
    /// Group style, used when an event has no colour of its own.
    pub font_color: Option<Rgba>,
    pub cell_color: Option<Rgba>,
    pub events: Vec<Event>,
}

impl HolidayGroup {
    pub fn new(name: &str) -> HolidayGroup {
        HolidayGroup { name: name.into(), enabled: true, font_color: None, cell_color: None, events: vec![] }
    }
}

fn ev(hu: &str, ro: &str, en: &str, kind: EventKind, rule: DateRule) -> Event {
    Event {
        names: vec![(Lang::Hu, hu.into()), (Lang::Ro, ro.into()), (Lang::En, en.into())],
        kind,
        rule,
        font_color: None,
        cell_color: None,
        photo: None,
        from_year: None,
    }
}

fn fixed(month: u32, day: u32) -> DateRule {
    DateRule::Fixed { month, day }
}

pub fn builtin_hungary() -> HolidayGroup {
    use EventKind::DayOff as D;
    let mut g = HolidayGroup::new("Magyar ünnepek");
    g.events = vec![
        ev("Újév", "Anul Nou", "New Year's Day", D, fixed(1, 1)),
        ev("Nemzeti ünnep", "Ziua națională (1848)", "National Day (1848)", D, fixed(3, 15)),
        ev("Nagypéntek", "Vinerea Mare", "Good Friday", D, DateRule::EasterWestern(-2)),
        ev("Húsvétvasárnap", "Paștele catolic", "Easter Sunday", D, DateRule::EasterWestern(0)),
        ev("Húsvéthétfő", "Lunea Paștelui", "Easter Monday", D, DateRule::EasterWestern(1)),
        ev("A munka ünnepe", "Ziua Muncii", "Labour Day", D, fixed(5, 1)),
        ev("Pünkösdvasárnap", "Rusaliile", "Whit Sunday", D, DateRule::EasterWestern(49)),
        ev("Pünkösdhétfő", "Lunea Rusaliilor", "Whit Monday", D, DateRule::EasterWestern(50)),
        ev("Államalapítás ünnepe", "Ziua Sfântului Ștefan", "St Stephen's Day", D, fixed(8, 20)),
        ev("Nemzeti ünnep", "Ziua națională (1956)", "National Day (1956)", D, fixed(10, 23)),
        ev("Mindenszentek", "Ziua Tuturor Sfinților", "All Saints' Day", D, fixed(11, 1)),
        Event { from_year: Some(2026), ..ev("Szenteste", "Ajunul Crăciunului", "Christmas Eve", D, fixed(12, 24)) },
        ev("Karácsony", "Crăciun", "Christmas Day", D, fixed(12, 25)),
        ev("Karácsony másnapja", "A doua zi de Crăciun", "Boxing Day", D, fixed(12, 26)),
    ];
    g
}

pub fn builtin_romania() -> HolidayGroup {
    use EventKind::DayOff as D;
    let mut g = HolidayGroup::new("Román ünnepek");
    g.events = vec![
        ev("Újév", "Anul Nou", "New Year's Day", D, fixed(1, 1)),
        ev("Újév másnapja", "A doua zi de Anul Nou", "2nd day of the New Year", D, fixed(1, 2)),
        ev("Vízkereszt", "Boboteaza", "Epiphany", D, fixed(1, 6)),
        ev("Szent János", "Sfântul Ioan Botezătorul", "St John the Baptist", D, fixed(1, 7)),
        ev("Az Egyesülés napja", "Ziua Unirii Principatelor", "Union Day", D, fixed(1, 24)),
        ev("Nagypéntek (ortodox)", "Vinerea Mare", "Orthodox Good Friday", D, DateRule::EasterOrthodox(-2)),
        ev("Ortodox húsvét", "Paștele ortodox", "Orthodox Easter", D, DateRule::EasterOrthodox(0)),
        ev("Ortodox húsvéthétfő", "A doua zi de Paște", "Orthodox Easter Monday", D, DateRule::EasterOrthodox(1)),
        ev("A munka ünnepe", "Ziua Muncii", "Labour Day", D, fixed(5, 1)),
        ev("Gyermeknap", "Ziua Copilului", "Children's Day", D, fixed(6, 1)),
        ev("Ortodox pünkösd", "Rusaliile", "Orthodox Pentecost", D, DateRule::EasterOrthodox(49)),
        ev("Ortodox pünkösdhétfő", "A doua zi de Rusalii", "Orthodox Whit Monday", D, DateRule::EasterOrthodox(50)),
        ev("Nagyboldogasszony", "Adormirea Maicii Domnului", "Dormition of the Theotokos", D, fixed(8, 15)),
        ev("Szent András", "Sfântul Andrei", "St Andrew's Day", D, fixed(11, 30)),
        ev("Románia nemzeti ünnepe", "Ziua Națională a României", "National Day of Romania", D, fixed(12, 1)),
        ev("Karácsony", "Crăciunul", "Christmas Day", D, fixed(12, 25)),
        ev("Karácsony másnapja", "A doua zi de Crăciun", "Boxing Day", D, fixed(12, 26)),
    ];
    g
}

/// An event that falls on a given day, with its resolved style.
#[derive(Clone, Debug)]
pub struct DayEvent<'a> {
    pub event: &'a Event,
    pub group: &'a HolidayGroup,
}

/// All events of the enabled groups on (year, month, day).
pub fn events_on<'a>(groups: &'a [HolidayGroup], year: i32, month: u32, day: u32) -> Vec<DayEvent<'a>> {
    let mut out = Vec::new();
    for g in groups.iter().filter(|g| g.enabled) {
        for e in &g.events {
            if e.from_year.is_none_or(|y| year >= y) && e.rule.resolve(year) == Some((month, day)) {
                out.push(DayEvent { event: e, group: g });
            }
        }
    }
    out
}

/// True if any enabled DayOff event falls on that day.
pub fn is_day_off(groups: &[HolidayGroup], year: i32, month: u32, day: u32) -> bool {
    events_on(groups, year, month, day).iter().any(|d| d.event.kind == EventKind::DayOff)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rules() {
        // Thanksgiving-style: 4th Thursday of November 2026 = Nov 26
        let r = DateRule::NthWeekday { month: 11, nth: 4, weekday: 3 };
        assert_eq!(r.resolve(2026), Some((11, 26)));
        let hu = vec![builtin_hungary()];
        assert!(is_day_off(&hu, 2026, 4, 6)); // Easter Monday 2026
        assert!(!is_day_off(&hu, 2026, 4, 7));
        let ro = vec![builtin_romania()];
        assert!(is_day_off(&ro, 2026, 4, 13)); // Orthodox Easter Monday 2026
    }
}

// ---------------------------------------------------------------------------------------
// CSV / Excel import and export
// ---------------------------------------------------------------------------------------

/// Columns: group; kind (off|work|anniv); name_hu; name_ro; name_en; rule; a; b; c
/// rules: fixed(month,day) once(year,month,day) nth(month,nth,weekday 0=Mon) easterw(offset) easterorth(offset)
pub fn export_csv(groups: &[HolidayGroup]) -> String {
    let mut out = String::from("group;kind;name_hu;name_ro;name_en;rule;a;b;c\n");
    let clean = |s: &str| s.replace([';', '\n', '\r'], " ");
    for g in groups {
        for e in &g.events {
            let nm = |l: Lang| e.names.iter().find(|(x, _)| *x == l).map(|(_, n)| clean(n)).unwrap_or_default();
            let kind = match e.kind {
                EventKind::DayOff => "off",
                EventKind::Workday => "work",
                EventKind::Anniversary => "anniv",
                EventKind::NameDay => "nameday",
            };
            let (rule, a, b, c) = match e.rule {
                DateRule::Fixed { month, day } => ("fixed", month as i64, day as i64, 0),
                DateRule::Once { year, month, day } => ("once", year as i64, month as i64, day as i64),
                DateRule::NthWeekday { month, nth, weekday } => ("nth", month as i64, nth as i64, weekday as i64),
                DateRule::EasterWestern(o) => ("easterw", o as i64, 0, 0),
                DateRule::EasterOrthodox(o) => ("easterorth", o as i64, 0, 0),
            };
            out.push_str(&format!("{};{};{};{};{};{};{};{};{}\n", clean(&g.name), kind, nm(Lang::Hu), nm(Lang::Ro), nm(Lang::En), rule, a, b, c));
        }
    }
    out
}

fn event_from_fields(f: &[String]) -> Option<(String, Event)> {
    if f.len() < 9 {
        return None;
    }
    let kind = match f[1].trim().to_lowercase().as_str() {
        "off" | "dayoff" => EventKind::DayOff,
        "anniv" | "birthday" => EventKind::Anniversary,
        "nameday" | "nevnap" | "névnap" => EventKind::NameDay,
        _ => EventKind::Workday,
    };
    let n = |i: usize| f[i].trim().parse::<f64>().ok().map(|v| v as i64);
    let (a, b, c) = (n(6).unwrap_or(0), n(7).unwrap_or(0), n(8).unwrap_or(0));
    let rule = match f[5].trim().to_lowercase().as_str() {
        "fixed" => DateRule::Fixed { month: a as u32, day: b as u32 },
        "once" => DateRule::Once { year: a as i32, month: b as u32, day: c as u32 },
        "nth" => DateRule::NthWeekday { month: a as u32, nth: b as u32, weekday: c as u32 },
        "easterw" => DateRule::EasterWestern(a as i32),
        "easterorth" => DateRule::EasterOrthodox(a as i32),
        _ => return None,
    };
    let mut names = vec![];
    for (l, i) in [(Lang::Hu, 2), (Lang::Ro, 3), (Lang::En, 4)] {
        if !f[i].trim().is_empty() {
            names.push((l, f[i].trim().to_string()));
        }
    }
    if names.is_empty() {
        return None;
    }
    Some((f[0].trim().to_string(), Event { names, kind, rule, font_color: None, cell_color: None, photo: None, from_year: None }))
}

fn collect(rows: Vec<Vec<String>>) -> Vec<HolidayGroup> {
    let mut groups: Vec<HolidayGroup> = vec![];
    for r in rows {
        if let Some((gname, ev)) = event_from_fields(&r) {
            match groups.iter_mut().find(|g| g.name == gname) {
                Some(g) => g.events.push(ev),
                None => {
                    let mut g = HolidayGroup::new(&gname);
                    g.events.push(ev);
                    groups.push(g);
                }
            }
        }
    }
    groups
}

pub fn import_csv(text: &str) -> Vec<HolidayGroup> {
    let rows = text.lines().skip(1).map(|l| l.split(';').map(|x| x.to_string()).collect()).collect();
    collect(rows)
}

/// Reads the first sheet of an .xlsx/.xls/.ods file with the same columns as the CSV (first row = header).
pub fn import_excel(path: &std::path::Path) -> Result<Vec<HolidayGroup>, String> {
    use calamine::{open_workbook_auto, Data, Reader};
    let mut wb = open_workbook_auto(path).map_err(|e| e.to_string())?;
    let name = wb.sheet_names().first().cloned().ok_or("üres munkafüzet")?;
    let range = wb.worksheet_range(&name).map_err(|e| e.to_string())?;
    let rows = range
        .rows()
        .skip(1)
        .map(|r| {
            r.iter()
                .map(|c| match c {
                    Data::String(s) => s.clone(),
                    Data::Float(f) => format!("{f}"),
                    Data::Int(i) => i.to_string(),
                    _ => String::new(),
                })
                .collect()
        })
        .collect();
    Ok(collect(rows))
}

#[cfg(test)]
mod csv_tests {
    use super::*;
    #[test]
    fn roundtrip() {
        let g = vec![builtin_hungary()];
        let csv = export_csv(&g);
        let back = import_csv(&csv);
        assert_eq!(back.len(), 1);
        assert_eq!(back[0].events.len(), g[0].events.len());
        assert_eq!(back[0].events[0].rule, g[0].events[0].rule);
    }
}

#[cfg(test)]
mod from_year_tests {
    use super::*;
    #[test]
    fn christmas_eve_only_from_2026() {
        let g = [builtin_hungary()];
        assert!(events_on(&g, 2025, 12, 24).is_empty());
        assert_eq!(events_on(&g, 2026, 12, 24).len(), 1);
        assert_eq!(events_on(&g, 2027, 12, 24).len(), 1);
    }
}

#[cfg(test)]
mod event_checks {
    use super::*;

    #[test]
    fn hungarian_holidays_with_easter_and_pentecost() {
        let g = vec![builtin_hungary()];
        for (m, d) in [(1, 1), (3, 15), (5, 1), (8, 20), (10, 23), (11, 1), (12, 25), (12, 26)] {
            assert!(is_day_off(&g, 2027, m, d), "{m}.{d}");
        }
        // Good Friday, Easter Monday, Whit Monday 2027
        assert!(is_day_off(&g, 2027, 3, 26));
        assert!(is_day_off(&g, 2027, 3, 29));
        assert!(is_day_off(&g, 2027, 5, 17));
        assert!(!is_day_off(&g, 2027, 5, 18));
    }

    #[test]
    fn recurring_and_one_off_events() {
        let mut g = HolidayGroup::new("Család");
        let bd = |kind, rule| Event { names: vec![(Lang::Hu, "Anna".into())], kind, rule, font_color: None, cell_color: None, photo: None, from_year: None };
        g.events.push(bd(EventKind::Anniversary, DateRule::Fixed { month: 2, day: 29 }));
        g.events.push(bd(EventKind::NameDay, DateRule::Fixed { month: 7, day: 26 }));
        g.events.push(bd(EventKind::Workday, DateRule::Once { year: 2027, month: 12, day: 11 }));
        let gs = vec![g];
        // every year
        assert_eq!(events_on(&gs, 2027, 7, 26).len(), 1);
        assert_eq!(events_on(&gs, 2031, 7, 26).len(), 1);
        // 29 February only in leap years
        assert_eq!(events_on(&gs, 2028, 2, 29).len(), 1);
        assert!(DateRule::Fixed { month: 2, day: 29 }.resolve(2027).is_none());
        // a one-off date only in its year, and name days never make a day off
        assert_eq!(events_on(&gs, 2027, 12, 11).len(), 1);
        assert_eq!(events_on(&gs, 2028, 12, 11).len(), 0);
        assert!(!is_day_off(&gs, 2027, 7, 26));
        // CSV keeps the name-day kind
        let csv = export_csv(&gs);
        assert!(csv.contains("nameday"));
        let back = import_csv(&csv);
        assert!(back[0].events.iter().any(|e| e.kind == EventKind::NameDay));
    }
}
