//! Built-in vector clipart: original compositions of the built-in shapes. Inserting one
//! creates ordinary shape layers, so every part stays editable (colour, size, outline ...).
use crate::model::*;

struct Piece {
    kind: ShapeKind,
    /// position and size relative to the clipart rectangle (0..1)
    u: (f32, f32, f32, f32),
    color: Rgba,
    outline: Option<Rgba>,
}

fn p(kind: ShapeKind, u: (f32, f32, f32, f32), c: (u8, u8, u8)) -> Piece {
    Piece { kind, u, color: Rgba(c.0, c.1, c.2, 255), outline: None }
}

fn po(kind: ShapeKind, u: (f32, f32, f32, f32), c: (u8, u8, u8), o: (u8, u8, u8)) -> Piece {
    Piece { kind, u, color: Rgba(c.0, c.1, c.2, 255), outline: Some(Rgba(o.0, o.1, o.2, 255)) }
}

const FULL: (f32, f32, f32, f32) = (0.0, 0.0, 1.0, 1.0);

pub fn names() -> Vec<&'static str> {
    vec![
        "Virág", "Napocska", "Felhő", "Hold", "Fenyőfa", "Hópehely", "Szív", "Csillag", "Levél", "Csepp",
        "Házikó", "Pillangó", "Hóember", "Húsvéti tojás", "Tök", "Keret (oldal)",
    ]
}

fn pieces(name: &str) -> Vec<Piece> {
    use ShapeKind::*;
    match name {
        "Virág" => vec![p(Flower, FULL, (255, 150, 190)), p(Circle, (0.35, 0.35, 0.3, 0.3), (255, 210, 60))],
        "Napocska" => vec![p(Sun, FULL, (255, 200, 40)), p(Circle, (0.22, 0.22, 0.56, 0.56), (255, 150, 30))],
        "Felhő" => vec![p(Cloud, FULL, (200, 225, 250))],
        "Hold" => vec![p(Moon, FULL, (250, 225, 120))],
        "Fenyőfa" => vec![p(Tree, FULL, (40, 130, 60)), p(Rectangle, (0.43, 0.85, 0.14, 0.15), (110, 70, 40))],
        "Hópehely" => vec![p(Snowflake, FULL, (140, 195, 240))],
        "Szív" => vec![p(Heart, FULL, (220, 40, 70))],
        "Csillag" => vec![p(Star, FULL, (250, 195, 30))],
        "Levél" => vec![p(Leaf, FULL, (70, 150, 60))],
        "Csepp" => vec![p(Drop, FULL, (70, 150, 230))],
        "Házikó" => vec![
            p(House, FULL, (225, 190, 150)),
            p(Triangle, (0.05, 0.05, 0.9, 0.43), (190, 60, 50)),
            p(Rectangle, (0.42, 0.65, 0.16, 0.35), (120, 80, 50)),
        ],
        "Pillangó" => vec![p(Butterfly, FULL, (240, 140, 40)), p(Ellipse, (0.46, 0.15, 0.08, 0.7), (50, 40, 40))],
        "Hóember" => vec![
            po(Circle, (0.12, 0.52, 0.76, 0.48), (255, 255, 255), (150, 160, 180)),
            po(Circle, (0.24, 0.26, 0.52, 0.36), (255, 255, 255), (150, 160, 180)),
            po(Circle, (0.33, 0.02, 0.34, 0.28), (255, 255, 255), (150, 160, 180)),
            p(Circle, (0.40, 0.09, 0.05, 0.04), (30, 30, 30)),
            p(Circle, (0.55, 0.09, 0.05, 0.04), (30, 30, 30)),
            p(Triangle, (0.46, 0.14, 0.08, 0.07), (240, 130, 30)),
        ],
        "Húsvéti tojás" => vec![
            p(Ellipse, (0.2, 0.05, 0.6, 0.9), (250, 170, 200)),
            p(Rectangle, (0.21, 0.46, 0.58, 0.08), (110, 170, 240)),
        ],
        "Tök" => vec![
            p(Rectangle, (0.45, 0.02, 0.1, 0.2), (70, 130, 50)),
            p(Ellipse, (0.05, 0.18, 0.9, 0.78), (245, 130, 30)),
            p(Triangle, (0.25, 0.38, 0.18, 0.18), (60, 30, 10)),
            p(Triangle, (0.57, 0.38, 0.18, 0.18), (60, 30, 10)),
            p(Rectangle, (0.3, 0.7, 0.4, 0.08), (60, 30, 10)),
        ],
        "Keret (oldal)" => vec![p(Frame, FULL, (90, 90, 90))],
        _ => vec![],
    }
}

/// Layers for clipart `name` placed inside `rect` (mm).
pub fn instantiate(name: &str, rect: RectMm) -> Vec<Layer> {
    pieces(name)
        .into_iter()
        .map(|pc| {
            let r = RectMm { x: rect.x + pc.u.0 * rect.w, y: rect.y + pc.u.1 * rect.h, w: pc.u.2 * rect.w, h: pc.u.3 * rect.h };
            layer(
                &format!("Clipart: {name}"),
                r,
                LayerKind::Shape(ShapeLayer {
                    kind: pc.kind,
                    fill: Fill::Color(pc.color),
                    outline: pc.outline.map(|c| (c, 0.4)),
                    opacity: 1.0,
                    drop_shadow: false,
                }),
            )
        })
        .collect()
}
