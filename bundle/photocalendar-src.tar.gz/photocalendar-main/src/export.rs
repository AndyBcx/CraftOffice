//! Print / export preparation: page ranges, bleed, crop marks, margins and N-up sheet layout.
//! Everything is done on DrawLists, so PDF and image exports share it.
use crate::draw::{Cmd, DrawList};
use crate::layout;
use crate::model::*;

/// Parses "1,3,5-12" into 0-based page indices (clamped to `n`); empty text = all pages.
pub fn parse_range(s: &str, n: usize) -> Vec<usize> {
    let s = s.trim();
    if s.is_empty() {
        return (0..n).collect();
    }
    let mut out = vec![];
    for part in s.split([',', ';']) {
        let part = part.trim();
        if part.is_empty() {
            continue;
        }
        let (a, b) = match part.split_once('-') {
            Some((a, b)) => (a.trim().parse::<usize>().ok(), b.trim().parse::<usize>().ok()),
            None => {
                let v = part.parse::<usize>().ok();
                (v, v)
            }
        };
        if let (Some(a), Some(b)) = (a, b) {
            let (lo, hi) = (a.min(b).max(1), a.max(b));
            for p in lo..=hi.min(n) {
                out.push(p - 1);
            }
        }
    }
    out
}

pub fn translate_cmds(cmds: &[Cmd], dx: f32, dy: f32) -> Vec<Cmd> {
    transform_cmds(cmds, 1.0, dx, dy)
}

/// Scales by `k` about the origin, then translates: x' = x*k + dx.
pub fn transform_cmds(cmds: &[Cmd], k: f32, dx: f32, dy: f32) -> Vec<Cmd> {
    let mv = |r: RectMm| RectMm { x: r.x * k + dx, y: r.y * k + dy, w: r.w * k, h: r.h * k };
    let pt = |p: &(f32, f32)| (p.0 * k + dx, p.1 * k + dy);
    cmds.iter()
        .map(|c| match c {
            Cmd::Rect { r, fill, stroke } => Cmd::Rect { r: mv(*r), fill: *fill, stroke: stroke.map(|(c, w)| (c, w * k)) },
            Cmd::Gradient { r, from, to, vertical } => Cmd::Gradient { r: mv(*r), from: *from, to: *to, vertical: *vertical },
            Cmd::Ellipse { r, fill, stroke } => Cmd::Ellipse { r: mv(*r), fill: *fill, stroke: stroke.map(|(c, w)| (c, w * k)) },
            Cmd::Line { x0, y0, x1, y1, color, width_mm } => Cmd::Line { x0: x0 * k + dx, y0: y0 * k + dy, x1: x1 * k + dx, y1: y1 * k + dy, color: *color, width_mm: width_mm * k },
            Cmd::Text { r, text, size_mm, bold, italic, color, align, font } => Cmd::Text { r: mv(*r), text: text.clone(), size_mm: size_mm * k, bold: *bold, italic: *italic, color: *color, align: *align, font: font.clone() },
            Cmd::Image { path, dest, crop, opacity, mask, fx } => Cmd::Image {
                path: path.clone(),
                dest: mv(*dest),
                crop: *crop,
                opacity: *opacity,
                mask: mask.as_ref().map(|m| m.iter().map(|g| g.iter().map(pt).collect()).collect()),
                fx: *fx,
            },
            Cmd::Polygon { rings, fill } => Cmd::Polygon { rings: rings.iter().map(|g| g.iter().map(pt).collect()).collect(), fill: *fill },
            Cmd::Group { rot_deg, cx, cy, cmds } => Cmd::Group { rot_deg: *rot_deg, cx: cx * k + dx, cy: cy * k + dy, cmds: transform_cmds(cmds, k, dx, dy) },
        })
        .collect()
}

/// Page with bleed: canvas grows by `bleed` on every side, the page background is stretched into it.
pub fn with_bleed(dl: &DrawList, bleed: f32) -> DrawList {
    if bleed <= 0.0 {
        return dl.clone();
    }
    let mut cmds = translate_cmds(&dl.cmds, bleed, bleed);
    let (pw, ph) = (dl.w_mm, dl.h_mm);
    let covers = |r: &RectMm| r.x <= bleed + 0.05 && r.y <= bleed + 0.05 && (r.w - pw).abs() < 0.1 && (r.h - ph).abs() < 0.1;
    let full = RectMm { x: 0.0, y: 0.0, w: pw + 2.0 * bleed, h: ph + 2.0 * bleed };
    // every layer that exactly covers the page (backgrounds, full-bleed photos) is stretched into the bleed
    for c in cmds.iter_mut() {
        match c {
            Cmd::Rect { r, .. } | Cmd::Gradient { r, .. } if covers(r) => *r = full,
            Cmd::Image { dest, crop, mask: None, .. } if covers(dest) => {
                let du = (crop.2 - crop.0) * bleed / pw;
                let dv = (crop.3 - crop.1) * bleed / ph;
                *crop = ((crop.0 - du).max(0.0), (crop.1 - dv).max(0.0), (crop.2 + du).min(1.0), (crop.3 + dv).min(1.0));
                *dest = full;
            }
            _ => {}
        }
    }
    DrawList { w_mm: dl.w_mm + 2.0 * bleed, h_mm: dl.h_mm + 2.0 * bleed, cmds }
}

/// Adds crop (trim) marks around the trim box, which sits `bleed` inside `dl`; the canvas grows by `slug`.
pub fn with_marks(dl: &DrawList, bleed: f32, slug: f32) -> DrawList {
    let mut cmds = translate_cmds(&dl.cmds, slug, slug);
    let (tx0, ty0) = (slug + bleed, slug + bleed);
    let (tx1, ty1) = (slug + dl.w_mm - bleed, slug + dl.h_mm - bleed);
    let k = Rgba(0, 0, 0, 255);
    let (gap, len) = (bleed + 1.0, (slug - bleed - 1.5).max(2.0));
    for (x, y, sx, sy) in [(tx0, ty0, -1.0, -1.0), (tx1, ty0, 1.0, -1.0), (tx0, ty1, -1.0, 1.0), (tx1, ty1, 1.0, 1.0)] {
        cmds.push(Cmd::Line { x0: x + sx * gap, y0: y, x1: x + sx * (gap + len), y1: y, color: k, width_mm: 0.15 });
        cmds.push(Cmd::Line { x0: x, y0: y + sy * gap, x1: x, y1: y + sy * (gap + len), color: k, width_mm: 0.15 });
    }
    DrawList { w_mm: dl.w_mm + 2.0 * slug, h_mm: dl.h_mm + 2.0 * slug, cmds }
}

/// Final sheets of an export: page selection, bleed, marks, then margins / N-up tiling on the paper.
pub fn prepare(project: &Project, dims: layout::DimsFn) -> Vec<DrawList> {
    let ex = &project.export;
    let idx = parse_range(&ex.page_range, project.pages.len());
    let bleed = project.bleed_mm.max(0.0);
    let slug = if ex.crop_marks { bleed + 7.0 } else { 0.0 };
    let pages: Vec<DrawList> = idx
        .into_iter()
        .map(|i| {
            let mut d = layout::render_page(project, i, dims);
            if bleed > 0.0 {
                d = with_bleed(&d, bleed);
            }
            if ex.crop_marks {
                d = with_marks(&d, bleed, slug);
            }
            d
        })
        .collect();
    let margin = ex.margin_mm.max(0.0);
    match &ex.paper {
        None => pages
            .into_iter()
            .map(|d| {
                if margin > 0.0 {
                    DrawList { w_mm: d.w_mm + 2.0 * margin, h_mm: d.h_mm + 2.0 * margin, cmds: translate_cmds(&d.cmds, margin, margin) }
                } else {
                    d
                }
            })
            .collect(),
        Some(p) => {
            let (pw, ph) = if ex.paper_landscape { (p.w_mm.max(p.h_mm), p.w_mm.min(p.h_mm)) } else { (p.w_mm.min(p.h_mm), p.w_mm.max(p.h_mm)) };
            let sp = ex.spacing_mm.max(0.0);
            let mut sheets: Vec<DrawList> = vec![];
            let (mut x, mut y, mut row_h) = (margin, margin, 0.0f32);
            let (aw, ah) = ((pw - 2.0 * margin).max(1.0), (ph - 2.0 * margin).max(1.0));
            for mut d in pages {
                if ex.fit_pages && (d.w_mm > aw + 0.01 || d.h_mm > ah + 0.01) {
                    let k = (aw / d.w_mm).min(ah / d.h_mm);
                    d = DrawList { w_mm: d.w_mm * k, h_mm: d.h_mm * k, cmds: transform_cmds(&d.cmds, k, 0.0, 0.0) };
                }
                if sheets.is_empty() {
                    sheets.push(DrawList::new(pw, ph));
                }
                if x + d.w_mm > pw - margin + 0.01 && x > margin {
                    x = margin;
                    y += row_h + sp;
                    row_h = 0.0;
                }
                if y + d.h_mm > ph - margin + 0.01 && y > margin {
                    sheets.push(DrawList::new(pw, ph));
                    x = margin;
                    y = margin;
                    row_h = 0.0;
                }
                let sheet = sheets.last_mut().unwrap();
                sheet.cmds.extend(translate_cmds(&d.cmds, x, y));
                x += d.w_mm + sp;
                row_h = row_h.max(d.h_mm);
            }
            sheets
        }
    }
}

/// Sends a file to the system printer (Windows: "print" verb; Linux/macOS: `lp`).
pub fn print_file(path: &std::path::Path, copies: u32) -> Result<(), String> {
    let copies = copies.max(1);
    #[cfg(target_os = "windows")]
    {
        let _ = copies;
        let cmd = format!("Start-Process -FilePath '{}' -Verb Print", path.display());
        std::process::Command::new("powershell").args(["-NoProfile", "-Command", &cmd]).status().map_err(|e| e.to_string())?;
        Ok(())
    }
    #[cfg(not(target_os = "windows"))]
    {
        let st = std::process::Command::new("lp").arg("-n").arg(copies.to_string()).arg(path).status().map_err(|e| format!("lp: {e}"))?;
        if st.success() { Ok(()) } else { Err("a nyomtatás parancs hibával tért vissza".into()) }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn ranges() {
        assert_eq!(parse_range("1,3,5-7", 12), vec![0, 2, 4, 5, 6]);
        assert_eq!(parse_range("", 3), vec![0, 1, 2]);
        assert_eq!(parse_range("10-20", 12), vec![9, 10, 11]);
        assert_eq!(parse_range("x,2", 4), vec![1]);
    }
    #[test]
    fn bleed_stretches_full_page_rect() {
        let mut dl = DrawList::new(100.0, 50.0);
        dl.push(Cmd::Rect { r: RectMm { x: 0.0, y: 0.0, w: 100.0, h: 50.0 }, fill: Some(Rgba::WHITE), stroke: None });
        dl.push(Cmd::Image { path: "x".into(), dest: RectMm { x: 0.0, y: 0.0, w: 100.0, h: 50.0 }, crop: (0.1, 0.1, 0.9, 0.9), opacity: 1.0, mask: None, fx: (0.0, 0.0, 0.0) });
        let b = with_bleed(&dl, 3.0);
        assert_eq!((b.w_mm, b.h_mm), (106.0, 56.0));
        match &b.cmds[1] {
            Cmd::Image { dest, crop, .. } => {
                assert_eq!((dest.x, dest.w), (0.0, 106.0));
                assert!(crop.0 < 0.1 && crop.2 > 0.9);
            }
            _ => panic!(),
        }
    }
    #[test]
    fn fit_scales_big_pages() {
        let mut p = Project::new_default(PageSize::presets().into_iter().find(|s| s.name == "A4").unwrap(), false, 2027, 1, crate::cal::Lang::Hu);
        p.export.paper = Some(PageSize::presets().into_iter().find(|s| s.name == "A6").unwrap());
        p.export.fit_pages = true;
        let sh = prepare(&p, &|_: &str| None);
        assert_eq!(sh.len(), 12);
        assert!((sh[0].w_mm - 105.0).abs() < 0.01);
    }
}
