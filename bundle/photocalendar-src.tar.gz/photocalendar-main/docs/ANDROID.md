# Android-port

Állapot: a kód előkészítve, de ebben a környezetben NEM fordítható és NEM kipróbált (az Android célplatform telepítése tiltott).

Előkészítve:
- `Cargo.toml`: `cdylib` lib, `android-activity` + eframe `android-native-activity` csak Androidon, `rfd` csak asztali gépen, `[package.metadata.android]` (cargo-apk).
- `src/lib.rs`: `android_main` belépési pont; `gui::run_android`.
- `src/platform.rs`: fájlpárbeszéd-burkoló. Androidon a mentés az app `exports/` mappájába megy, a fotóválasztás a legfrissebb képeket kínálja az `import/`, `Pictures`, `DCIM/Camera`, `Download` mappákból. Az igazi választó (Storage Access Framework, JNI) még hátravan.
- `src/config.rs`: konfiguráció az Android belső tárhelyén.

Build (Android SDK + NDK telepítése után):
    rustup target add aarch64-linux-android
    cargo install cargo-apk
    cargo apk build --release --lib

Hátravan: SAF-alapú fájlválasztó, PDF megosztás Intent-tel, érintésbarát méretezés, olvasási engedély kérése futásidőben.
