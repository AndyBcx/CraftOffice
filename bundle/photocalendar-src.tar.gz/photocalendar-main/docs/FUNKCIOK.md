# Funkciólista (a felhasználó 51 képernyőképe alapján)

Csak funkcionális referencia. Sablonokat, clipartot, betűtípust, ikont nem másolunk.
Névnapok: NEM kellenek (felhasználói kérés).

## Varázsló
- Típus: Poster (egész év egy lapon), Spiral-Bound, Desk, Monthly Planner, Pocket, Custom.
- Spirálosnál: fotó + rács külön oldalon / ugyanazon az oldalon.
- Sablonválasztó: All / Vertical / Horizontal szűrő; sablon = szerkeszthető rétegkészlet.
- Fotók kiválasztása (12 hely), főfotó kiválasztása (poster).
- Tulajdonságok: kezdő év/hónap, méret (Custom, A6, A5, A4, A3, A2, Letter, Legal,
  Tabloid 11x17, 150x210, 200x300, 12x18 in, 4x6 in), felbontás (72/96/200/300/600),
  szélesség/magasság mm/inch, álló/fekvő.

## Menük
- File: projekt mentés/másként, mentés sablonként, képként, PDF-ként, CMYK elrendezés.
- Calendar: Month Style, Customize Holidays, Language Editor, Moon Phases (testreszabás, mutatás),
  Customize/Display Holiday Names, oldal hozzáadás/törlés/duplikálás, háttérkép.
- Add: Photo, Photo Collage, Caption, Clipart, Logo from file, Photo to Cell, Month Set, Calendar Month.
- Layer: előre/hátra, középre, igazítás, hónapok átméretezése, beállítások.
- Szerkesztő: undo/redo, kivágás/másolás/beillesztés/törlés, zárolás, rács (méret csúszka),
  Fit / 100% / nagyítás csúszka, oldal-miniatűrök (hozzáadás, törlés, importálás).

## Main panel
- Kezdő év/hónap, Month Style, ünnepek kiemelése, ünnepnevek, szombat/vasárnap kiemelése,
  naptár nyelve, második nyelv, hét kezdőnapja, háttér (szín / színátmenet / kép + igazítás +
  "Lighten background").

## Month Style (Template Editor) – minden cella külön stílus
- Elemek: Month Header, Weekday Names, Weekend Names, Weekdays, Weekends and Holidays,
  Week Numbers, Week Numbers Header, Background.
- Cella: fő szöveg (tokenekkel: [&MonthName], [&DayNameShort], [&Day], [&Week], [&WeekShort]),
  betű, méret, B/I/U, igazítás, szín, kiegészítő szöveg, keret (vastagság, szín, oldalanként, átlátszó),
  háttér (átlátszó / szín / színátmenet / kép).
- Elrendezés: táblázat függőleges/vízszintes, sor, oszlop var. 1-3, hét-tábla, hét-oszlop;
  üres cellák elrejtése, hónapnév/napnevek/hétszámok méretezéssel, keret elrejtése.
- Táblázatstílus: alakzat-stílusok, páros/páratlan sor háttér, kitöltés vízszintes/függőleges.
- Kategóriák: Classic, One-line, Decorative, Table, Monthly planner, Weekly planner, Custom;
  Create / Edit / Delete / Add to Templates.

## Ünnepek
- Csoportok országonként (új csoport, másolás, törlés), csoportstílus (betű/háttérszín).
- Ünnep: típus (Day off / Workday), név, dátum (nap, hónap, ismétlődés pl. minden évben),
  betűszín, cellaszín, fotó. Hozzáadás: Holiday / Recurring event / Birthday-anniversary.
- Import Excel/CSV, export CSV.

## Rétegek
- Fotó: hozzáadás, kollázs, csere, vágás; árnyék, körvonal, keret, maszk, autokivágás;
  forgatás, átlátszóság; fényerő, kontraszt, telítettség, reset.
- Szöveg: szöveg + Insert Year/Month, betű, méret, B/I, igazítás, árnyék,
  kitöltés szín/színátmenet/textúra, körvonal, forgatás, átlátszóság.
- Clipart + Shapes: alakzatok (kör, ellipszis, négyzet, téglalap, háromszög, csillag, nyíl, szív,
  kereszt, gyűrű, virág…), kitöltés szín/színátmenet/textúra, körvonal, forgatás, átlátszóság, árnyék.

## Nyomtatás / export
- Nyomtató, papír (saját méretek felvétele/törlése, mm/inch), felbontás, tájolás, példányszám,
  nyomtatási jelek (markup), oldaltartomány (1,3,5-12), margók, térköz, bleed, Save Layout As.
- PDF, kép (PNG/JPEG), CMYK elrendezés.
