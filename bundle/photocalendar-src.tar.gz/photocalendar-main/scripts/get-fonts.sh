#!/bin/sh
# Fetches the Liberation Sans fonts (SIL OFL 1.1) that the program embeds. Run once before `cargo build`.
set -e
mkdir -p assets
if [ -f /usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf ]; then
  cp /usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf /usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf assets/
else
  curl -fsSL -o /tmp/lib.tgz https://github.com/liberationfonts/liberation-fonts/files/7261482/liberation-fonts-ttf-2.1.5.tar.gz
  tar xzf /tmp/lib.tgz -C /tmp
  cp /tmp/liberation-fonts-ttf-2.1.5/LiberationSans-Regular.ttf /tmp/liberation-fonts-ttf-2.1.5/LiberationSans-Bold.ttf assets/
fi
