//! Finds interface text drawn without going through translation: the app is laid out in the
//! pseudo-language (see `pseudo.rs`) in many states, and any visible word outside `⟦…⟧` marks is
//! reported. The document itself is drawn as an image, so its text never shows up here.

use std::cell::Cell;
use std::collections::BTreeMap;

use serde_json::{Value, json};

use super::pseudo;
use crate::WordApp;

thread_local! {
    // Input time, advanced every frame so tooltips and animations move on.
    static TIME: Cell<f64> = const { Cell::new(0.0) };
    // Process-wide names (font families, the custom dictionary) seen at any point of the run:
    // tests running alongside add and remove them, so one may be drawn and gone by the check.
    static GLOBAL_NAMES: std::cell::RefCell<std::collections::HashSet<String>> = std::cell::RefCell::new(Default::default());
}

/// Remember the process-wide names drawn this frame could have come from.
fn note_global_names() {
    GLOBAL_NAMES.with_borrow_mut(|seen| {
        seen.extend(wordcraft_fonts::FontDb::global().families());
        seen.extend(wordcraft_engine::proof::user_dictionary());
    });
}

fn texts(shape: &egui::Shape, out: &mut Vec<String>) {
    match shape {
        egui::Shape::Text(t) => out.push(t.galley.text().to_string()),
        egui::Shape::Vec(v) => v.iter().for_each(|s| texts(s, out)),
        _ => {}
    }
}

/// Run a frame per entry of `steps` (its events), then a few quiet ones, and return every text
/// drawn in the last.
fn frames(ctx: &egui::Context, app: &mut WordApp, steps: Vec<Vec<egui::Event>>) -> Vec<String> {
    // Wide enough that no ribbon tab overflows behind its scroll arrows.
    let screen = egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(2560.0, 900.0));
    let mut drawn = Vec::new();
    let n = steps.len() + 3;
    let mut steps = steps.into_iter();
    for _ in 0..n {
        TIME.set(TIME.get() + 0.1);
        let input =
            egui::RawInput { screen_rect: Some(screen), time: Some(TIME.get()), events: steps.next().unwrap_or_default(), ..Default::default() };
        note_global_names();
        let mut out = ctx.run_ui(input, |ui| {
            app.logic(ui.ctx());
            app.ui(ui);
        });
        note_global_names();
        drawn.clear();
        for s in &out.shapes {
            texts(&s.shape, &mut drawn);
        }
        out.textures_delta.clear();
    }
    drawn
}

fn frame(ctx: &egui::Context, app: &mut WordApp) -> Vec<String> {
    frames(ctx, app, Vec::new())
}

/// Move there, press, release: one frame each, as a real click arrives.
fn click(at: egui::Pos2, button: egui::PointerButton) -> Vec<Vec<egui::Event>> {
    let press = |pressed| egui::Event::PointerButton { pos: at, button, pressed, modifiers: Default::default() };
    vec![vec![egui::Event::PointerMoved(at)], vec![press(true)], vec![press(false)]]
}

fn escape() -> Vec<Vec<egui::Event>> {
    vec![vec![egui::Event::Key { key: egui::Key::Escape, physical_key: None, pressed: true, repeat: false, modifiers: Default::default() }]]
}

/// Centres of the enabled, clickable widgets drawn last frame in the ribbon: below the tab row
/// and above the document area (the largest clickable widget).
fn ribbon_controls(ctx: &egui::Context) -> Vec<egui::Pos2> {
    ctx.viewport(|v| {
        let widgets: Vec<&egui::WidgetRect> = v
            .prev_pass
            .widgets
            .layers()
            .filter(|(layer, _)| matches!(layer.order, egui::Order::Background | egui::Order::Middle))
            .flat_map(|(_, w)| w.iter())
            .filter(|w| w.enabled && w.sense.senses_click())
            .collect();
        let page_top = widgets.iter().max_by(|a, b| a.rect.area().total_cmp(&b.rect.area())).map_or(f32::INFINITY, |w| w.rect.min.y);
        // The tab row ends where the ribbon's first group label row starts; tabs sit near y = 53.
        let tabs_bottom = 64.0;
        widgets.iter().filter(|w| w.rect.width() < 300.0).map(|w| w.rect.center()).filter(|c| c.y > tabs_bottom && c.y < page_top).collect()
    })
}

fn fresh_app(ctx: &egui::Context) -> WordApp {
    ctx.all_styles_mut(|s| s.interaction.tooltip_delay = 0.0);
    let mut app = WordApp::new(wordcraft_engine::Session::new(wordcraft_engine::sample::sample_document()), Default::default());
    // Read Aloud holds each sentence instead of starting the system's speech engine: no sound on
    // machines that have one, and no worker thread failing at its own pace on machines that don't.
    app.session.read_aloud.backend = wordcraft_engine::speech::Backend::Hold;
    // Fonts install over the first frames.
    for _ in 0..2 {
        frame(ctx, &mut app);
    }
    app
}

/// Words (two or more ASCII letters in a row) drawn outside translation marks.
fn english_words(text: &str) -> bool {
    let plain = pseudo::unmarked(text);
    plain.as_bytes().windows(2).any(|w| w[0].is_ascii_alphabetic() && w[1].is_ascii_alphabetic())
}

/// Text that is right to show untranslated: what the author or the machine supplied, not the
/// interface's own wording.
struct Exempt<'a> {
    /// The document's text (headings in the Navigation pane, the title in the title bar).
    body: String,
    /// Installed font families and the document's style names (pickers and editable fields).
    names: std::collections::HashSet<String>,
    /// The Equation tab's UnicodeMath placeholders (math input, not interface wording).
    math: &'a std::collections::HashSet<String>,
}

/// The Equation tab's temporary UnicodeMath placeholders (while a preview loads). They are math
/// input, not interface wording; a character the interface fonts lack becomes its linear name
/// (`┬` → `\below`), so the exact strings are recognized rather than a pattern.
fn math_placeholders(ctx: &egui::Context) -> std::collections::HashSet<String> {
    let font = crate::theme::regular(11.0);
    math_placeholders_with(|c| ctx.fonts_mut(|fonts| fonts.has_glyph(&font, c)))
}

/// [`math_placeholders`] given which characters the interface fonts cover, so the exact-string
/// boundary can be tested without depending on the host's fonts.
fn math_placeholders_with(covered: impl Fn(char) -> bool) -> std::collections::HashSet<String> {
    let mut out = std::collections::HashSet::new();
    for linear in crate::equation_tab::placeholder_linears() {
        out.insert(crate::equation_tab::math_placeholder_with(&linear, &covered));
    }
    out
}

impl<'a> Exempt<'a> {
    fn new(app: &WordApp, math_placeholders: &'a std::collections::HashSet<String>) -> Self {
        // Installed fonts, and the custom dictionary's words (File › Options › Proofing): the user's own.
        note_global_names();
        let mut names: std::collections::HashSet<String> = GLOBAL_NAMES.with_borrow(Clone::clone);
        names.extend(app.session.doc.styles.styles.iter().map(|s| s.name.clone()));
        // Fonts a document asks for, installed or not (Aptos is drawn with a substitute).
        names.extend([wordcraft_doc::styles::BODY_FONT, wordcraft_doc::styles::HEADING_FONT].map(str::to_string));
        // The selected SmartArt graphic's items (the Text Pane): document content.
        if let Some(g) = wordcraft_engine::cmd::smart_art::selected_smart_art(&app.session) {
            names.extend(g.items.iter().map(|i| i.text.clone()));
        }
        // The accessibility checker's findings: like command messages, they answer scripts and
        // MCP too, so they stay English for now.
        for i in wordcraft_engine::cmd::accessibility::check(&app.session.doc) {
            names.extend(["issue", "fix"].iter().filter_map(|k| i[*k].as_str()).map(str::to_string));
        }
        // The selected chart's data (Edit Data's grid): document content.
        if let Some(c) = wordcraft_engine::cmd::chart::selected_chart(&app.session) {
            names.extend(c.categories.iter().cloned());
            names.extend(c.series.iter().map(|s| s.name.clone()));
        }
        // About › Language data: the licences' own titles and texts, and the packs' names,
        // licences and sources (File › Options › Language), as their authors wrote them.
        for (title, text) in wordcraft_engine::packs::licence_texts() {
            names.extend([title, text]);
        }
        for p in wordcraft_engine::packs::available() {
            names.extend([format!("{} · {}", p.name, p.locale), p.source_link().to_string(), p.locale, p.name, p.licence, p.url]);
        }
        for p in wordcraft_engine::packs::installed() {
            names.extend([p.name.clone(), p.licence, format!("{} · {}", p.name, p.locale), p.locale]);
        }
        // Options › Language › Your languages: each row's language tag, and a pack's own name
        // beside it, as the index and the document wrote them.
        let index = wordcraft_engine::packs::available();
        for row in wordcraft_engine::packs::your_languages(&app.session) {
            let tag = row.tags.first().cloned().or_else(|| row.pack.as_deref().map(crate::ribbon::tag_for_pack)).unwrap_or_default();
            if let Some(p) = row.pack.as_deref().and_then(|l| index.iter().find(|p| p.locale == l)) {
                names.insert(format!("{} · {tag}", p.name));
            }
            names.extend(row.tags.iter().cloned());
            names.insert(tag);
        }
        for m in crate::credits::MODELS {
            names.extend([m.company, m.model, m.version].map(str::to_string));
        }
        // The spelling/grammar suggestions popup (#3340): dictionary and grammar-rule words, not
        // interface text.
        if let Some(sugg) = app.canvas.context_issue.as_ref().and_then(|i| i.get("suggestions")).and_then(Value::as_array) {
            names.extend(sugg.iter().filter_map(Value::as_str).map(str::to_string));
        }
        // The proofing pane displays document context and dictionary suggestions, not UI wording.
        if let Some(form) = &app.spelling_review {
            names.extend(form.content_text());
        }
        Exempt { body: app.session.doc.plain_text(wordcraft_doc::StoryRef::Body), names, math: math_placeholders }
    }

    /// Whitelists text that is not interface wording: shortcuts and punctuation, status and Read
    /// Aloud messages, theme font suffixes, icon lettering and account initials, math symbols and
    /// equation placeholders, document body and known names, contributor handles, default style
    /// names and fixed tokens.
    fn allows(&self, app: &WordApp, text: &str) -> bool {
        let plain = pseudo::unmarked(text);
        let plain = plain.trim().trim_end_matches(" —").trim();
        let is_shortcut =
            || plain.split('+').all(|k| matches!(k, "Ctrl" | "Shift" | "Alt" | "Cmd" | "Esc" | "Tab" | "Enter") || k.chars().count() <= 3);
        // A command's error message in the status bar: commands answer scripts and MCP too, so
        // their messages stay English for now.
        let status = app.status_msg.iter().map(|(m, _)| m).chain(&app.read_aloud_error).any(|m| text.contains(m.as_str()));
        // A theme's fonts after its (translated) name: `Studio: Georgia / Georgia`.
        let theme_fonts = plain.strip_prefix(": ").is_some_and(|f| f.split(" / ").count() == 2);
        let icon_lettering = matches!(plain, "Aa" | "ab" | "abc" | "ac" | "cd" | "ab-" | "fx" | "ABC");
        let initials = plain.chars().count() == 2 && plain.chars().all(|c| c.is_ascii_uppercase());
        // Math tiles fall back to UnicodeMath syntax while their preview loads. These are
        // language-independent commands, and only names in the real symbol table qualify.
        let math_symbol = plain.strip_prefix('\\').is_some_and(|name| wordcraft_doc::math_symbols::symbol(name).is_some());
        icon_lettering // drawn inside icons
            || initials // the account button
            || math_symbol
            || status
            || theme_fonts
            || is_shortcut()
            || self.body.contains(plain)
            || self.names.contains(plain)
            || self.math.contains(plain) // the Equation tab's `lim\below(n→∞)`-style placeholders
            || plain.starts_with('@') // contributor handles
            || plain.starts_with("Style") || plain.starts_with("Table Style ") // a new style's default name
            || plain.contains('┬') || plain.contains('\u{2061}') // equation input (UnicodeMath), drawn as math
            || matches!(plain, "WordCraft" | "WordCraft User" | "Discord" | "https://" | "auto" | "I. II. III." | "i. ii. iii." | "I, II, III, …" | "i, ii, iii, …")
            || plain == "CONFIDENTIAL" // the watermark dialog's text: document content, kept as typed
            || plain == "Figure 1" // the caption dialog's sample: the label goes into the document as is
            || crate::dialogs_insert::date_time_preview_matches(plain)
    }
}

#[test]
fn math_placeholders_are_exact_math_input_only() {
    // CI's interface fonts lack `┬`, so the Equation tab paints the linear fallback. Only those
    // exact placeholders are math input; the set is not a backslash or "contains ┬" pattern.
    let set = math_placeholders_with(|c| c.is_ascii() || matches!(c, '∞' | '→'));
    assert!(set.contains("lim\\below(n→∞)"), "the limit button's fallback");
    assert!(!set.contains("lim\u{252C}(n→∞)"), "the covered form is not what this font chain paints");
    assert!(set.contains("\\sum_(i=1)^n"), "the Equation button picture");
    assert!(set.contains("\\complement"), "a symbol tile's fallback");
    assert!(!set.contains("Translate"), "ordinary interface wording is not exempt");
}

/// Fails on interface text drawn without going through the catalog, listed per UI state, and
/// prints the missing-translation report (`report_catalog_gaps`). `cargo xtask i18n-report` runs it
/// with `--nocapture`; `cargo xtask test` and `ci` run it that way instead of in the main test run.
/// It can also run with the other tests: input is synthetic and timed by `TIME`, Read Aloud never
/// starts a speech thread, and process-wide names other tests change are gathered every frame.
#[test]
fn untranslated_interface_text() {
    pseudo::set(true);
    let ctx = egui::Context::default();
    let mut app = fresh_app(&ctx);
    let math_placeholders = math_placeholders(&ctx);
    let mut found: BTreeMap<String, Vec<String>> = BTreeMap::new();
    let mut record = |app: &WordApp, state: &str, drawn: Vec<String>| {
        let exempt = Exempt::new(app, &math_placeholders);
        for t in drawn.into_iter().filter(|t| english_words(t) && !exempt.allows(app, t)) {
            found.entry(t).or_default().push(state.to_string());
        }
    };
    let tabs: Vec<&str> = crate::ribbon::TABS.iter().copied().filter(|t| *t != "File").collect();
    for tab in &tabs {
        let _ = app.run("ui.tab", json!({"tab": tab}));
        let drawn = frame(&ctx, &mut app);
        record(&app, &format!("tab {tab}"), drawn);
    }
    let _ = app.run("ui.tab", json!({"tab": "Home"}));
    for page in ["home", "new", "open", "info", "export", "options"] {
        let _ = app.run("ui.backstage", json!({"value": true, "page": page}));
        let drawn = frame(&ctx, &mut app);
        record(&app, &format!("File › {page}"), drawn);
    }
    for pane in wordcraft_engine::cmd::options::PANES {
        let _ = app.run("ui.backstage", json!({"value": true, "page": "options", "pane": pane}));
        let drawn = frame(&ctx, &mut app);
        record(&app, &format!("File › Options › {pane}"), drawn);
    }
    let _ = app.run("ui.backstage", json!({"value": false}));
    let dialogs = [
        "font",
        "paragraph",
        "goto",
        "insertTable",
        "pageSetup",
        "pageNumbers",
        "link",
        "bookmark",
        "wordCount",
        "zoom",
        "watermark",
        "newStyle",
        "newTableStyle",
        "modifyTableStyle",
        "commands",
        "tableProperties",
        "pasteSpecial",
        "about",
        "contributors",
        "models",
        "languageData",
        "insertMergeField",
        "findRecipient",
        "mergeRecords",
        "printRecords",
        "caption",
        "index",
        "markEntry",
        "toc",
        "tableOfFigures",
        "sourceManager",
        "createSource",
    ];
    for name in dialogs {
        let _ = app.run("ui.dialog", json!({"name": name}));
        let drawn = frame(&ctx, &mut app);
        record(&app, &format!("dialog {name}"), drawn);
        app.dialog = None;
    }
    let panes: Vec<String> =
        app.session.registry.all().iter().map(|c| c.id.to_string()).filter(|id| id.starts_with("view.") && id.ends_with("Pane")).collect();
    for pane in &panes {
        let _ = app.run(pane, json!({"value": true}));
        let drawn = frame(&ctx, &mut app);
        record(&app, &format!("pane {pane}"), drawn);
        let _ = app.run(pane, json!({"value": false}));
    }
    // Right-click on the page (centred in the window).
    let drawn = frames(&ctx, &mut app, click(egui::pos2(1280.0, 520.0), egui::PointerButton::Secondary));
    record(&app, "context menu", drawn);
    frames(&ctx, &mut app, escape());
    // Contextual tabs: a table, then an equation.
    let _ = app.run("insert.table", json!({"rows": 2, "cols": 2}));
    for tab in ["Table Design", "Table Layout"] {
        let _ = app.run("ui.tab", json!({"tab": tab}));
        let drawn = frame(&ctx, &mut app);
        record(&app, &format!("tab {tab}"), drawn);
    }
    let _ = app.run("insert.smartArt", json!({"layout": "hierarchy"}));
    let _ = app.run("smartArt.textPane", json!({"value": true}));
    let _ = app.run("ui.tab", json!({"tab": "SmartArt Design"}));
    let drawn = frame(&ctx, &mut app);
    record(&app, "tab SmartArt Design", drawn);
    let _ = app.run("smartArt.textPane", json!({"value": false}));
    let _ = app.run("ui.dialog", json!({"name": "insertSmartArt"}));
    let drawn = frame(&ctx, &mut app);
    record(&app, "dialog insertSmartArt", drawn);
    app.dialog = None;
    let _ = app.run("insert.chart", json!({"type": "column"}));
    let _ = app.run("ui.tab", json!({"tab": "Chart Design"}));
    let drawn = frame(&ctx, &mut app);
    record(&app, "tab Chart Design", drawn);
    for name in ["chartData", "changeChartType", "insertChart"] {
        let _ = app.run("ui.dialog", json!({"name": name}));
        let drawn = frame(&ctx, &mut app);
        record(&app, &format!("dialog {name}"), drawn);
        app.dialog = None;
    }
    let _ = app.run("insert.equation", json!({}));
    let _ = app.run("ui.tab", json!({"tab": "Equation"}));
    let drawn = frame(&ctx, &mut app);
    record(&app, "tab Equation", drawn);
    // Every ribbon control on every tab, and whatever menu or dialog it opens. A fresh app per
    // tab keeps one tab's commands from changing the next.
    // A fresh app per control, set up the same way, so no click changes what the next one hits
    // (Escape, for one, leaves an equation and takes the Equation tab with it).
    let contextual = ["Table Design", "Table Layout", "Equation", "Chart Design", "SmartArt Design"];
    let open = |tab: &str| {
        let ctx = egui::Context::default();
        let mut app = fresh_app(&ctx);
        match tab {
            "Table Design" | "Table Layout" => drop(app.run("insert.table", json!({"rows": 2, "cols": 2}))),
            "Equation" => drop(app.run("insert.equation", json!({}))),
            "SmartArt Design" => drop(app.run("insert.smartArt", json!({"layout": "process"}))),
            "Chart Design" => drop(app.run("insert.chart", json!({"type": "column"}))),
            _ => {}
        }
        let _ = app.run("ui.tab", json!({"tab": tab}));
        frame(&ctx, &mut app);
        (ctx, app)
    };
    for tab in tabs.iter().chain(&contextual) {
        let (ctx, _) = open(tab);
        let controls = ribbon_controls(&ctx);
        for at in controls {
            let (ctx, mut app) = open(tab);
            // Hover first (tooltips), then click (menus, dialogs).
            let hovered = frames(&ctx, &mut app, vec![vec![egui::Event::PointerMoved(at)]; 3]);
            record(&app, &format!("{tab} › hover"), hovered);
            let drawn = frames(&ctx, &mut app, click(at, egui::PointerButton::Primary));
            record(&app, &format!("{tab} › click"), drawn);
        }
    }
    pseudo::set(false);
    let mut report = String::new();
    for (text, states) in &found {
        let mut states = states.clone();
        states.sort();
        states.dedup();
        report.push_str(&format!("{:?}  [{}]\n", pseudo::unmarked(text), states.join(", ")));
    }
    report_catalog_gaps(pseudo::looked_up());
    assert!(found.is_empty(), "{} interface texts skip translation (wrap them in tl!):\n{report}", found.len());
}

/// The missing-translation report (craft-i18n's S3; `cargo xtask i18n-report`, part of `cargo xtask
/// ci`): the embedded catalogs' problems (the crate's `check_all`), and per language the interface
/// strings with no translation (the missing bucket, which translators fill in craft-i18n) and those
/// whose translation is the English itself (kept English, not counted as translated). A missing
/// translation falls back to English, so the report never fails; without embedded catalogs
/// (`CRAFT_I18N_DIR` unset) it is skipped. The strings are the ones the audit saw looked up, the
/// ribbon tabs, every command's label and ribbon location, the File › Home greetings, every reason
/// a command gives for being off (#2678) and the equation gallery's labels (shown in menus the
/// audit doesn't open one by one). Numbered style names go through a template.
fn report_catalog_gaps(mut keys: std::collections::BTreeSet<String>) {
    use wordcraft_engine::math_gallery::{BUILT_INS, STRUCTURES, SYMBOL_SETS};
    if super::CRAFT_I18N.is_empty() {
        eprintln!("missing-translation report skipped: built without craft-i18n (set CRAFT_I18N_DIR to a craft-i18n checkout)");
        return;
    }
    let problems = super::I18N.check_all();
    if !problems.is_empty() {
        eprintln!("{} catalog rows are skipped (they show in English):\n{problems:#?}", problems.len());
    }
    let tabs = crate::ribbon::TABS.iter().chain(&["Table Design", "Table Layout"]);
    keys.extend(tabs.map(|t| t.to_string()));
    keys.extend(["Good morning", "Good afternoon", "Good evening"].map(String::from));
    keys.extend(disabled_reasons());
    // Reasons the UI itself gives (`widgets.rs::tooltip`), which the engine's checks never reach.
    keys.insert("Open a document first".to_string());
    for doc in [wordcraft_doc::Document::new(), wordcraft_engine::sample::sample_document()] {
        let session = wordcraft_engine::Session::new(doc);
        for spec in session.registry.all() {
            keys.extend(std::iter::once(spec.label).chain(spec.location.split(" › ")).filter(|s| !s.is_empty()).map(String::from));
            keys.extend((spec.enabled)(&session).map(String::from));
        }
    }
    keys.extend(BUILT_INS.iter().map(|(_, label, _)| label.to_string()));
    keys.extend(SYMBOL_SETS.iter().map(|(name, _)| name.to_string()));
    for g in STRUCTURES {
        keys.insert(g.label.to_string());
        for (section, templates) in g.sections {
            keys.insert(section.to_string());
            keys.extend(templates.iter().map(|t| t.label.to_string()));
        }
    }
    let numbered = |s: &str| ["Heading ", "TOC "].iter().any(|p| s.strip_prefix(p).is_some_and(|n| n.chars().all(|c| c.is_ascii_digit())));
    // Names that read the same across languages (citation style names included).
    let same = |s: &str| {
        matches!(
            s,
            "LaTeX"
                | "LaTeX (*.tex)"
                | "Unicode"
                | "I. II. III."
                | "i. ii. iii."
                | "I, II, III, …"
                | "i, ii, iii, …"
                | "APA"
                | "Chicago"
                | "GB/T 7714"
                | "GOST (name sort)"
                | "GOST (title sort)"
                | "Harvard (Anglia)"
                | "IEEE"
                | "ISO 690 (author-date)"
                | "ISO 690 (numerical)"
                | "MLA"
                | "SIST02"
                | "Turabian"
        )
    };
    // A command called with parameters it can't use (`bad parameters: \`path\` (string) is
    // required`): the message names JSON parameters for scripts and MCP, so it stays English like
    // the rest of the engine's errors; the status bar translates only the ones a catalog knows.
    let script_error = |s: &str| s.starts_with("bad parameters: ");
    // A pattern of placeholders and figures only (`{paper}   {width} × {height}`) has nothing to
    // translate: its placeholder names aren't words the interface shows.
    let words = |s: &str| english_words(&s.split('{').map(|p| p.split_once('}').map_or(p, |(_, rest)| rest)).collect::<String>());
    for lang in super::Lang::all().filter(|l| *l != super::Lang::EN) {
        let reported = keys.iter().filter(|s| words(s) && !numbered(s) && !same(s) && !script_error(s));
        let (kept, missing): (Vec<&String>, Vec<&String>) = reported.filter(|s| super::tr(lang, s) == s.as_str()).partition(|s| super::has(lang, s));
        if !missing.is_empty() {
            eprintln!("{} strings have no {} translation:\n{missing:#?}", missing.len(), lang.code());
        }
        if !kept.is_empty() {
            eprintln!("{} strings are kept in English in {}:\n{kept:#?}", kept.len(), lang.code());
        }
    }
}

/// The text from `open` (the first char of `src`) to its matching `close`, skipping string
/// literals (reasons hold brackets: `(Shift+click)`).
fn balanced(src: &str, open: char, close: char) -> &str {
    let (mut depth, mut in_str, mut escaped) = (0usize, false, false);
    for (i, c) in src.char_indices() {
        match (in_str, escaped, c) {
            (true, true, _) => escaped = false,
            (true, false, '\\') => escaped = true,
            (true, false, '"') | (false, _, '"') => in_str = !in_str,
            (false, _, c) if c == open => depth += 1,
            (false, _, c) if c == close => {
                depth -= 1;
                if depth == 0 {
                    return &src[..i + c.len_utf8()];
                }
            }
            _ => {}
        }
    }
    src
}

/// The string literals in `code`.
fn literals(code: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut rest = code;
    while let Some(start) = rest.find('"') {
        let body = &rest[start + 1..];
        let mut escaped = false;
        let end = body.char_indices().find(|&(_, c)| {
            let ends = !escaped && c == '"';
            escaped = !escaped && c == '\\';
            ends
        });
        let Some((end, _)) = end else { break };
        let after = &body[end + 1..];
        // `Some("readOnly" | "forms") => …` matches on a value; it isn't shown to anyone.
        let pattern = after.trim_start().starts_with('|') || rest[..start].trim_end().ends_with('|');
        if !pattern {
            out.push(body[..end].replace("\\'", "'").replace("\\\"", "\""));
        }
        rest = after;
    }
    out
}

/// Every reason a command gives for being off (its `enabled` check), which ribbon tooltips show
/// (#1086). Read from the engine's command sources so a new reason can't slip by: the literals in
/// each `.when(…)` closure and in the checks it names (and the checks those call), with `const`
/// reasons resolved.
fn disabled_reasons() -> std::collections::BTreeSet<String> {
    let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../engine/src/cmd");
    let files = crate::rust_sources(&dir);
    let all: String = files.iter().map(|p| std::fs::read_to_string(p).unwrap()).collect::<Vec<_>>().join("\n");
    // A named check's bodies (any file's `fn name(…) -> Option<&'static str>`).
    let checks = |name: &str| -> Vec<&str> {
        all.match_indices(&format!("fn {name}("))
            .filter_map(|(i, _)| {
                let from = &all[i..];
                let brace = from.find('{')?;
                from[..brace].contains("-> Option<&'static str>").then(|| balanced(&from[brace..], '{', '}'))
            })
            .collect()
    };
    let is_ident = |s: &str| !s.is_empty() && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == ':');
    let mut bodies: Vec<&str> = Vec::new();
    let mut names: Vec<String> = Vec::new();
    for (i, _) in all.match_indices(".when(") {
        let args = balanced(&all[i + ".when".len()..], '(', ')');
        let inner = args.trim_start_matches('(').trim_end_matches(')').trim();
        if is_ident(inner) {
            names.push(inner.rsplit("::").next().unwrap_or(inner).to_string());
        } else {
            bodies.push(inner);
        }
    }
    let mut seen = std::collections::HashSet::new();
    while let Some(name) = names.pop() {
        if !seen.insert(name.clone()) {
            continue;
        }
        for body in checks(&name) {
            bodies.push(body);
            // The checks this one calls (`has_object(s)`).
            for (j, _) in body.match_indices("(s)") {
                let callee = body[..j].rsplit(|c: char| !(c.is_ascii_alphanumeric() || c == '_')).next().unwrap_or("");
                if !callee.is_empty() {
                    names.push(callee.to_string());
                }
            }
        }
    }
    let mut reasons = std::collections::BTreeSet::new();
    for body in bodies {
        // `cfg!(target_arch = "wasm32")` names a target, not a reason.
        let mut code = body.to_string();
        while let Some(i) = code.find("cfg!(") {
            let len = balanced(&code[i + "cfg!".len()..], '(', ')').len();
            code.replace_range(i..i + "cfg!".len() + len, "");
        }
        reasons.extend(literals(&code));
        // `const FROZEN: &str = "…"` reasons.
        for word in body.split(|c: char| !(c.is_ascii_uppercase() || c == '_')).filter(|w| w.len() > 2) {
            if let Some(i) = all.find(&format!("const {word}: &str = ")) {
                reasons.extend(literals(all[i..].lines().next().unwrap_or("")));
            }
        }
    }
    reasons
}

/// One frame at a given window width; returns the left edge of every text drawn.
fn frame_at(ctx: &egui::Context, app: &mut WordApp, width: f32) -> Vec<(String, f32)> {
    fn collect(shape: &egui::Shape, out: &mut Vec<(String, f32)>) {
        match shape {
            egui::Shape::Text(t) => out.push((t.galley.text().to_string(), t.pos.x)),
            egui::Shape::Vec(v) => v.iter().for_each(|s| collect(s, out)),
            _ => {}
        }
    }
    let screen = egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(width, 900.0));
    let mut drawn = Vec::new();
    for _ in 0..4 {
        TIME.set(TIME.get() + 0.1);
        let input = egui::RawInput { screen_rect: Some(screen), time: Some(TIME.get()), ..Default::default() };
        let mut out = ctx.run_ui(input, |ui| {
            app.logic(ui.ctx());
            app.ui(ui);
        });
        drawn.clear();
        for s in &out.shapes {
            collect(&s.shape, &mut drawn);
        }
        out.textures_delta.clear();
    }
    drawn
}

/// The Arabic interface is mirrored: reading starts at the right. And nothing in it can panic:
/// every tab (wide, and narrow enough to scroll), File page, dialog, pane, context menu and
/// ribbon control is laid out right to left. egui's `Grid` asserts against right-to-left parents,
/// so a grid that is not wrapped in `rtl::grid` fails here.
#[test]
fn the_arabic_interface_is_mirrored_and_never_panics() {
    // Arabic comes from the craft-i18n catalogs: a build without them (English only) has nothing to mirror.
    let Some(ar) = super::Lang::from_code("ar") else {
        eprintln!("skipped: built without the craft-i18n Arabic catalog (set CRAFT_I18N_DIR to a checkout)");
        return;
    };
    let start = |ctx: &egui::Context| {
        let mut app = fresh_app(ctx);
        app.ui.language = "ar".into();
        frame(ctx, &mut app);
        app
    };
    let ctx = egui::Context::default();
    let mut app = start(&ctx);
    assert!(crate::rtl::on());
    let x_of = |drawn: &[(String, f32)], english: &str| {
        let label = super::tr(ar, english);
        drawn.iter().find(|(t, _)| t == label).map(|(_, x)| *x).unwrap_or_else(|| panic!("{english} is not drawn"))
    };
    // Tabs run from the right: File, Home, Insert … and the Share button is at the far left.
    let drawn = frame_at(&ctx, &mut app, 1600.0);
    let (file, home, insert, share) = (x_of(&drawn, "File"), x_of(&drawn, "Home"), x_of(&drawn, "Insert"), x_of(&drawn, "Share"));
    assert!(file > home && home > insert && insert > 800.0, "tabs: {file} {home} {insert}");
    assert!(share < 200.0, "Share: {share}");
    // Ribbon groups too: Clipboard is right of Font, which is right of Styles.
    assert!(x_of(&drawn, "Clipboard") > x_of(&drawn, "Font") && x_of(&drawn, "Font") > x_of(&drawn, "Styles"));
    // The status bar starts at the right, and a narrow window still shows the ribbon's first group.
    let page = drawn.iter().find(|(t, _)| t.contains(super::tr(ar, "Editing"))).map(|(_, x)| *x);
    assert!(page.is_some());
    let narrow = frame_at(&ctx, &mut app, 700.0);
    let clipboard = x_of(&narrow, "Clipboard");
    assert!((350.0..700.0).contains(&clipboard), "the narrow ribbon starts at its right end: {clipboard}");
    // Side panes swap sides: Navigation is on the right.
    let _ = app.run("view.navigationPane", json!({"value": true}));
    let drawn = frame_at(&ctx, &mut app, 1600.0);
    assert!(x_of(&drawn, "Navigation") > 1300.0);
    let _ = app.run("view.navigationPane", json!({"value": false}));
    // English stays as it was.
    {
        let ctx = egui::Context::default();
        let mut app = fresh_app(&ctx);
        let drawn = frame_at(&ctx, &mut app, 1600.0);
        let x = |label: &str| drawn.iter().find(|(t, _)| t == label).map(|(_, x)| *x).unwrap();
        assert!(x("File") < x("Home") && x("Home") < x("Insert") && x("Insert") < 400.0 && x("Share") > 1400.0);
        assert!(x("Clipboard") < x("Font") && x("Font") < x("Styles"));
        assert!(x("Cut") < 200.0, "ribbon buttons keep their icon on the left and start at the left");
        assert!(!crate::rtl::on());
        super::set_current(ar);
    }
    // Everything else: no panic at any width.
    let tabs: Vec<&str> = crate::ribbon::TABS.iter().copied().filter(|t| *t != "File").collect();
    for tab in &tabs {
        let _ = app.run("ui.tab", json!({"tab": tab}));
        for width in [2560.0, 1100.0, 420.0] {
            frame_at(&ctx, &mut app, width);
        }
    }
    let _ = app.run("ui.tab", json!({"tab": "Home"}));
    // Reading Mode's toolbar is mirrored too: its far-side button ("Edit Document") is at the left.
    let _ = app.run("view.readMode", json!({}));
    let drawn = frame_at(&ctx, &mut app, 1600.0);
    let edit = x_of(&drawn, "Edit Document");
    assert!(edit < 400.0, "Reading Mode: Edit Document at {edit}");
    let _ = app.run("view.printLayout", json!({}));
    // File › Print: the settings are on the right and the preview on the left, not over each other.
    let _ = app.run("ui.backstage", json!({"value": true, "page": "print"}));
    for width in [1600.0, 1100.0] {
        let drawn = frame_at(&ctx, &mut app, width);
        let settings = x_of(&drawn, "Save these pages as PDF…");
        let indicator = super::tr(ar, "Sheet {page} of {pages}").split('{').next().unwrap_or_default();
        // (The status bar's page count is drawn under the page too, at the right: take the leftmost.)
        let preview = drawn.iter().filter(|(t, _)| t.starts_with(indicator)).map(|(_, x)| *x).fold(f32::MAX, f32::min);
        assert!(preview < f32::MAX, "the preview's page indicator is drawn");
        assert!(preview + 100.0 < settings, "print page at {width}: settings {settings}, preview {preview}");
    }
    for page in ["home", "new", "open", "info", "export", "print", "options"] {
        let _ = app.run("ui.backstage", json!({"value": true, "page": page}));
        frame(&ctx, &mut app);
        frame_at(&ctx, &mut app, 500.0);
    }
    let _ = app.run("ui.backstage", json!({"value": false}));
    // A dialog's columns start at the right too: Go To's list of targets is right of its input.
    let _ = app.run("ui.dialog", json!({"name": "goto"}));
    let drawn = frame_at(&ctx, &mut app, 1600.0);
    let (targets, input) = (x_of(&drawn, "Go to what:"), x_of(&drawn, "Enter page number:"));
    assert!(targets > input, "Go To: targets {targets}, input {input}");
    app.dialog = None;
    let dialogs = [
        "font",
        "paragraph",
        "tabs",
        "goto",
        "insertTable",
        "pageSetup",
        "link",
        "bookmark",
        "wordCount",
        "zoom",
        "watermark",
        "phonetic",
        "newStyle",
        "manageStyles",
        "newTableStyle",
        "modifyTableStyle",
        "commands",
        "icons",
        "tableProperties",
        "enclose",
        "pasteSpecial",
        "about",
        "contributors",
        "models",
        "insertMergeField",
        "findRecipient",
        "fieldCode",
        "encryptPassword",
        "defineList",
        "trackChangesOptions",
        "customizeKeyboard",
        "customizeRibbon",
        "customizeQuickAccess",
        "noteOptions",
        "caption",
        "index",
        "markEntry",
        "toc",
        "sourceManager",
        "createSource",
        "lineNumbers",
        "hyphenation",
        "language",
        "envelopes",
        "labels",
        "find",
        "replace",
        "symbol",
        "field",
        "columns",
        "borders",
        "pageBorders",
        "newRecipientList",
        "editRecipientList",
        "rules",
        "matchFields",
        "dropCap",
        "dateTime",
        "crossReference",
    ];
    for name in dialogs {
        let _ = app.run("ui.dialog", json!({"name": name}));
        frame(&ctx, &mut app);
        app.dialog = None;
    }
    let panes: Vec<String> =
        app.session.registry.all().iter().map(|c| c.id.to_string()).filter(|id| id.starts_with("view.") && id.ends_with("Pane")).collect();
    for pane in &panes {
        let _ = app.run(pane, json!({"value": true}));
        frame(&ctx, &mut app);
        frame_at(&ctx, &mut app, 600.0);
        let _ = app.run(pane, json!({"value": false}));
    }
    frames(&ctx, &mut app, click(egui::pos2(1280.0, 520.0), egui::PointerButton::Secondary));
    frames(&ctx, &mut app, escape());
    let _ = app.run("insert.table", json!({"rows": 2, "cols": 2}));
    for tab in ["Table Design", "Table Layout"] {
        let _ = app.run("ui.tab", json!({"tab": tab}));
        frame(&ctx, &mut app);
        frame_at(&ctx, &mut app, 600.0);
    }
    let _ = app.run("insert.equation", json!({}));
    let _ = app.run("ui.tab", json!({"tab": "Equation"}));
    frame(&ctx, &mut app);
    // Every ribbon control on every tab, hovered and clicked: its tooltip, menu or dialog.
    let contextual = ["Table Design", "Table Layout", "Equation"];
    let open = |tab: &str| {
        let ctx = egui::Context::default();
        let mut app = start(&ctx);
        match tab {
            "Table Design" | "Table Layout" => drop(app.run("insert.table", json!({"rows": 2, "cols": 2}))),
            "Equation" => drop(app.run("insert.equation", json!({}))),
            _ => {}
        }
        let _ = app.run("ui.tab", json!({"tab": tab}));
        frame(&ctx, &mut app);
        (ctx, app)
    };
    for tab in tabs.iter().chain(&contextual) {
        let (ctx, mut app) = open(tab);
        for at in ribbon_controls(&ctx) {
            frames(&ctx, &mut app, vec![vec![egui::Event::PointerMoved(at)]; 2]);
            frames(&ctx, &mut app, click(at, egui::PointerButton::Primary));
            frames(&ctx, &mut app, escape());
            app.dialog = None;
            app.ui.backstage = false;
            if app.ui.tab != *tab {
                (_, app) = open(tab);
            }
        }
    }
    super::set_current(super::Lang::EN);
}
