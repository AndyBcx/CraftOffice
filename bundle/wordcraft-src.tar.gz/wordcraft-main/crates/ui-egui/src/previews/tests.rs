use super::*;

/// #848: each trip through the Font box loaded every family it showed, for good. Entries are
/// now drawn with a face read for the preview alone: installed families stay unloaded.
#[test]
fn font_menu_entries_leave_installed_families_unloaded() {
    let db = wordcraft_fonts::FontDb::global();
    let ink = |img: &egui::ColorImage| img.pixels.iter().filter(|p| p.r() < 128).count();
    assert!(ink(&font_entry_image("Source Sans 3", 1.0)) > 20, "the bundled face draws");
    assert!(ink(&font_entry_image("No Such Font 848", 1.0)) > 20, "an unknown font shows in the default face");
    // Tests running alongside share this database and may load a fallback (a math font for
    // an equation, a font for a script) at any time: leave the math fonts out, and allow a
    // stray load or two. Before #848 every family previewed was loaded.
    let shared = |f: &str| wordcraft_fonts::math::MATH_SUBSTITUTES.iter().any(|n| f.eq_ignore_ascii_case(n));
    let unloaded: Vec<String> = db.families().into_iter().filter(|f| !db.is_loaded(f) && !shared(f)).take(25).collect();
    let mut loaded = Vec::new();
    for f in &unloaded {
        let img = font_entry_image(f, 1.0);
        assert_eq!(img.size, [244, 22]);
        if db.is_loaded(f) {
            loaded.push(f.clone());
        }
    }
    assert!(loaded.len() <= 2, "previewing loaded {loaded:?}");
}

/// A window whose Styles gallery lists `style` first: runs the gallery for a few frames and
/// returns the painted shapes of the last one and every texture picture uploaded on the way.
fn run_gallery(mut doc: Document, style: wordcraft_doc::styles::Style) -> (Vec<egui::epaint::ClippedShape>, Vec<egui::ColorImage>) {
    // Only the style under test is in the gallery.
    for other in &mut Arc::make_mut(&mut doc.styles).styles {
        other.quick = false;
    }
    Arc::make_mut(&mut doc.styles).upsert(style);
    let mut app = WordApp::new(wordcraft_engine::Session::new(doc), Default::default());
    app.ui.language = "en".into();
    let ctx = egui::Context::default();
    let mut shapes = Vec::new();
    let mut images = Vec::new();
    for frame in 0..6 {
        let input = egui::RawInput {
            time: Some(f64::from(frame) * 0.1),
            screen_rect: Some(Rect::from_min_size(pos2(0.0, 0.0), vec2(800.0, 200.0))),
            ..Default::default()
        };
        let mut out = ctx.run_ui(input, |ui| {
            ui.add_space(20.0);
            style_gallery(&mut app, ui, &json!({}));
        });
        for (_, deltas) in out.textures_delta.set.drain() {
            for delta in deltas {
                if let (None, egui::ImageData::Color(img)) = (delta.pos, &delta.image) {
                    images.push(egui::ColorImage::clone(img));
                }
            }
        }
        out.textures_delta.clear();
        shapes = out.shapes;
    }
    (shapes, images)
}

fn gallery_style(name: &str) -> wordcraft_doc::styles::Style {
    wordcraft_doc::styles::Style { id: "Backfill".into(), name: name.into(), quick: true, priority: Some(0), ..Default::default() }
}

/// Seeded style preview textures are invalidated when fonts change so that newly available
/// faces replace fallback fonts used in earlier renders (#5957).
#[test]
fn font_changes_invalidate_cached_style_preview_textures() {
    let ctx = egui::Context::default();
    let mut previews = Previews::default();
    let texture = ctx.load_texture("test-style-preview", egui::ColorImage::new([1, 1], vec![egui::Color32::BLACK]), egui::TextureOptions::LINEAR);
    previews.tex.insert("style:Normal:cached".into(), texture);
    previews.fonts_changed();
    assert!(previews.tex.is_empty(), "a new font can replace the fallback used by cached style previews");
}

/// Previews instances (such as other open windows) that missed an active `watch_fonts` call
/// invalidate their cached preview textures on their next lookup once the font generation advances (#5957).
#[test]
fn stale_previews_invalidate_on_next_lookup() {
    let ctx = egui::Context::default();
    let mut previews = Previews::default();
    let texture = ctx.load_texture("test-style-preview", egui::ColorImage::new([1, 1], vec![egui::Color32::BLACK]), egui::TextureOptions::LINEAR);
    previews.tex.insert("style:Normal:cached".into(), texture);
    // Simulate this Previews instance having rendered at an older font generation.
    previews.font_gen = wordcraft_fonts::FontDb::global().generation().wrapping_sub(1);
    let mut made = false;
    let _ = previews.get_or(&ctx, "style:Normal:cached", || {
        made = true;
        Some(egui::ColorImage::new([1, 1], vec![egui::Color32::WHITE]))
    });
    assert!(made, "the cached preview was invalidated and re-rendered because the font generation changed");
}

/// Regression test for #2: a style gallery label longer than its tile was painted at full width
/// and ran into the neighbouring tiles; it is now cut with an ellipsis to fit the tile.
#[test]
fn a_long_style_name_is_truncated_to_its_tile() {
    let name = "An extraordinarily long custom style name that cannot fit a tile";
    let (shapes, _) = run_gallery(Document::new(), gallery_style(name));
    let label = shapes
        .iter()
        .find_map(|s| match &s.shape {
            egui::Shape::Text(t) if t.galley.job.text == name => Some(t),
            _ => None,
        })
        .expect("the long style's label is painted");
    // A tile is 74 points wide.
    assert!(label.galley.size().x <= 74.0, "the label is {} points wide, wider than its 74-point tile", label.galley.size().x);
    assert!(label.galley.elided, "the label is cut short with an ellipsis");
}

/// Regression test for #2: a style whose hanging indent is larger than its left indent previewed
/// with its first line starting off the tile's left edge; the first line now starts at the edge.
#[test]
fn a_hanging_indent_style_previews_from_the_tile_edge() {
    let mut style = gallery_style("Hanging");
    style.para.indent_left = Some(0.0);
    style.para.indent_first = Some(-36.0);
    let (_, images) = run_gallery(Document::new(), style);
    // The style is the only one in the gallery: its preview is the picture of a tile's size (the other upload is egui's font texture).
    let preview = images.iter().find(|i| (200..300).contains(&i.size[0]) && (20..60).contains(&i.size[1])).expect("the preview is rendered");
    let [w, h] = preview.size;
    let inked: Vec<bool> = (0..w).map(|x| (0..h).any(|y| preview.pixels.get(y * w + x).is_some_and(|p| p.a() > 0 && p.r() < 160))).collect();
    let first = inked.iter().position(|&i| i).expect("the preview has text");
    let last = inked.iter().rposition(|&i| i).unwrap_or(first);
    // "AaBbCcDd" begins at the left margin (1 point) and is whole: it is about 60 points wide.
    assert!(first < 6, "the first line starts off the tile's left edge (ink from column {first})");
    assert!(last - first > 40, "the first line is cut off by the tile's left edge (ink {first}..{last})");
}

/// #663: gallery previews are dimmed in the dark theme, unless they show Switch Modes' dark
/// page; the light theme keeps a white page.
#[test]
fn previews_are_dimmed_in_the_dark_theme() {
    let (light, dark) = (crate::theme::Tokens::light(), crate::theme::Tokens::dark());
    assert_eq!(super::preview_tint(&light, false), egui::Color32::WHITE);
    assert_eq!(super::preview_tint(&dark, true), egui::Color32::WHITE, "the dark page is already dark");
    let dim = super::preview_tint(&dark, false);
    assert!(dim.r() < 0xE0 && dim.r() > 0xA0, "{dim:?}");
}

/// Font-menu previews defer over budget, render on a later frame, and reuse cached entries
/// without consuming budget or deadlocking.
#[test]
fn font_menu_previews_render_defer_and_reuse_without_deadlocking() {
    // A nested Context lock used to hang the first uncached menu entry. Bound the wait so
    // a regression fails the test instead of hanging the entire test suite.
    let (tx, rx) = std::sync::mpsc::channel();
    let worker = std::thread::spawn(move || {
        let ctx = egui::Context::default();
        let mut previews = Previews::default();
        let preview = previews.font_preview_fn();
        let budget_id = egui::Id::unique("font_preview_budget");
        let (sans, inter) = (font_key("Source Sans 3", 1.0), font_key("Inter", 1.0));
        ctx.data_mut(|d| d.insert_temp(budget_id, (1.0_f64, 11_u32)));

        for time in [1.0, 2.0, 3.0] {
            let input = egui::RawInput { time: Some(time), ..Default::default() };
            ctx.run_ui(input, |ui| {
                preview(ui, "Source Sans 3");
                preview(ui, "Inter");
            })
            .drop_without_applying_deltas();
            let drawn = |key: &str| previews.fonts.lock().atlas.uv.contains_key(key);
            assert!(drawn(&sans));
            let budget = ctx.data(|d| d.get_temp::<(f64, u32)>(budget_id));
            if time == 1.0 {
                assert!(!drawn(&inter), "over-budget entry should defer");
                assert_eq!(budget, Some((1.0, 13)));
            } else {
                assert!(drawn(&inter), "deferred entry should render next frame");
                assert_eq!(budget, Some((2.0, 1)), "cached entries should not consume budget");
            }
        }
        tx.send(()).unwrap();
    });
    rx.recv_timeout(std::time::Duration::from_secs(30)).expect("font menu preview rendering hung or failed");
    worker.join().unwrap();
}

/// #817: equation pictures were black on white; they are now an ink mask (white, transparent paper).
#[test]
fn math_pictures_are_ink_masks() {
    use wordcraft_doc::math::parse_linear;
    let img = math_image(&parse_linear("x/y"), false, 12.0, 40.0, 34.0, 1.0).expect("renders");
    assert!(img.pixels.iter().any(|p| p.a() == 0), "paper is transparent");
    assert!(img.pixels.iter().any(|p| p.a() > 0), "ink is kept");
    assert!(img.pixels.iter().all(|p| *p == egui::Color32::from_white_alpha(p.a())), "ink is white, to be tinted");
}

/// Every picture the Equation tab and Insert › Equation draw: (key, nodes, display, pt, tile size).
fn equation_pictures() -> Vec<(String, wordcraft_doc::math::Arg, bool, f32, egui::Vec2)> {
    use wordcraft_doc::math::{MNode, MRun, parse_linear};
    use wordcraft_engine::math_gallery::{BUILT_INS, STRUCTURES, SYMBOL_SETS};
    let mut out = Vec::new();
    for g in STRUCTURES {
        let pic = crate::equation_tab::button_picture(g.id);
        out.push((format!("btn:{pic}"), parse_linear(pic), false, 12.0, vec2(40.0, 32.0)));
        for (_, templates) in g.sections {
            for t in templates.iter() {
                out.push((format!("tpl:{}", t.id), t.nodes(), true, 14.0, vec2(56.0, 52.0)));
                out.push((format!("tpl:{}", t.id), t.nodes(), true, 13.0, vec2(154.0, 56.0)));
            }
        }
    }
    for (id, _, lin) in BUILT_INS {
        out.push((format!("builtin:{id}"), parse_linear(lin), true, 11.0, vec2(346.0, 60.0)));
    }
    for (_, chars) in SYMBOL_SETS {
        for c in chars.chars() {
            let nodes = vec![MNode::Run(MRun { text: c.to_string(), lit: true, ..Default::default() })];
            out.push((format!("sym:{c}"), nodes, false, 11.0, vec2(22.0, 22.0)));
        }
    }
    out
}

/// #1002: drawn the way the Equation tab draws them (the picture tinted with the theme's text
/// colour on an input-coloured tile), every gallery tile, button and symbol is the theme's
/// greys only: its background is the tile colour and its ink no darker or lighter than the
/// text, in light and dark mode, with no red or teal anywhere.
#[test]
fn equation_pictures_follow_the_theme() {
    let mix = |fg: u8, bg: u8, a: u8| ((u32::from(fg) * u32::from(a) + u32::from(bg) * (255 - u32::from(a))) / 255) as u8;
    for (key, nodes, display, pt, size) in equation_pictures() {
        let img = math_image(&nodes, display, pt, size.x, size.y, 1.0).unwrap_or_else(|| panic!("{key} renders"));
        assert!(img.pixels.iter().all(|p| *p == egui::Color32::from_white_alpha(p.a())), "{key}: an ink mask");
        // Ink may reach the corner (a matrix bracket with Windows fonts): look for paper anywhere.
        assert!(img.pixels.iter().any(|p| p.a() == 0), "{key}: transparent paper");
        for t in [Tokens::light(), Tokens::dark()] {
            let (bg, fg) = (t.input, t.text);
            let (lo, hi) = (bg.r().min(fg.r()), bg.r().max(fg.r()));
            for p in &img.pixels {
                let a = p.a();
                let c = [mix(fg.r(), bg.r(), a), mix(fg.g(), bg.g(), a), mix(fg.b(), bg.b(), a)];
                assert!(c[0] == c[1] && c[1] == c[2], "{key}: a grey, not {c:?}");
                assert!((lo..=hi).contains(&c[0]), "{key}: between the tile and the text colour, not {c:?}");
            }
        }
    }
}

/// #1002: the pictures share one texture, written in place: browsing every gallery creates no
/// texture per tile and frees none (hundreds of small textures, freed in bulk, showed other
/// textures' memory on DirectX 12).
#[test]
fn equation_pictures_share_one_texture() {
    let ctx = egui::Context::default();
    let mut app = WordApp::new(wordcraft_engine::Session::new(Document::new()), crate::Services::default());
    let pictures = equation_pictures();
    // Symbols repeat across sets (∀, ≠…): each is drawn once.
    let unique = pictures.iter().map(|(key, _, _, pt, size)| format!("{key}:{pt}:{size:?}")).collect::<std::collections::HashSet<_>>().len();
    let mut drawn: HashMap<String, (egui::TextureId, Rect)> = HashMap::new();
    let mut freed = 0;
    for _ in 0..200 {
        let mut out = ctx.run_ui(egui::RawInput::default(), |ui| {
            let ctx = ui.ctx().clone();
            for (key, nodes, display, pt, size) in &pictures {
                let k = format!("{key}:{pt}:{size:?}");
                if let std::collections::hash_map::Entry::Vacant(e) = drawn.entry(k)
                    && let Some(t) = math_texture(&mut app, &ctx, key, nodes, *display, *pt, *size)
                {
                    e.insert(t);
                }
            }
        });
        freed += out.textures_delta.free.len();
        out.textures_delta.clear();
        if drawn.len() == unique {
            break;
        }
    }
    assert_eq!(drawn.len(), unique, "every picture is drawn");
    let ids: std::collections::HashSet<_> = drawn.values().map(|(id, _)| *id).collect();
    assert_eq!(ids.len(), 1, "one texture for every picture");
    assert_eq!(freed, 0, "no texture freed while browsing");
    // No two pictures overlap, and each lies inside the texture.
    let rects: Vec<Rect> = drawn.values().map(|(_, uv)| *uv).collect();
    for (i, a) in rects.iter().enumerate() {
        assert!(a.min.x >= 0.0 && a.min.y >= 0.0 && a.max.x <= 1.0 && a.max.y <= 1.0, "{a:?} inside");
        for b in rects.iter().skip(i + 1) {
            assert!(!a.intersects(*b) || a.intersect(*b).area() <= 0.0, "{a:?} overlaps {b:?}");
        }
    }
}

/// #1002: pictures are packed row by row, and pictures that can never fit are refused.
#[test]
fn math_atlas_packs_rows() {
    let mut a = AtlasPage::default();
    assert_eq!(a.place(100, 40), Some([0, 0]));
    assert_eq!(a.place(100, 20), Some([100 + ATLAS_GAP, 0]));
    assert_eq!(a.place(ATLAS, 10), Some([0, 40 + ATLAS_GAP]), "a new row under the tallest");
    assert_eq!(a.place(ATLAS + 1, 10), None);
    assert_eq!(a.place(10, 0), None);
    assert_eq!(a.place(10, ATLAS), None, "full");
    assert_eq!(a.place(10, 10), Some([0, 40 + ATLAS_GAP + 10 + ATLAS_GAP]), "still room after a refusal");
}

/// #1002: a page is never wiped in a frame that handed out one of its pictures (they are
/// already on screen); once all pages are full, the least recently drawn page starts over.
#[test]
fn math_atlas_never_wipes_a_page_drawn_from_this_frame() {
    let ctx = egui::Context::default();
    let img = || egui::ColorImage::filled([ATLAS, ATLAS], egui::Color32::TRANSPARENT);
    let mut out = ctx.run_ui(egui::RawInput::default(), |ui| {
        let mut a = PreviewAtlas::default();
        let first: Vec<_> = (0..ATLAS_PAGES).map(|i| a.add(ui.ctx(), 1, &format!("p{i}"), img())).collect();
        assert!(first.iter().all(Option::is_some), "a page each");
        let ids: std::collections::HashSet<_> = first.iter().flatten().map(|(id, _)| *id).collect();
        assert_eq!(ids.len(), ATLAS_PAGES);
        assert!(a.add(ui.ctx(), 1, "more", img()).is_none(), "every page was drawn from this frame");
        assert_eq!(a.wipes, 0);
        assert!(a.uv.len() == ATLAS_PAGES, "nothing forgotten");
        // Next frame: page 0 is drawn from again, so the one drawn longest ago is page 1.
        assert_eq!(a.get(2, "p0"), first.first().copied().flatten());
        let (id, _) = a.add(ui.ctx(), 2, "more", img()).expect("a page starts over");
        assert_eq!(a.wipes, 1);
        assert_eq!(Some(id), first.get(1).copied().flatten().map(|(id, _)| id), "the least recently drawn page");
        assert!(a.uv.contains_key("p0") && !a.uv.contains_key("p1"));
        // Pages 0 and 1 are now in use this frame; 2 and 3 are free to start over, then none.
        assert!(a.add(ui.ctx(), 2, "x", img()).is_some());
        assert!(a.add(ui.ctx(), 2, "y", img()).is_some());
        assert!(a.add(ui.ctx(), 2, "z", img()).is_none());
        assert_eq!(a.wipes, 3);
        assert!(a.get(2, "p0").is_some() && a.get(2, "more").is_some() && a.get(2, "x").is_some() && a.get(2, "y").is_some());
    });
    out.textures_delta.clear();
}

/// #1002: at a display scale of 3, the 22 built-in equations need more than one page; the
/// built-in menu opened again draws them all from the atlas, with nothing wiped or moved
/// (a single page used to start over every frame: flicker and constant re-rendering).
#[test]
fn builtin_menu_at_scale_3_fits_without_wiping() {
    use wordcraft_doc::math::parse_linear;
    use wordcraft_engine::math_gallery::BUILT_INS;
    let ctx = egui::Context::default();
    ctx.set_pixels_per_point(3.0);
    let mut app = WordApp::new(wordcraft_engine::Session::new(Document::new()), crate::Services::default());
    let builtins: Vec<_> = BUILT_INS.iter().map(|(id, _, lin)| (format!("builtin:{id}"), parse_linear(lin))).collect();
    let draw = |app: &mut WordApp| {
        let mut got = Vec::new();
        let mut out = ctx.run_ui(egui::RawInput::default(), |ui| {
            assert_eq!(ui.ctx().pixels_per_point(), 3.0);
            let ctx = ui.ctx().clone();
            got = builtins.iter().map(|(key, nodes)| math_texture(app, &ctx, key, nodes, true, 11.0, vec2(346.0, 60.0))).collect();
        });
        out.textures_delta.clear();
        got
    };
    // The first opening renders a few a frame.
    let mut first = draw(&mut app);
    for _ in 0..20 {
        if first.iter().all(Option::is_some) {
            break;
        }
        first = draw(&mut app);
    }
    assert!(first.iter().all(Option::is_some), "every built-in drawn");
    let wipes = app.previews.math.wipes;
    let again = draw(&mut app);
    assert_eq!(again, first, "the same texture and place for each");
    assert_eq!(app.previews.math.wipes, wipes, "nothing started over");
    assert_eq!(wipes, 0);
}

#[test]
fn ink_mask_keeps_the_ink_and_drops_the_paper() {
    let mut img = egui::ColorImage::new([3, 1], vec![egui::Color32::WHITE, egui::Color32::BLACK, egui::Color32::from_gray(128)]);
    ink_mask(&mut img);
    assert_eq!(img.pixels[0].a(), 0, "paper becomes transparent");
    assert_eq!(img.pixels[1], egui::Color32::from_white_alpha(255), "full ink stays opaque");
    assert_eq!(img.pixels[2].a(), 127, "antialiased ink keeps its coverage");
}

/// #5105: on Windows, font menu entries showed on black strips in light mode and on white or
/// red ones in dark mode: each entry was a texture of its own, and browsing the list created
/// and freed hundreds of them, the DirectX 12 texture mix-up of #1002. Entries are now drawn
/// from a few shared pages written in place: scrolling through a long font list, at a high
/// display scale too, creates at most [`ATLAS_PAGES`] textures and frees none. Once fonts are
/// added or removed (from any window), every entry is drawn again.
#[test]
fn font_menu_entries_share_a_few_textures_and_free_none() {
    for ppp in [1.0, 3.0] {
        let ctx = egui::Context::default();
        ctx.set_pixels_per_point(ppp);
        let mut previews = Previews::default();
        let preview = previews.font_preview_fn();
        let names: Vec<String> = (0..300).map(|i| format!("Font {i}")).collect();
        let (mut created, mut freed, mut ids) = (std::collections::HashSet::new(), 0, std::collections::HashSet::new());
        // A menu shows about fifteen entries a frame; scroll it through the list twice.
        for (frame, rows) in names.chunks(15).chain(names.chunks(15)).enumerate() {
            let input = egui::RawInput { time: Some(frame as f64), ..Default::default() };
            let mut out = ctx.run_ui(input, |ui| {
                for name in rows {
                    preview(ui, name);
                }
            });
            created.extend(
                out.textures_delta
                    .set
                    .iter()
                    .filter(|(id, ds)| **id != egui::TextureId::default() && ds.iter().any(|d| d.pos.is_none()))
                    .map(|(id, _)| *id),
            );
            freed += out.textures_delta.free.len();
            for s in &out.shapes {
                if let egui::Shape::Mesh(m) = &s.shape
                    && m.texture_id != egui::TextureId::default()
                {
                    ids.insert(m.texture_id);
                }
            }
            out.textures_delta.clear();
        }
        assert!(!created.is_empty() && created.len() <= ATLAS_PAGES, "{ppp}: {} textures created", created.len());
        assert_eq!(freed, 0, "{ppp}: no texture is freed while the list is browsed");
        assert!(ids.len() <= ATLAS_PAGES, "{ppp}: entries drawn from {} textures", ids.len());
        // An entry is drawn from the atlas, not as plain text.
        ctx.run_ui(egui::RawInput { time: Some(1000.0), ..Default::default() }, |ui| {
            preview(ui, "Font 298");
            preview(ui, "Font 299");
        })
        .drop_without_applying_deltas();
        assert!(previews.fonts.lock().atlas.uv.contains_key(&font_key("Font 299", ppp)));
        // Fonts were added or removed since the entries were drawn: the next entry drawn starts
        // the atlas over, so none keeps a face it no longer has.
        previews.fonts.lock().generation = u64::MAX;
        ctx.run_ui(egui::RawInput { time: Some(1001.0), ..Default::default() }, |ui| {
            preview(ui, "Font 298");
        })
        .drop_without_applying_deltas();
        let fonts = previews.fonts.lock();
        // Not compared with the database's generation: tests running alongside add and remove fonts.
        assert_ne!(fonts.generation, u64::MAX, "the atlas took the database's generation");
        assert!(fonts.atlas.uv.contains_key(&font_key("Font 298", ppp)) && !fonts.atlas.uv.contains_key(&font_key("Font 299", ppp)));
    }
}

/// #535: font menu entries drew on a white strip in dark mode. They are now tinted with the
/// theme's text colour and draw no background of their own.
#[test]
fn font_menu_entries_take_the_theme_text_colour() {
    for theme in [egui::Theme::Dark, egui::Theme::Light] {
        let ctx = egui::Context::default();
        crate::theme::apply(&ctx, crate::theme::Appearance::System);
        ctx.set_theme(theme);
        let preview = Previews::default().font_preview_fn();
        let mut out = None;
        for time in [1.0, 2.0] {
            let input = egui::RawInput { time: Some(time), ..Default::default() };
            let mut o = ctx.run_ui(input, |ui| {
                preview(ui, "Source Sans 3");
            });
            o.textures_delta.clear();
            out = Some(o);
        }
        let want = if theme == egui::Theme::Dark { Tokens::dark().text } else { Tokens::light().text };
        let shapes = out.map(|o| o.shapes).unwrap_or_default();
        let mut images = 0;
        for s in &shapes {
            match &s.shape {
                egui::Shape::Mesh(m) if m.texture_id != egui::TextureId::default() => {
                    images += 1;
                    assert!(m.vertices.iter().all(|v| v.color == want), "{theme:?}: the entry is not tinted with the text colour");
                }
                egui::Shape::Rect(r) => panic!("{theme:?}: an idle entry paints no background, got {:?}", r.fill),
                _ => {}
            }
        }
        assert_eq!(images, 1, "{theme:?}: the entry draws its rendered name");
    }
}

/// Where the Home tab's Styles group, laid out as the ribbon lays it out in the current interface
/// language, puts its parts, by their accessible rectangles: the gallery's first tiles in gallery
/// order, the column of scroll arrows and "more" from the top (the unnamed buttons beside the
/// tiles; only "more" has a name), and the button named for the Styles pane.
fn styles_group_rects() -> (Vec<(String, Rect)>, Vec<Rect>, Option<Rect>) {
    use egui_kittest::kittest::{Queryable, by};
    let app = WordApp::new(wordcraft_engine::Session::new(Document::new()), Default::default());
    let names: Vec<String> = app.session.doc.styles.gallery().iter().take(super::STYLE_TILES).map(|s| crate::i18n::style_name(s)).collect();
    let mut h = egui_kittest::Harness::builder().with_size(vec2(900.0, 200.0)).build_ui_state(
        |ui, app: &mut WordApp| {
            crate::rtl::root(ui, |ui| {
                crate::rtl::horizontal_top(ui, |ui| {
                    crate::widgets::group(ui, "Styles", Some("styles.pane"), app, |ui, app| style_gallery(app, ui, &json!({})));
                });
            });
        },
        app,
    );
    h.run_steps(3);
    let tiles: Vec<(String, Rect)> = names.iter().map(|n| (n.clone(), h.get_by_label(n).rect())).collect();
    let row = tiles.first().map_or(Rect::NOTHING, |(_, r)| *r);
    // The arrows are 14 points wide and stacked beside the tiles; the group's launcher is below them.
    let mut arrows: Vec<Rect> = h
        .query_all(by().predicate(|n| n.bounding_box().is_some()))
        .map(|n| n.rect())
        .filter(|r| r.width() <= 16.0 && (row.min.y..=row.max.y).contains(&r.center().y))
        .collect();
    arrows.sort_by(|a, b| a.min.y.total_cmp(&b.min.y));
    let more = h.query_by_label(crate::i18n::t("Styles Pane")).map(|n| n.rect());
    (tiles, arrows, more)
}

/// #5566: in a right-to-left interface the Styles gallery starts at the right, as the rest of
/// the ribbon does: the first style (Normal) is the rightmost tile, and the scroll arrows and
/// "more" sit at the gallery's left end. Left to right is unchanged.
#[test]
fn the_styles_gallery_reads_from_the_right_in_a_right_to_left_interface() {
    crate::i18n::set_current(crate::i18n::Lang::EN);
    let (tiles, arrows, more) = styles_group_rects();
    assert!(tiles.len() >= 2, "the gallery shows its tiles: {tiles:?}");
    assert_eq!(arrows.len(), 3, "up, down and more: {arrows:?}");
    assert!(tiles.windows(2).all(|w| w[0].1.center().x < w[1].1.center().x), "left to right, tiles run rightwards: {tiles:?}");
    assert!(
        arrows.iter().all(|a| tiles.iter().all(|(_, r)| a.min.x >= r.max.x)),
        "left to right, the arrows are right of every tile: {arrows:?} {tiles:?}"
    );
    let ltr_more = (more, arrows.last().copied());

    // An Arabic interface; its catalog is not needed (the harness has no Arabic font to draw it).
    crate::i18n::set_current(crate::i18n::fixture_lang("ar", "\tHome\tالرئيسية\n"));
    let (tiles, arrows, more) = styles_group_rects();
    crate::i18n::set_current(crate::i18n::Lang::EN);
    assert_eq!(tiles.first().map(|(n, _)| n.as_str()), Some("Normal"), "the first tile is Normal");
    assert_eq!(arrows.len(), 3, "up, down and more: {arrows:?}");
    assert!(tiles.windows(2).all(|w| w[0].1.center().x > w[1].1.center().x), "right to left, tiles run leftwards: {tiles:?}");
    assert!(
        arrows.iter().all(|a| tiles.iter().all(|(_, r)| a.max.x <= r.min.x)),
        "right to left, the arrows are left of every tile: {arrows:?} {tiles:?}"
    );

    // Screen readers find "more", the bottom arrow, by the pane it opens, in either direction.
    for (more, bottom) in [ltr_more, (more, arrows.last().copied())] {
        assert!(more.is_some() && more == bottom, "the bottom arrow ({bottom:?}) is named for the Styles pane ({more:?})");
    }
}

#[test]
fn font_sample_shows_small_caps_and_the_script_mark() {
    let white = wordcraft_doc::Rgb(255, 255, 255);
    let plain = CharProps { size: Some(20.0), ..Default::default() };
    let draw = |p: &CharProps, mark, dark| font_sample("AaBbYyZz", p, mark, (200.0, 40.0, 1.0), white, dark).map(|i| i.pixels);
    let small = CharProps { small_caps: Some(true), ..plain.clone() };
    assert_ne!(draw(&plain, None, false), draw(&small, None, false), "small caps change the sample");
    let sup = Some(wordcraft_doc::props::VertAlign::Superscript);
    assert_ne!(draw(&plain, None, false), draw(&plain, sup, false), "the mark is drawn");
    assert_ne!(draw(&plain, None, false), draw(&plain, None, true), "Switch Modes transforms the preview");
}
