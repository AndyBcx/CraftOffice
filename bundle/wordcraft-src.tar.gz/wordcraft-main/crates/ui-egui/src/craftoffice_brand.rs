//! CraftOffice: a felületen megjelenő Craft appnevek saját névre cserélése (magyar ragozással).
//! Csak a megjelenő szövegre hat; fájlok, mappák, beállítások neve nem változik.

/// (eredeti név, CraftOffice-név, az utolsó szó ragozott alakjai: tárgyeset, -ban, -ból, -tól,
/// -val, -nak, -hoz, -ra, -on, -ról, -ba, -ig)
const NAMES: &[(&str, &str, [&str; 12])] = &[
    ("WordCraft", "CraftOffice Writer", ["Writert", "Writerben", "Writerből", "Writertől", "Writerrel", "Writernek", "Writerhez", "Writerre", "Writeren", "Writerről", "Writerbe", "Writerig"]),
    ("GridCraft", "CraftOffice Sheets", ["Sheetset", "Sheetsben", "Sheetsből", "Sheetstől", "Sheetsszel", "Sheetsnek", "Sheetshez", "Sheetsre", "Sheetsen", "Sheetsről", "Sheetsbe", "Sheetsig"]),
    ("DeckCraft", "CraftOffice Slides", ["Slidesot", "Slidesban", "Slidesból", "Slidestól", "Slidesszal", "Slidesnak", "Slideshoz", "Slidesra", "Slideson", "Slidesról", "Slidesba", "Slidesig"]),
    ("DesignCraft", "CraftOffice Layout", ["Layoutot", "Layoutban", "Layoutból", "Layouttól", "Layouttal", "Layoutnak", "Layouthoz", "Layoutra", "Layouton", "Layoutról", "Layoutba", "Layoutig"]),
    ("PdfCraft", "CraftOffice PDF", ["PDF-et", "PDF-ben", "PDF-ből", "PDF-től", "PDF-fel", "PDF-nek", "PDF-hez", "PDF-re", "PDF-en", "PDF-ről", "PDF-be", "PDF-ig"]),
    ("PhotoCraft", "CraftOffice Photo", ["Photót", "Photóban", "Photóból", "Photótól", "Photóval", "Photónak", "Photóhoz", "Photóra", "Photón", "Photóról", "Photóba", "Photóig"]),
    ("VectorCraft", "CraftOffice Vector", ["Vectort", "Vectorban", "Vectorból", "Vectortól", "Vectorral", "Vectornak", "Vectorhoz", "Vectorra", "Vectoron", "Vectorról", "Vectorba", "Vectorig"]),
    ("LightCraft", "CraftOffice Darkroom", ["Darkroomot", "Darkroomban", "Darkroomból", "Darkroomtól", "Darkroommal", "Darkroomnak", "Darkroomhoz", "Darkroomra", "Darkroomon", "Darkroomról", "Darkroomba", "Darkroomig"]),
    ("FilmCraft", "CraftOffice Video", ["Videót", "Videóban", "Videóból", "Videótól", "Videóval", "Videónak", "Videóhoz", "Videóra", "Videón", "Videóról", "Videóba", "Videóig"]),
    ("EffectCraft", "CraftOffice Motion", ["Motiont", "Motionben", "Motionből", "Motiontől", "Motionnel", "Motionnek", "Motionhöz", "Motionre", "Motionön", "Motionről", "Motionbe", "Motionig"]),
    ("SoundCraft", "CraftOffice Audio", ["Audiót", "Audióban", "Audióból", "Audiótól", "Audióval", "Audiónak", "Audióhoz", "Audióra", "Audión", "Audióról", "Audióba", "Audióig"]),
    ("AniCraft", "CraftOffice Animation", ["Animationt", "Animationben", "Animationből", "Animationtől", "Animationnel", "Animationnek", "Animationhöz", "Animationre", "Animationön", "Animationről", "Animationbe", "Animationig"]),
    ("FigCraft", "CraftOffice Prototype", ["Prototype-ot", "Prototype-ban", "Prototype-ból", "Prototype-tól", "Prototype-pal", "Prototype-nak", "Prototype-hoz", "Prototype-ra", "Prototype-on", "Prototype-ról", "Prototype-ba", "Prototype-ig"]),
    ("CADCraft", "CraftOffice CAD", ["CAD-et", "CAD-ben", "CAD-ből", "CAD-től", "CAD-del", "CAD-nek", "CAD-hez", "CAD-re", "CAD-en", "CAD-ről", "CAD-be", "CAD-ig"]),
    ("MaterialCraft", "CraftOffice Material", ["Materialt", "Materialben", "Materialből", "Materialtől", "Materiallel", "Materialnek", "Materialhez", "Materialre", "Materialen", "Materialről", "Materialbe", "Materialig"]),
    ("TextureCraft", "CraftOffice Texture", ["Texture-t", "Texture-ben", "Texture-ből", "Texture-től", "Texture-rel", "Texture-nek", "Texture-höz", "Texture-re", "Texture-ön", "Texture-ről", "Texture-be", "Texture-ig"]),
    ("Craft Anything", "CraftOffice Workshop", ["Workshopot", "Workshopban", "Workshopból", "Workshoptól", "Workshoppal", "Workshopnak", "Workshophoz", "Workshopra", "Workshopon", "Workshopról", "Workshopba", "Workshopig"]),
];

const SUFFIX: &[(&str, usize)] = &[
    ("ot", 0),
    ("ban", 1),
    ("ból", 2),
    ("tól", 3),
    ("tal", 4),
    ("val", 4),
    ("nak", 5),
    ("hoz", 6),
    ("ra", 7),
    ("on", 8),
    ("ról", 9),
    ("ba", 10),
    ("ig", 11),
];

fn brand_string(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 16);
    let mut rest = s;
    'outer: while !rest.is_empty() {
        for (orig, new, forms) in NAMES {
            if let Some(after) = rest.strip_prefix(orig) {
                // a név utáni betűk (rag), ha vannak
                let tail_len: usize = after.char_indices().take_while(|(_, c)| c.is_alphabetic()).map(|(i, c)| i + c.len_utf8()).last().unwrap_or(0);
                let suffix = &after[..tail_len];
                if suffix.is_empty() {
                    out.push_str(new);
                } else if let Some((_, case)) = SUFFIX.iter().find(|(k, _)| *k == suffix) {
                    let base = new.rsplit_once(' ').map_or("", |(b, _)| b);
                    if !base.is_empty() {
                        out.push_str(base);
                        out.push(' ');
                    }
                    out.push_str(forms.get(*case).copied().unwrap_or(new));
                } else {
                    out.push_str(new);
                    out.push('-');
                    out.push_str(suffix);
                }
                rest = &after[tail_len..];
                continue 'outer;
            }
        }
        let mut chars = rest.chars();
        if let Some(c) = chars.next() {
            out.push(c);
        }
        rest = chars.as_str();
    }
    out
}

/// `s` a CraftOffice-nevekkel. Változatlan szövegnél nincs másolás; a lecserélt szövegek egyszer
/// készülnek el és megmaradnak (a felület szövegei véges számúak).
pub fn brand(s: &str) -> &str {
    if !NAMES.iter().any(|(o, _, _)| s.contains(o)) {
        return s;
    }
    static CACHE: std::sync::Mutex<Option<std::collections::HashMap<String, &'static str>>> = std::sync::Mutex::new(None);
    let mut guard = CACHE.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    let map = guard.get_or_insert_with(std::collections::HashMap::new);
    if let Some(v) = map.get(s) {
        return v;
    }
    let v: &'static str = Box::leak(brand_string(s).into_boxed_str());
    map.insert(s.to_string(), v);
    v
}
