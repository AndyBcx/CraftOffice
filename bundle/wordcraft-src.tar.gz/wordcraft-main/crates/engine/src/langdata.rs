//! Per-language lists in LibreOffice's formats, read from the dictionaries folders
//! (`WORDCRAFT_DICTIONARIES`, WordCraft's own `dictionaries` folder, the system's):
//!
//! - AutoCorrect: `acor_<lang>.dat` (`acor_hu-HU.dat`), a zip with `DocumentList.xml`
//!   (replacements), `SentenceExceptList.xml` (abbreviations after which a sentence doesn't end)
//!   and `WordExceptList.xml` (words that keep two initial capitals).
//! - Thesaurus: `th_<lang>*.dat` (`th_hu_HU_v2.dat`), MyThes text format.
//!
//! English keeps WordCraft's own built-in lists; these add other languages (CraftOffice).
//! Everything is loaded lazily, once per language, and nothing here panics on a damaged file.

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Arc, PoisonError, RwLock};

/// Largest file read (real ones are a few MB).
const MAX_FILE: u64 = 32 << 20;
/// Largest unpacked zip member.
const MAX_MEMBER: usize = 16 << 20;

/// A language's AutoCorrect lists.
#[derive(Debug, Default)]
pub struct AutoCorrectList {
    pub replacements: HashMap<String, String>,
    /// Lowercase, with their full stop ("pl.", "stb.").
    pub sentence_exceptions: Vec<String>,
    pub word_exceptions: Vec<String>,
}

impl AutoCorrectList {
    /// The replacement for `word`: an exact entry, else a lowercase entry for a capitalised word
    /// (its replacement capitalised too).
    pub fn replacement(&self, word: &str) -> Option<String> {
        if let Some(v) = self.replacements.get(word) {
            return Some(v.clone());
        }
        let mut cs = word.chars();
        let first = cs.next()?;
        if first.is_uppercase() {
            let low: String = first.to_lowercase().chain(cs).collect();
            if let Some(v) = self.replacements.get(&low) {
                let mut vc = v.chars();
                return vc.next().map(|f| f.to_uppercase().chain(vc).collect());
            }
        }
        None
    }
}

type Synonyms = HashMap<String, Vec<String>>;

static AUTOCORRECT: RwLock<Option<HashMap<String, Option<Arc<AutoCorrectList>>>>> = RwLock::new(None);
static THESAURUS: RwLock<Option<HashMap<String, Option<Arc<Synonyms>>>>> = RwLock::new(None);

fn primary(tag: &str) -> String {
    tag.split(['-', '_', '.', '@']).next().unwrap_or("").to_ascii_lowercase()
}

fn region(tag: &str) -> Option<String> {
    tag.split(['-', '_']).nth(1).filter(|r| r.len() == 2).map(str::to_ascii_uppercase)
}

fn dirs() -> Vec<PathBuf> {
    wordcraft_proof::hunspell::search_dirs(None)
}

/// The first file in the dictionaries folders whose name (lowercase) starts with one of
/// `prefixes` and ends with `.dat`.
fn find_file(prefixes: &[String]) -> Option<PathBuf> {
    for d in dirs() {
        let Ok(rd) = std::fs::read_dir(&d) else { continue };
        let mut names: Vec<(String, PathBuf)> = rd
            .flatten()
            .filter(|e| e.file_type().is_ok_and(|t| t.is_file()))
            .map(|e| (e.file_name().to_string_lossy().to_lowercase(), e.path()))
            .filter(|(n, _)| n.ends_with(".dat"))
            .collect();
        names.sort();
        for p in prefixes {
            if let Some((_, path)) = names.iter().find(|(n, _)| n.starts_with(p.as_str())) {
                return Some(path.clone());
            }
        }
    }
    None
}

fn read_capped(path: &Path) -> Option<Vec<u8>> {
    let len = std::fs::metadata(path).ok()?.len();
    if len > MAX_FILE {
        return None;
    }
    std::fs::read(path).ok()
}

// ---------- AutoCorrect ----------

/// The AutoCorrect lists for text tagged `tag`, if a LibreOffice list for its language is
/// installed. English has WordCraft's own list and gets none here.
pub fn autocorrect_for(tag: Option<&str>) -> Option<Arc<AutoCorrectList>> {
    let tag = tag?;
    let lang = primary(tag);
    if lang.is_empty() || lang == "en" {
        return None;
    }
    if let Some(cache) = AUTOCORRECT.read().unwrap_or_else(PoisonError::into_inner).as_ref() {
        if let Some(hit) = cache.get(&lang) {
            return hit.clone();
        }
    }
    let mut prefixes = Vec::new();
    if let Some(r) = region(tag) {
        prefixes.push(format!("acor_{lang}-{}", r.to_lowercase()));
    }
    prefixes.push(format!("acor_{lang}."));
    prefixes.push(format!("acor_{lang}"));
    let loaded = find_file(&prefixes).and_then(|p| {
        let r = load_autocorrect(&p);
        if r.is_none() {
            log::warn!("autocorrect: could not read {}", p.display());
        }
        r
    });
    let loaded = loaded.map(Arc::new);
    AUTOCORRECT
        .write()
        .unwrap_or_else(PoisonError::into_inner)
        .get_or_insert_with(HashMap::new)
        .insert(lang, loaded.clone());
    loaded
}

fn load_autocorrect(path: &Path) -> Option<AutoCorrectList> {
    let data = read_capped(path)?;
    let members = unzip(&data)?;
    let get = |name: &str| members.iter().find(|(n, _)| n == name).map(|(_, b)| String::from_utf8_lossy(b).into_owned());
    let mut list = AutoCorrectList::default();
    if let Some(x) = get("DocumentList.xml") {
        for attrs in blocks(&x) {
            let (Some(from), Some(to)) = (attr(attrs, "abbreviated-name"), attr(attrs, "name")) else { continue };
            // LibreOffice's pattern entries (".*", "*") and empty ones are not plain words.
            if from.is_empty() || from.contains('*') || from.contains(char::is_whitespace) {
                continue;
            }
            list.replacements.entry(from).or_insert(to);
        }
    }
    if let Some(x) = get("SentenceExceptList.xml") {
        list.sentence_exceptions = blocks(&x).filter_map(|a| attr(a, "abbreviated-name")).map(|s| s.to_lowercase()).collect();
    }
    if let Some(x) = get("WordExceptList.xml") {
        list.word_exceptions = blocks(&x).filter_map(|a| attr(a, "abbreviated-name")).collect();
    }
    log::info!(
        "autocorrect: {} entries, {} sentence exceptions from {}",
        list.replacements.len(),
        list.sentence_exceptions.len(),
        path.display()
    );
    Some(list)
}

/// The attribute text of each `<block-list:block …/>` element.
fn blocks(xml: &str) -> impl Iterator<Item = &str> {
    xml.split("<block-list:block ").skip(1).filter_map(|s| s.find("/>").or_else(|| s.find('>')).map(|e| &s[..e]))
}

/// `block-list:<name>="value"` in `attrs`, unescaped.
fn attr(attrs: &str, name: &str) -> Option<String> {
    let key = format!("block-list:{name}=\"");
    let start = attrs.find(&key)? + key.len();
    let end = attrs[start..].find('"')? + start;
    Some(unescape(&attrs[start..end]))
}

fn unescape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut rest = s;
    while let Some(i) = rest.find('&') {
        out.push_str(&rest[..i]);
        rest = &rest[i..];
        let Some(semi) = rest.find(';') else { break };
        let ent = &rest[1..semi];
        let ch = match ent {
            "amp" => Some('&'),
            "lt" => Some('<'),
            "gt" => Some('>'),
            "quot" => Some('"'),
            "apos" => Some('\''),
            e if e.starts_with("#x") || e.starts_with("#X") => u32::from_str_radix(&e[2..], 16).ok().and_then(char::from_u32),
            e if e.starts_with('#') => e[1..].parse().ok().and_then(char::from_u32),
            _ => None,
        };
        match ch {
            Some(c) => {
                out.push(c);
                rest = &rest[semi + 1..];
            }
            None => {
                out.push('&');
                rest = &rest[1..];
            }
        }
    }
    out.push_str(rest);
    out
}

/// A minimal zip reader (stored and deflated members), enough for LibreOffice's `.dat` lists.
fn unzip(data: &[u8]) -> Option<Vec<(String, Vec<u8>)>> {
    let u16_at = |o: usize| data.get(o..o + 2).map(|b| u16::from_le_bytes([b[0], b[1]]) as usize);
    let u32_at = |o: usize| data.get(o..o + 4).map(|b| u32::from_le_bytes([b[0], b[1], b[2], b[3]]) as usize);
    // End of central directory: the last "PK\x05\x06".
    let eocd = (0..data.len().saturating_sub(21)).rev().take(70_000).find(|&i| data.get(i..i + 4) == Some(b"PK\x05\x06"))?;
    let count = u16_at(eocd + 10)?;
    let mut off = u32_at(eocd + 16)?;
    let mut out = Vec::new();
    for _ in 0..count.min(4096) {
        if data.get(off..off + 4)? != b"PK\x01\x02" {
            break;
        }
        let method = u16_at(off + 10)?;
        let csize = u32_at(off + 20)?;
        let usize_ = u32_at(off + 24)?;
        let (nlen, elen, clen) = (u16_at(off + 28)?, u16_at(off + 30)?, u16_at(off + 32)?);
        let local = u32_at(off + 42)?;
        let name = String::from_utf8_lossy(data.get(off + 46..off + 46 + nlen)?).into_owned();
        off += 46 + nlen + elen + clen;
        if data.get(local..local + 4)? != b"PK\x03\x04" || usize_ > MAX_MEMBER {
            continue;
        }
        let start = local + 30 + u16_at(local + 26)? + u16_at(local + 28)?;
        let raw = data.get(start..start + csize)?;
        let bytes = match method {
            0 => raw.to_vec(),
            8 => match miniz_oxide::inflate::decompress_to_vec_with_limit(raw, MAX_MEMBER) {
                Ok(b) => b,
                Err(_) => continue,
            },
            _ => continue,
        };
        out.push((name, bytes));
    }
    Some(out)
}

// ---------- Thesaurus ----------

/// Synonyms of `word` (any case) from the MyThes thesaurus of `tag`'s language, if one is
/// installed: every meaning's words, without duplicates or the word itself.
pub fn synonyms(tag: Option<&str>, word: &str) -> Option<Vec<String>> {
    let tag = tag?;
    let lang = primary(tag);
    if lang.is_empty() {
        return None;
    }
    let th = thesaurus_for(&lang, region(tag))?;
    let key = word.trim().to_lowercase();
    let list = th.get(&key)?;
    let mut seen = std::collections::HashSet::new();
    seen.insert(key);
    Some(list.iter().filter(|w| seen.insert(w.to_lowercase())).take(40).cloned().collect())
}

fn thesaurus_for(lang: &str, region: Option<String>) -> Option<Arc<Synonyms>> {
    if let Some(cache) = THESAURUS.read().unwrap_or_else(PoisonError::into_inner).as_ref() {
        if let Some(hit) = cache.get(lang) {
            return hit.clone();
        }
    }
    let mut prefixes = Vec::new();
    if let Some(r) = region {
        prefixes.push(format!("th_{lang}_{}", r.to_lowercase()));
        prefixes.push(format!("th_{lang}-{}", r.to_lowercase()));
    }
    prefixes.push(format!("th_{lang}_"));
    prefixes.push(format!("th_{lang}"));
    let loaded = find_file(&prefixes).and_then(|p| read_capped(&p).map(|b| (p, b))).map(|(p, b)| {
        let t = parse_mythes(&b);
        log::info!("thesaurus: {} entries from {}", t.len(), p.display());
        Arc::new(t)
    });
    THESAURUS
        .write()
        .unwrap_or_else(PoisonError::into_inner)
        .get_or_insert_with(HashMap::new)
        .insert(lang.to_string(), loaded.clone());
    loaded
}

/// MyThes: an encoding line, then `word|meanings` followed by that many `(pos)|syn|syn…` lines.
fn parse_mythes(bytes: &[u8]) -> Synonyms {
    let text = match std::str::from_utf8(bytes) {
        Ok(t) => std::borrow::Cow::Borrowed(t),
        // Older thesauri are ISO 8859-x: read the bytes as Latin-1 rather than fail.
        Err(_) => std::borrow::Cow::Owned(bytes.iter().map(|&b| b as char).collect::<String>()),
    };
    let mut map: Synonyms = HashMap::new();
    let mut lines = text.lines().skip(1);
    while let Some(head) = lines.next() {
        let Some((word, n)) = head.rsplit_once('|') else { continue };
        let Ok(n) = n.trim().parse::<usize>() else { continue };
        let mut syns = Vec::new();
        for _ in 0..n.min(200) {
            let Some(l) = lines.next() else { break };
            for s in l.split('|').skip(1) {
                let s = s.trim();
                // "(antonym)"-style notes and empty fields are not words to offer.
                let s = s.split(" (").next().unwrap_or(s).trim();
                // vezető stílusjelölés: "(pop.) chipos", "(înv. și reg.) vederos"
                let s = if s.starts_with('(') { s.split_once(')').map_or(s, |(_, r)| r).trim() } else { s };
                if !s.is_empty() {
                    syns.push(s.to_string());
                }
            }
        }
        if !syns.is_empty() {
            map.entry(word.trim().to_lowercase()).or_default().extend(syns);
        }
    }
    map
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mythes() {
        let t = parse_mythes("UTF-8\nparány|1\n|testecske|korpuszkula|részecske|\nsárcipő|1\n|sárcipő|kalocsni\n".as_bytes());
        assert_eq!(t["parány"], vec!["testecske", "korpuszkula", "részecske"]);
        assert_eq!(t["sárcipő"], vec!["sárcipő", "kalocsni"]);
        let r = parse_mythes("UTF-8\nfrumos|1\n(adj.)|estetic|(pop.) chipos|(înv. și reg.) vederos\n".as_bytes());
        assert_eq!(r["frumos"], vec!["estetic", "chipos", "vederos"]);
    }

    #[test]
    fn entities_and_blocks() {
        let x = r#"<block-list:block block-list:abbreviated-name="(c)" block-list:name="&#169;"/><block-list:block block-list:abbreviated-name="ojan" block-list:name="olyan"/>"#;
        let v: Vec<(String, String)> =
            blocks(x).map(|a| (attr(a, "abbreviated-name").unwrap(), attr(a, "name").unwrap())).collect();
        assert_eq!(v, vec![("(c)".into(), "©".into()), ("ojan".into(), "olyan".into())]);
        assert_eq!(unescape("a &amp; b &lt;x&gt; &#x41;"), "a & b <x> A");
    }

    #[test]
    fn capitalised_lookup() {
        let mut l = AutoCorrectList::default();
        l.replacements.insert("ojan".into(), "olyan".into());
        assert_eq!(l.replacement("ojan").as_deref(), Some("olyan"));
        assert_eq!(l.replacement("Ojan").as_deref(), Some("Olyan"));
        assert_eq!(l.replacement("x"), None);
    }
}
