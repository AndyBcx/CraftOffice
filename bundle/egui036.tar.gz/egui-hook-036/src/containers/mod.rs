//! Containers are pieces of the UI which wraps other pieces of UI. Examples: [`Window`], [`ScrollArea`], [`Resize`], [`Panel`], etc.
//!
//! For instance, a [`Frame`] adds a frame and background to some contained UI.

pub(crate) mod area;
mod close_tag;
pub mod collapsing_header;
mod combo_box;
pub mod frame;
pub mod menu;
pub mod modal;
pub mod panel;
mod popup;
pub(crate) mod resize;
mod scene;
pub mod scroll_area;
mod sides;
mod tooltip;
pub(crate) mod window;

pub use {
    area::{Area, AreaState},
    close_tag::ClosableTag,
    collapsing_header::{CollapsingHeader, CollapsingResponse},
    combo_box::*,
    frame::Frame,
    modal::{Modal, ModalResponse},
    panel::*,
    popup::*,
    resize::Resize,
    scene::{DragPanButtons, Scene},
    scroll_area::ScrollArea,
    sides::Sides,
    tooltip::*,
    window::{Window, WindowDrag},
};
