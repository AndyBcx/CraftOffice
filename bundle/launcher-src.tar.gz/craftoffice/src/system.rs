//! Windows-integráció: fájltársítások („Társítás”/„Megnyitás ezzel”) és parancsikonok.

use crate::apps::{all, Installed};
use std::collections::HashMap;
use std::path::Path;

#[cfg(windows)]
pub fn register_associations(launcher: &Path) -> Result<usize, String> {
    use winreg::enums::*;
    use winreg::RegKey;
    let hkcu = RegKey::predef(HKEY_CURRENT_USER);
    let classes = hkcu
        .open_subkey_with_flags("Software\\Classes", KEY_ALL_ACCESS)
        .map_err(|e| e.to_string())?;
    let cmd = format!("\"{}\" \"%1\"", launcher.display());
    let icon = format!("\"{}\",0", launcher.display());
    let mut count = 0;
    for app in all().into_iter().filter(|a| !a.exts.is_empty()) {
        let progid = format!("CraftOffice.{}", app.id);
        let (k, _) = classes.create_subkey(&progid).map_err(|e| e.to_string())?;
        k.set_value("", &format!("CraftOffice {} dokumentum", app.name)).map_err(|e| e.to_string())?;
        let (di, _) = k.create_subkey("DefaultIcon").map_err(|e| e.to_string())?;
        di.set_value("", &icon).map_err(|e| e.to_string())?;
        let (c, _) = k.create_subkey("shell\\open\\command").map_err(|e| e.to_string())?;
        c.set_value("", &cmd).map_err(|e| e.to_string())?;
        for ext in app.exts {
            if matches!(*ext, "txt" | "md" | "markdown" | "htm" | "html" | "tex") {
                continue; // ezeket nem vesszük át alapértelmezésnek
            }
            let (ek, _) = classes
                .create_subkey(format!(".{ext}\\OpenWithProgids"))
                .map_err(|e| e.to_string())?;
            ek.set_value(&progid, &"").map_err(|e| e.to_string())?;
            count += 1;
        }
    }
    // "Megnyitás ezzel" listához az alkalmazás neve
    let (a, _) = classes
        .create_subkey("Applications\\craftoffice.exe")
        .map_err(|e| e.to_string())?;
    a.set_value("FriendlyAppName", &"CraftOffice").map_err(|e| e.to_string())?;
    let (ac, _) = a.create_subkey("shell\\open\\command").map_err(|e| e.to_string())?;
    ac.set_value("", &cmd).map_err(|e| e.to_string())?;
    notify_assoc_changed();
    Ok(count)
}

#[cfg(windows)]
pub fn unregister_associations() -> Result<(), String> {
    use winreg::enums::*;
    use winreg::RegKey;
    let hkcu = RegKey::predef(HKEY_CURRENT_USER);
    let classes = hkcu
        .open_subkey_with_flags("Software\\Classes", KEY_ALL_ACCESS)
        .map_err(|e| e.to_string())?;
    for app in all().into_iter().filter(|a| !a.exts.is_empty()) {
        let progid = format!("CraftOffice.{}", app.id);
        let _ = classes.delete_subkey_all(&progid);
        for ext in app.exts {
            if let Ok(k) =
                classes.open_subkey_with_flags(format!(".{ext}\\OpenWithProgids"), KEY_ALL_ACCESS)
            {
                let _ = k.delete_value(&progid);
            }
        }
    }
    let _ = classes.delete_subkey_all("Applications\\craftoffice.exe");
    notify_assoc_changed();
    Ok(())
}

#[cfg(windows)]
fn notify_assoc_changed() {
    use windows_sys::Win32::UI::Shell::{SHChangeNotify, SHCNE_ASSOCCHANGED, SHCNF_IDLIST};
    unsafe { SHChangeNotify(SHCNE_ASSOCCHANGED as i32, SHCNF_IDLIST, std::ptr::null(), std::ptr::null()) };
}

#[cfg(not(windows))]
pub fn register_associations(_launcher: &Path) -> Result<usize, String> {
    Err("Csak Windowson érhető el".into())
}
#[cfg(not(windows))]
pub fn unregister_associations() -> Result<(), String> {
    Err("Csak Windowson érhető el".into())
}

pub fn open_default_apps_settings() {
    crate::apps::open_url("ms-settings:defaultapps");
}

/// Parancsikonok PowerShell + WScript.Shell segítségével.
fn make_shortcuts(items: &[(String, String, String)]) -> Result<(), String> {
    // (lnk-útvonal, cél, munkakönyvtár)
    let mut script = String::from("$s=New-Object -ComObject WScript.Shell;");
    for (lnk, target, wd) in items {
        let esc = |s: &str| s.replace('\'', "''");
        script.push_str(&format!(
            "$l=$s.CreateShortcut('{}');$l.TargetPath='{}';$l.WorkingDirectory='{}';$l.Save();",
            esc(lnk),
            esc(target),
            esc(wd)
        ));
    }
    let st = crate::apps::hidden_command("powershell.exe")
        .args(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", &script])
        .status()
        .map_err(|e| e.to_string())?;
    if st.success() {
        Ok(())
    } else {
        Err("A PowerShell hibát jelzett".into())
    }
}

pub fn desktop_shortcut(launcher: &Path) -> Result<(), String> {
    let home = crate::config::home_dir().ok_or("Nincs felhasználói mappa")?;
    // OneDrive alatti Asztal is lehet
    let desk = [home.join("Desktop"), home.join("OneDrive").join("Desktop"), home.join("OneDrive").join("Asztal")]
        .into_iter()
        .find(|p| p.is_dir())
        .ok_or("Nem található az Asztal mappa")?;
    let wd = launcher.parent().unwrap_or(launcher).display().to_string();
    make_shortcuts(&[(
        desk.join("CraftOffice.lnk").display().to_string(),
        launcher.display().to_string(),
        wd,
    )])
}

pub fn start_menu_shortcuts(launcher: &Path, installed: &HashMap<&'static str, Installed>) -> Result<usize, String> {
    let appdata = std::env::var_os("APPDATA").ok_or("Nincs APPDATA")?;
    let dir = Path::new(&appdata).join("Microsoft\\Windows\\Start Menu\\Programs\\CraftOffice");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let mut items = vec![(
        dir.join("CraftOffice.lnk").display().to_string(),
        launcher.display().to_string(),
        launcher.parent().unwrap_or(launcher).display().to_string(),
    )];
    for app in all() {
        if let Some(i) = installed.get(app.id) {
            items.push((
                dir.join(format!("{}.lnk", crate::apps::brand_name(app).unwrap_or_else(|| app.name.to_string()))).display().to_string(),
                i.exe.display().to_string(),
                i.dir.display().to_string(),
            ));
        }
    }
    make_shortcuts(&items)?;
    Ok(items.len())
}
