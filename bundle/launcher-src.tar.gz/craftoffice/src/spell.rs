//! Magyar helyesírás (Magyar Ispell, Hunspell) a WordCraft és a többi Craft app számára.
//! A szótár a csomag `szotarak` mappájában van; a launcher
//!  1) a `WORDCRAFT_DICTIONARIES` változóban átadja az általa indított appoknak, és
//!  2) bemásolja a WordCraft saját szótármappájába (%APPDATA%\WordCraft\dictionaries),
//!     hogy a közvetlenül indított WordCraft is lássa.

use crate::config::exe_dir;
use std::path::PathBuf;

/// A csomag szótárfájljai (helyesírás, elválasztás, automatikus javítás, szinonimák):
/// minden .aff/.dic/.dat/.idx a `szotarak` mappában (magyar, román…).
pub fn files() -> Vec<String> {
    let Ok(rd) = std::fs::read_dir(bundled_dir()) else { return Vec::new() };
    let mut v: Vec<String> = rd
        .flatten()
        .map(|e| e.file_name().to_string_lossy().to_string())
        .filter(|n| {
            let l = n.to_lowercase();
            l.ends_with(".aff") || l.ends_with(".dic") || l.ends_with(".dat") || l.ends_with(".idx")
        })
        .collect();
    v.sort();
    v
}

/// Mely nyelvek vannak a csomagban (helyesírási szótár alapján), pl. ["hu_HU", "ro_RO"].
pub fn languages() -> Vec<String> {
    files().iter().filter(|f| f.ends_with(".aff")).map(|f| f.trim_end_matches(".aff").to_string()).collect()
}

pub fn bundled_dir() -> PathBuf {
    exe_dir().join("szotarak")
}

pub fn bundled() -> bool {
    !languages().is_empty()
}

pub fn wordcraft_dir() -> Option<PathBuf> {
    let base = std::env::var_os("APPDATA")
        .map(PathBuf::from)
        .or_else(|| crate::config::home_dir().map(|h| h.join(".local/share")))?;
    Some(base.join(if cfg!(windows) { "WordCraft" } else { "wordcraft" }).join("dictionaries"))
}

pub fn installed() -> bool {
    let Some(d) = wordcraft_dir() else { return false };
    files().iter().all(|f| {
        matches!((std::fs::metadata(bundled_dir().join(f)), std::fs::metadata(d.join(f))), (Ok(a), Ok(b)) if a.len() == b.len())
    })
}

/// Bemásolja a magyar szótárt a WordCraft szótármappájába (ha még nincs ott ugyanez).
pub fn install() -> Result<PathBuf, String> {
    if !bundled() {
        return Err("A csomagban nincs magyar szótár (szotarak mappa)".into());
    }
    let d = wordcraft_dir().ok_or("Nincs APPDATA mappa")?;
    std::fs::create_dir_all(&d).map_err(|e| e.to_string())?;
    for f in files() {
        let src = bundled_dir().join(&f);
        let dst = d.join(&f);
        let same = matches!((std::fs::metadata(&src), std::fs::metadata(&dst)), (Ok(a), Ok(b)) if a.len() == b.len());
        if !same {
            std::fs::copy(&src, &dst).map_err(|e| format!("{f}: {e}"))?;
        }
    }
    Ok(d)
}

/// Környezeti változó az indított appoknak (ha a felhasználó nem állított be sajátot).
pub fn env_for_child() -> Option<(&'static str, PathBuf)> {
    if std::env::var_os("WORDCRAFT_DICTIONARIES").is_some() || !bundled() {
        return None;
    }
    Some(("WORDCRAFT_DICTIONARIES", bundled_dir()))
}
