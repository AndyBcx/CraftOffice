#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
//! CraftOffice – közös indító a Craft irodai alkalmazásokhoz (WordCraft, GridCraft, DeckCraft,
//! DesignCraft, PdfCraft). Paraméterként kapott fájlt a megfelelő alkalmazásban nyit meg.

mod apps;
mod config;
mod download;
mod icon;
mod scan;
mod spell;
mod system;
mod ui;

use std::path::PathBuf;

/// `craftoffice.exe dokumentum.docx` → azonnal megnyitja a megfelelő appban, ablak nélkül.
fn open_from_cli(path: &std::path::Path) -> Result<(), String> {
    let app = apps::app_for_path(path).ok_or_else(|| format!("Ismeretlen fájltípus: {}", path.display()))?;
    let mut cfg = config::Config::load();
    let installed = apps::discover_cfg(&cfg);
    let inst = installed
        .get(app.id)
        .ok_or_else(|| format!("A(z) {} nincs telepítve – a fájl megnyitásához töltsd le az Alkalmazások oldalon.", app.name))?;
    apps::launch(inst, Some(path), &[]).map_err(|e| format!("{} nem indítható: {e}", app.name))?;
    cfg.push_recent(path, app.id);
    cfg.save();
    Ok(())
}

fn main() -> eframe::Result {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut pending = None;
    let mut errors = Vec::new();
    let files: Vec<PathBuf> = args.iter().filter(|a| !a.starts_with("--")).map(PathBuf::from).collect();
    if !files.is_empty() {
        for f in &files {
            if let Err(e) = open_from_cli(f) {
                errors.push(e);
            }
        }
        if errors.is_empty() {
            return Ok(());
        }
        pending = Some(errors.join("\n"));
    }

    let mut options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("CraftOffice")
            .with_app_id("craftoffice")
            .with_inner_size([1200.0, 780.0])
            .with_min_inner_size([880.0, 560.0])
            .with_icon(icon::window_icon())
            .with_drag_and_drop(true),
        ..Default::default()
    };
    #[cfg(windows)]
    {
        // A Craft appokhoz hasonlóan csak DirectX 12 / Vulkan: egyes AMD OpenGL-meghajtók
        // összeomlanak, ha a wgpu GL-példányt is létrehoz. WGPU_BACKEND felülírja.
        use eframe::egui_wgpu::{self, wgpu};
        let mut setup = egui_wgpu::WgpuSetupCreateNew::without_display_handle();
        if wgpu::Backends::from_env().is_none() {
            setup.instance_descriptor.backends = wgpu::Backends::DX12 | wgpu::Backends::VULKAN;
        }
        setup.power_preference = wgpu::PowerPreference::LowPower;
        options.wgpu_options.wgpu_setup = egui_wgpu::WgpuSetup::CreateNew(setup);
    }
    #[cfg(not(windows))]
    {
        let _ = &mut options;
    }
    eframe::run_native(
        "CraftOffice",
        options,
        Box::new(move |cc| Ok(Box::new(ui::OfficeApp::new(cc, pending)))),
    )
}
