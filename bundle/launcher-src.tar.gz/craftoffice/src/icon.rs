//! A CraftOffice ikon: sötétkék lekerekített négyzet, arany „C” ív és pont.

pub fn rgba(size: u32) -> Vec<u8> {
    let s = size as f32;
    let navy = [0x14u8, 0x21, 0x3D];
    let gold = [0xD4u8, 0xA5, 0x37];
    let rad = s * 0.22;
    let (cx, cy) = (s / 2.0, s / 2.0);
    let (r_in, r_out) = (s * 0.20, s * 0.32);
    let mut buf = vec![0u8; (size * size * 4) as usize];
    for y in 0..size {
        for x in 0..size {
            let (fx, fy) = (x as f32 + 0.5, y as f32 + 0.5);
            // lekerekített négyzet, élsimítással
            let dx = (rad - fx).max(fx - (s - rad)).max(0.0);
            let dy = (rad - fy).max(fy - (s - rad)).max(0.0);
            let a = (0.5 - ((dx * dx + dy * dy).sqrt() - rad)).clamp(0.0, 1.0);
            if a <= 0.0 {
                continue;
            }
            let (px, py) = (fx - cx, fy - cy);
            let d = (px * px + py * py).sqrt();
            let ang = py.atan2(px).abs(); // 0 = jobbra
            let ring = (d - r_in).min(r_out - d); // >0 a gyűrűben
            let mut g = (ring + 0.5).clamp(0.0, 1.0);
            if ang < std::f32::consts::FRAC_PI_4 {
                g = 0.0; // a „C” nyílása
            }
            let dot = ((s * 0.07) - ((px - s * 0.05).powi(2) + py * py).sqrt() + 0.5).clamp(0.0, 1.0);
            let g = g.max(dot);
            let c: Vec<u8> = (0..3).map(|i| (navy[i] as f32 * (1.0 - g) + gold[i] as f32 * g) as u8).collect();
            let i = ((y * size + x) * 4) as usize;
            buf[i..i + 4].copy_from_slice(&[c[0], c[1], c[2], (a * 255.0) as u8]);
        }
    }
    buf
}

pub fn window_icon() -> egui::IconData {
    egui::IconData { rgba: rgba(64), width: 64, height: 64 }
}
