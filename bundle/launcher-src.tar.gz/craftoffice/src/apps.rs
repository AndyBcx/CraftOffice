//! Az alkalmazás-katalógus: mely Craft appok tartoznak a csomagba, hol vannak, hogyan indulnak.

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::process::Command;

#[derive(Debug)]
pub struct AppDef {
    /// Mappanév- és exe-előtag, pl. "wordcraft" → wordcraft.exe
    pub id: &'static str,
    /// Saját (CraftOffice) név, pl. "Szöveg"
    pub name: &'static str,
    /// Az eredeti Craft app neve, pl. "WordCraft"
    pub origin: &'static str,
    /// Melyik ismert programnak felel meg
    pub office: &'static str,
    /// Csoport a kezdőlapon: Iroda / Kreatív / Tervezés / Egyéb
    pub group: &'static str,
    pub desc: &'static str,
    /// "Új" kártya felirata
    pub new_label: &'static str,
    #[allow(dead_code)]
    pub letter: &'static str,
    pub color: [u8; 3],
    /// Kiterjesztések, amelyeket ez az app nyit meg (kisbetűvel, pont nélkül)
    pub exts: &'static [&'static str],
    /// Az irodai alapcsomag része-e
    pub core: bool,
    /// GitHub repó a letöltéshez
    pub repo: &'static str,
    /// Van-e beépített minta (`--sample`)
    pub sample: bool,
}

pub const GROUPS: &[&str] = &["Iroda", "Kreatív", "Tervezés", "Egyéb"];

pub const APPS: &[AppDef] = &[
    AppDef {
        id: "wordcraft",
        name: "Writer",
        origin: "WordCraft",
        office: "Word",
        group: "Iroda",
        desc: "Szövegszerkesztés: stílusok, táblázatok, korrektúra, hivatkozások, körlevél",
        new_label: "Üres dokumentum",
        letter: "Sz",
        color: [0x3B, 0x6F, 0xD8],
        exts: &["docx", "docm", "dotx", "doc", "odt", "rtf", "md", "markdown", "tex", "txt", "htm", "html"],
        core: true,
        repo: "storytold/wordcraft",
        sample: true,
    },
    AppDef {
        id: "gridcraft",
        name: "Sheets",
        origin: "GridCraft",
        office: "Excel",
        group: "Iroda",
        desc: "Táblázatkezelés: képletek, diagramok, kimutatások, feltételes formázás",
        new_label: "Üres munkafüzet",
        letter: "T",
        color: [0x2E, 0x9E, 0x5B],
        exts: &["xlsx", "xlsm", "xltx", "xls", "xlsb", "ods", "csv", "tsv"],
        core: true,
        repo: "storytold/gridcraft",
        sample: false,
    },
    AppDef {
        id: "deckcraft",
        name: "Slides",
        origin: "DeckCraft",
        office: "PowerPoint",
        group: "Iroda",
        desc: "Bemutatók: diák, átmenetek, előadói nézet, PDF-export",
        new_label: "Üres bemutató",
        letter: "B",
        color: [0xE0, 0x6A, 0x3B],
        exts: &["pptx", "pptm", "potx", "ppsx"],
        core: true,
        repo: "storytold/deckcraft",
        sample: false,
    },
    AppDef {
        id: "designcraft",
        name: "Layout",
        origin: "DesignCraft",
        office: "Publisher / InDesign",
        group: "Iroda",
        desc: "Kiadványszerkesztés: magazinok, szórólapok, IDML-import",
        new_label: "Üres kiadvány",
        letter: "K",
        color: [0x1F, 0xA3, 0x9A],
        exts: &["designcraft", "idml", "indd"],
        core: true,
        repo: "storytold/designcraft",
        sample: true,
    },
    AppDef {
        id: "pdfcraft",
        name: "PDF",
        origin: "PdfCraft",
        office: "Acrobat",
        group: "Iroda",
        desc: "PDF olvasás, jegyzetelés, oldalak rendezése, űrlapok, aláírás, OCR",
        new_label: "PDF megnyitása",
        letter: "P",
        color: [0xD6, 0x3C, 0x3C],
        exts: &["pdf"],
        core: true,
        repo: "storytold/pdfcraft",
        sample: false,
    },
    AppDef {
        id: "photocraft",
        name: "Photo",
        origin: "PhotoCraft",
        office: "Photoshop",
        group: "Kreatív",
        desc: "Képszerkesztés rétegekkel, maszkokkal, szöveggel, valódi PSD-fájlokkal",
        new_label: "Új kép",
        letter: "F",
        color: [0x2D, 0x8C, 0xE0],
        exts: &["psd", "photocraft"],
        core: false,
        repo: "storytold/photocraft",
        sample: false,
    },
    AppDef {
        id: "vectorcraft",
        name: "Vector",
        origin: "VectorCraft",
        office: "Illustrator",
        group: "Kreatív",
        desc: "Vektoros illusztráció",
        new_label: "Új rajz",
        letter: "V",
        color: [0xF0, 0x9A, 0x1A],
        exts: &["svg", "ai", "vectorcraft"],
        core: false,
        repo: "storytold/vectorcraft",
        sample: false,
    },
    AppDef {
        id: "lightcraft",
        name: "Darkroom",
        origin: "LightCraft",
        office: "Lightroom",
        group: "Kreatív",
        desc: "Fotókönyvtár és RAW-előhívás",
        new_label: "Könyvtár",
        letter: "Ft",
        color: [0x5B, 0x7C, 0xA8],
        exts: &["lightcraft"],
        core: false,
        repo: "storytold/lightcraft",
        sample: false,
    },
    AppDef {
        id: "filmcraft",
        name: "Video",
        origin: "FilmCraft",
        office: "Premiere Pro",
        group: "Kreatív",
        desc: "Videóvágás, színkorrekció és hang",
        new_label: "Új projekt",
        letter: "Vi",
        color: [0x8A, 0x5C, 0xD8],
        exts: &["filmcraft"],
        core: false,
        repo: "storytold/filmcraft",
        sample: false,
    },
    AppDef {
        id: "effectcraft",
        name: "Motion",
        origin: "EffectCraft",
        office: "After Effects",
        group: "Kreatív",
        desc: "Mozgógrafika és vizuális effektek",
        new_label: "Új kompozíció",
        letter: "E",
        color: [0xA8, 0x5C, 0xD0],
        exts: &["effectcraft"],
        core: false,
        repo: "storytold/effectcraft",
        sample: false,
    },
    AppDef {
        id: "soundcraft",
        name: "Audio",
        origin: "SoundCraft",
        office: "Audition",
        group: "Kreatív",
        desc: "Hangfelvétel és -szerkesztés",
        new_label: "Új felvétel",
        letter: "H",
        color: [0x14, 0xA8, 0xB8],
        exts: &["soundcraft"],
        core: false,
        repo: "storytold/soundcraft",
        sample: false,
    },
    AppDef {
        id: "anicraft",
        name: "Animation",
        origin: "AniCraft",
        office: "Animate",
        group: "Kreatív",
        desc: "2D vektoros animáció (FLA/XFL import)",
        new_label: "Új animáció",
        letter: "An",
        color: [0xE5, 0x5B, 0x8F],
        exts: &["anicraft", "fla", "xfl"],
        core: false,
        repo: "storytold/anicraft",
        sample: false,
    },
    AppDef {
        id: "figcraft",
        name: "Prototype",
        origin: "FigCraft",
        office: "Figma",
        group: "Tervezés",
        desc: "Felülettervezés és prototípusok",
        new_label: "Új terv",
        letter: "U",
        color: [0xC2, 0x4E, 0x9E],
        exts: &["figcraft", "fig"],
        core: false,
        repo: "storytold/figcraft",
        sample: false,
    },
    AppDef {
        id: "cadcraft",
        name: "CAD",
        origin: "CADCraft",
        office: "AutoCAD",
        group: "Tervezés",
        desc: "Számítógépes tervezés (2D/3D)",
        new_label: "Új rajz",
        letter: "C",
        color: [0x6B, 0x7A, 0x8F],
        exts: &["cadcraft", "dxf"],
        core: false,
        repo: "storytold/cadcraft",
        sample: false,
    },
    AppDef {
        id: "vormantis",
        name: "Vormantis",
        origin: "saját Fusion/SolidCraft fork",
        office: "Fusion / SolidWorks",
        group: "Tervezés",
        desc: "Saját parametrikus 3D CAD – Fusion / SolidCraft fork",
        new_label: "Új alkatrész",
        letter: "V",
        color: [0x2A, 0x9D, 0xE8],
        exts: &["vormantis"],
        core: false,
        repo: "",
        sample: false,
    },
    AppDef {
        id: "craft-anything",
        name: "Workshop",
        origin: "Craft Anything",
        office: "fejlesztői stúdió",
        group: "Tervezés",
        desc: "Weboldalak, appok és fájlok elemzése, majd saját projekt építése kódoló ügynökkel",
        new_label: "Új projekt",
        letter: "</>",
        color: [0x3B, 0x6E, 0xF0],
        exts: &[],
        core: false,
        repo: "storytold/craft-anything",
        sample: false,
    },
    AppDef {
        id: "materialcraft",
        name: "Material",
        origin: "MaterialCraft",
        office: "Substance Designer",
        group: "Tervezés",
        desc: "Procedurális anyagok csomópont-alapú szerkesztővel (SBS-import)",
        new_label: "Új anyag",
        letter: "M",
        color: [0x7A, 0x8B, 0x3A],
        exts: &["mcmat", "mcraft", "sbs"],
        core: false,
        repo: "storytold/materialcraft",
        sample: false,
    },
    AppDef {
        id: "texturecraft",
        name: "Texture",
        origin: "TextureCraft",
        office: "Substance Painter",
        group: "Tervezés",
        desc: "3D textúrafestés",
        new_label: "Új textúra",
        letter: "Tx",
        color: [0x9C, 0x6B, 0x3F],
        exts: &["texturecraft"],
        core: false,
        repo: "storytold/texturecraft",
        sample: false,
    },
];

/// A gépen talált, a katalógusban nem szereplő *craft appok (pl. egy új Craft alkalmazás).
static EXTRA: std::sync::Mutex<Vec<&'static AppDef>> = std::sync::Mutex::new(Vec::new());

/// Minden ismert app: a katalógus + a felismert ismeretlen *craft appok.
pub fn all() -> Vec<&'static AppDef> {
    let mut v: Vec<&'static AppDef> = APPS.iter().collect();
    if let Ok(e) = EXTRA.lock() {
        v.extend(e.iter().copied());
    }
    v
}

fn register_extra(id: &str) -> &'static AppDef {
    let mut e = EXTRA.lock().unwrap_or_else(|p| p.into_inner());
    if let Some(a) = e.iter().find(|a| a.id == id) {
        return a;
    }
    let leak = |s: String| -> &'static str { Box::leak(s.into_boxed_str()) };
    let base = id.trim_end_matches("craft");
    let mut cap = base.chars();
    let pretty = match cap.next() {
        Some(f) => f.to_uppercase().collect::<String>() + cap.as_str(),
        None => id.to_string(),
    };
    let def: &'static AppDef = Box::leak(Box::new(AppDef {
        id: leak(id.to_string()),
        name: leak(format!("{pretty}Craft")),
        origin: leak(format!("{pretty}Craft")),
        office: "Craft alkalmazás",
        group: "Egyéb",
        desc: "A gépen talált további Craft alkalmazás",
        new_label: "Új",
        letter: leak(pretty.chars().next().unwrap_or('?').to_uppercase().to_string()),
        color: [0x8A, 0x93, 0xA6],
        exts: &[],
        core: false,
        repo: leak(format!("storytold/{id}")),
        sample: false,
    }));
    e.push(def);
    def
}

pub fn app_by_id(id: &str) -> Option<&'static AppDef> {
    all().into_iter().find(|a| a.id == id)
}

pub fn ext_of(path: &Path) -> Option<String> {
    path.extension().map(|e| e.to_string_lossy().to_lowercase())
}

/// Melyik app nyitja meg ezt a fájlt? (az alapcsomag élvez elsőbbséget)
pub fn app_for_path(path: &Path) -> Option<&'static AppDef> {
    let ext = ext_of(path)?;
    APPS.iter().find(|a| a.exts.contains(&ext.as_str()))
}

#[derive(Debug, Clone)]
pub struct Installed {
    pub exe: PathBuf,
    pub dir: PathBuf,
    pub version: Option<String>,
}

pub fn exe_name(id: &str) -> String {
    if cfg!(windows) {
        format!("{id}.exe")
    } else {
        id.to_string()
    }
}

/// "gridcraft-0.19.1-windows-x64-portable" → "0.19.1"
pub fn version_from_dir_name(id: &str, dir_name: &str) -> Option<String> {
    let rest = dir_name.strip_prefix(id)?.strip_prefix('-')?;
    let v: String = rest
        .split('-')
        .next()?
        .trim_start_matches('v')
        .to_string();
    if v.chars().next()?.is_ascii_digit() {
        Some(v)
    } else {
        None
    }
}

pub fn parse_version(v: &str) -> Vec<u64> {
    v.trim_start_matches('v')
        .split(|c: char| !c.is_ascii_digit())
        .filter(|s| !s.is_empty())
        .map(|s| s.parse().unwrap_or(0))
        .collect()
}

pub fn version_newer(candidate: &str, current: &str) -> bool {
    parse_version(candidate) > parse_version(current)
}

/// Végignézi a gyökérmappákat, és minden apphoz a legmagasabb verziójú példányt adja vissza.
pub fn discover(roots: &[PathBuf]) -> HashMap<&'static str, Installed> {
    let mut found: HashMap<&'static str, Installed> = HashMap::new();
    let mut consider = |app: &'static AppDef, cand: Installed| {
        let better = match found.get(app.id) {
            None => true,
            Some(old) => match (&cand.version, &old.version) {
                (Some(n), Some(o)) => version_newer(n, o),
                (Some(_), None) => true,
                _ => false,
            },
        };
        if better {
            found.insert(app.id, cand);
        }
    };

    for root in roots {
        if !root.is_dir() {
            continue;
        }
        // Közvetlenül a gyökérben lévő exe
        for app in APPS {
            let exe = root.join(exe_name(app.id));
            if exe.is_file() {
                consider(app, Installed { exe, dir: root.clone(), version: None });
            }
        }
        let Ok(rd) = std::fs::read_dir(root) else { continue };
        for entry in rd.flatten() {
            let path = entry.path();
            if !path.is_dir() {
                continue;
            }
            if let Some((id, version, exe)) = read_marker(&path) {
                if let Some(app) = APPS.iter().find(|a| a.id == id) {
                    let exe = path.join(exe);
                    if exe.is_file() {
                        consider(app, Installed { exe, dir: path.clone(), version });
                    }
                }
                continue;
            }
            let name = entry.file_name().to_string_lossy().to_lowercase();
            // Más processzorra készült build (pl. ARM64 egy x64-es gépen) nem indulna el.
            if cfg!(target_arch = "x86_64") && (name.contains("-arm64") || name.contains("-aarch64")) {
                continue;
            }
            // Ismeretlen Craft app (pl. "newcraft-1.2.0-windows-x64-portable" + newcraft.exe)
            let prefix: String = name.chars().take_while(|c| c.is_ascii_alphanumeric()).collect();
            if prefix.len() > 5
                && prefix.ends_with("craft")
                && !name.starts_with("artcraft")
                // a SolidCraft helyett a saját Vormantis van a csomagban
                && !name.starts_with("solidcraft")
                && !APPS.iter().any(|a| a.id == prefix)
                && path.join(exe_name(&prefix)).is_file()
            {
                let app = register_extra(&prefix);
                consider(
                    app,
                    Installed {
                        exe: path.join(exe_name(&prefix)),
                        dir: path.clone(),
                        version: version_from_dir_name(&prefix, &name),
                    },
                );
            }
            for app in APPS {
                let norm: String = name.chars().filter(|c| c.is_ascii_alphanumeric()).collect();
                let id_norm: String = app.id.chars().filter(|c| c.is_ascii_alphanumeric()).collect();
                if name == app.id || name.starts_with(&format!("{}-", app.id)) || norm == id_norm {
                    let exe = path.join(exe_name(app.id));
                    if exe.is_file() {
                        consider(
                            app,
                            Installed {
                                exe,
                                dir: path.clone(),
                                version: version_from_dir_name(app.id, &name),
                            },
                        );
                    }
                }
            }
        }
    }
    found
}

#[cfg(windows)]
fn no_console(cmd: &mut Command) {
    use std::os::windows::process::CommandExt;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;
    cmd.creation_flags(CREATE_NO_WINDOW);
}
#[cfg(not(windows))]
fn no_console(_cmd: &mut Command) {}

pub fn hidden_command(program: impl AsRef<std::ffi::OsStr>) -> Command {
    let mut c = Command::new(program);
    no_console(&mut c);
    c
}

/// Elindít egy appot, opcionálisan egy fájllal vagy extra argumentumokkal.
pub fn launch(inst: &Installed, file: Option<&Path>, extra: &[&str]) -> std::io::Result<()> {
    let mut cmd = Command::new(&inst.exe);
    cmd.current_dir(&inst.dir);
    if let Some((k, v)) = crate::spell::env_for_child() {
        cmd.env(k, v);
    }
    let lang = crate::config::Config::load().app_lang;
    if !lang.is_empty() {
        cmd.env("CRAFTOFFICE_LANG", lang);
    }
    for a in extra {
        cmd.arg(a);
    }
    if let Some(f) = file {
        cmd.arg(f);
    }
    cmd.spawn().map(|_| ())
}

/// Mappa megnyitása / fájl kijelölése a Fájlkezelőben.
pub fn reveal(path: &Path) {
    #[cfg(windows)]
    {
        if path.is_file() {
            let _ = Command::new("explorer.exe")
                .arg(format!("/select,{}", path.display()))
                .spawn();
        } else {
            let _ = Command::new("explorer.exe").arg(path).spawn();
        }
    }
    #[cfg(not(windows))]
    {
        let dir = if path.is_file() { path.parent().unwrap_or(path) } else { path };
        let _ = Command::new("xdg-open").arg(dir).spawn();
    }
}

pub fn open_url(url: &str) {
    #[cfg(windows)]
    {
        let _ = hidden_command("cmd").args(["/C", "start", "", url]).spawn();
    }
    #[cfg(not(windows))]
    {
        let _ = Command::new("xdg-open").arg(url).spawn();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn versions() {
        assert_eq!(
            version_from_dir_name("gridcraft", "gridcraft-0.19.1-windows-x64-portable").as_deref(),
            Some("0.19.1")
        );
        assert_eq!(version_from_dir_name("gridcraft", "gridcraft"), None);
        assert!(version_newer("0.10.0", "0.9.5"));
        assert!(!version_newer("v0.8.0", "0.8.0"));
    }

    #[test]
    fn routing() {
        assert_eq!(app_for_path(Path::new("a/B.DOCX")).unwrap().id, "wordcraft");
        assert_eq!(app_for_path(Path::new("x.csv")).unwrap().id, "gridcraft");
        assert_eq!(app_for_path(Path::new("x.pptx")).unwrap().id, "deckcraft");
        assert_eq!(app_for_path(Path::new("x.idml")).unwrap().id, "designcraft");
        assert_eq!(app_for_path(Path::new("x.pdf")).unwrap().id, "pdfcraft");
        assert!(app_for_path(Path::new("x.zip")).is_none());
    }

    #[test]
    fn discovery() {
        let tmp = std::env::temp_dir().join(format!("co-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&tmp);
        for d in ["wordcraft-0.8.0-windows-x64-portable", "wordcraft-0.9.1-windows-x64-portable", "gridcraftx"] {
            std::fs::create_dir_all(tmp.join(d)).unwrap();
        }
        std::fs::write(tmp.join("wordcraft-0.8.0-windows-x64-portable").join(exe_name("wordcraft")), b"").unwrap();
        std::fs::write(tmp.join("wordcraft-0.9.1-windows-x64-portable").join(exe_name("wordcraft")), b"").unwrap();
        std::fs::write(tmp.join("gridcraftx").join(exe_name("gridcraft")), b"").unwrap();
        let f = discover(&[tmp.clone()]);
        assert_eq!(f["wordcraft"].version.as_deref(), Some("0.9.1"));
        assert!(!f.contains_key("gridcraft"));
        let _ = std::fs::remove_dir_all(&tmp);
    }
    #[test]
    fn rename_and_update() {
        let tmp = std::env::temp_dir().join(format!("co-mig-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&tmp);
        let old = tmp.join("wordcraft-0.18.1-windows-x64-portable");
        std::fs::create_dir_all(old.join("WordCraftData")).unwrap();
        std::fs::write(old.join(exe_name("wordcraft")), b"v1").unwrap();
        std::fs::write(old.join("WordCraftData").join("prefs"), b"mine").unwrap();
        std::fs::create_dir_all(tmp.join("Vormantis")).unwrap();
        std::fs::write(tmp.join("Vormantis").join(exe_name("vormantis")), b"x").unwrap();
        assert_eq!(migrate_names(&tmp), 1);
        let brand = tmp.join("CraftOffice Writer");
        let exe = if cfg!(windows) { "CraftOffice Writer.exe" } else { "CraftOffice Writer" };
        assert!(brand.join(exe).is_file());
        assert!(tmp.join("Vormantis").is_dir());
        let f = discover(&[tmp.clone()]);
        assert_eq!(f["wordcraft"].version.as_deref(), Some("0.18.1"));
        assert_eq!(f["wordcraft"].exe, brand.join(exe));
        // frissítés: új verzió a régi néven érkezik, összefésül, a beállítások maradnak
        let new = tmp.join("wordcraft-0.19.0-windows-x64-portable");
        std::fs::create_dir_all(&new).unwrap();
        std::fs::write(new.join(exe_name("wordcraft")), b"v2").unwrap();
        assert_eq!(migrate_names(&tmp), 1);
        assert_eq!(std::fs::read(brand.join(exe)).unwrap(), b"v2");
        assert_eq!(std::fs::read(brand.join("WordCraftData").join("prefs")).unwrap(), b"mine");
        assert_eq!(discover(&[tmp.clone()])["wordcraft"].version.as_deref(), Some("0.19.0"));
        assert!(!new.exists());
        let _ = std::fs::remove_dir_all(&tmp);
    }

}

/// A gépen talált appok, a felhasználó által megadott exe-helyekkel kiegészítve.
pub fn discover_cfg(cfg: &crate::config::Config) -> HashMap<&'static str, Installed> {
    let mut found = discover(&cfg.roots());
    for (id, exe) in &cfg.exe_overrides {
        let exe = PathBuf::from(exe);
        if let (Some(app), true) = (app_by_id(id), exe.is_file()) {
            let dir = exe.parent().map(Path::to_path_buf).unwrap_or_default();
            found.insert(app.id, Installed { exe, dir, version: None });
        }
    }
    found
}

/// Az app saját ikonja a mappájában (pl. Vormantis: icon-512.png), ha van.
pub fn own_icon(inst: &Installed) -> Option<PathBuf> {
    ["icon-512.png", "icon-256.png", "icon.png"].iter().map(|n| inst.dir.join(n)).find(|p| p.is_file())
}

/// A CraftOffice-név, ami a mappa- és exe-név lesz (pl. "CraftOffice Writer").
/// A saját appok (Vormantis) és az ismeretlen Craft appok nem kapnak új nevet.
pub fn brand_name(app: &AppDef) -> Option<String> {
    if app.repo.is_empty() || app.group == "Egyéb" {
        return None;
    }
    Some(format!("CraftOffice {}", app.name))
}

const MARKER: &str = "craftoffice.json";

/// Átnevezett app-mappa jelölője: melyik app, melyik verzió, mi az exe neve.
fn read_marker(dir: &Path) -> Option<(String, Option<String>, String)> {
    let v: serde_json::Value = serde_json::from_str(&std::fs::read_to_string(dir.join(MARKER)).ok()?).ok()?;
    Some((
        v["id"].as_str()?.to_string(),
        v["version"].as_str().map(str::to_string),
        v["exe"].as_str()?.to_string(),
    ))
}

fn write_marker(dir: &Path, id: &str, version: Option<&str>, exe: &str) {
    let v = serde_json::json!({ "id": id, "version": version, "exe": exe });
    let _ = std::fs::write(dir.join(MARKER), serde_json::to_string_pretty(&v).unwrap_or_default());
}

/// Fájlok áthelyezése `from`-ból `to`-ba (felülírva), majd `from` törlése.
fn merge_move(from: &Path, to: &Path) -> std::io::Result<()> {
    std::fs::create_dir_all(to)?;
    for e in std::fs::read_dir(from)?.flatten() {
        let dst = to.join(e.file_name());
        if e.path().is_dir() {
            merge_move(&e.path(), &dst)?;
        } else {
            if dst.exists() {
                std::fs::remove_file(&dst)?;
            }
            std::fs::rename(e.path(), &dst)?;
        }
    }
    std::fs::remove_dir_all(from)
}

/// A `root` (CraftOffice\apps) alatti eredeti nevű app-mappák átnevezése CraftOffice-névre:
/// `wordcraft-0.18.1-windows-x64-portable\wordcraft.exe` → `CraftOffice Writer\CraftOffice Writer.exe`.
/// Frissítésnél (már van ilyen nevű mappa) az új fájlok a meglévő mappába kerülnek, így a
/// hordozható beállítások (pl. PdfCraftData) megmaradnak. Visszaadja az átnevezett appok számát.
pub fn migrate_names(root: &Path) -> usize {
    let Ok(rd) = std::fs::read_dir(root) else { return 0 };
    let mut done = 0;
    for e in rd.flatten() {
        let dir = e.path();
        if !dir.is_dir() || dir.join(MARKER).is_file() {
            continue;
        }
        let name = e.file_name().to_string_lossy().to_lowercase();
        let Some(app) = APPS.iter().find(|a| name == a.id || name.starts_with(&format!("{}-", a.id))) else { continue };
        let Some(brand) = brand_name(app) else { continue };
        let old_exe = dir.join(exe_name(app.id));
        if !old_exe.is_file() {
            continue;
        }
        let version = version_from_dir_name(app.id, &name);
        let target = root.join(&brand);
        let new_exe_name = if cfg!(windows) { format!("{brand}.exe") } else { brand.clone() };
        // az exe átnevezése a régi mappában, utána a mappa (vagy összefésülés a meglévővel)
        if std::fs::rename(&old_exe, dir.join(&new_exe_name)).is_err() {
            continue; // fut az app: majd legközelebb
        }
        let moved = if target.exists() { merge_move(&dir, &target).is_ok() } else { std::fs::rename(&dir, &target).is_ok() };
        if moved {
            write_marker(&target, app.id, version.as_deref(), &new_exe_name);
            done += 1;
        } else {
            let _ = std::fs::rename(dir.join(&new_exe_name), &old_exe);
        }
    }
    done
}

/// Az „internetről letöltött” jelölés (Zone.Identifier) levétele az `apps` mappa programjairól,
/// ugyanaz, mint a Tulajdonságok › „Tiltás feloldása” / PowerShell `Unblock-File`.
/// A CraftOffice-ba másolt saját fordítású appok így nem akadnak meg a SmartScreen-figyelmeztetésen.
pub fn unblock_tree(root: &Path) -> usize {
    fn walk(dir: &Path, depth: usize, n: &mut usize) {
        if depth > 3 {
            return;
        }
        let Ok(rd) = std::fs::read_dir(dir) else { return };
        for e in rd.flatten() {
            let p = e.path();
            if p.is_dir() {
                walk(&p, depth + 1, n);
            } else if cfg!(windows) {
                let l = p.to_string_lossy().to_lowercase();
                if l.ends_with(".exe") || l.ends_with(".dll") {
                    let ads = format!("{}:Zone.Identifier", p.display());
                    if std::fs::remove_file(&ads).is_ok() {
                        *n += 1;
                    }
                }
            }
        }
    }
    // csak a CraftOffice által kezelt app-mappák (jelölő vagy Craft-név); más (pl. Vormantis) érintetlen
    let mut n = 0;
    let Ok(rd) = std::fs::read_dir(root) else { return 0 };
    for e in rd.flatten() {
        let p = e.path();
        let name = e.file_name().to_string_lossy().to_lowercase();
        let managed = p.join(MARKER).is_file() || APPS.iter().any(|a| !a.repo.is_empty() && (name == a.id || name.starts_with(&format!("{}-", a.id))));
        if p.is_dir() && managed {
            walk(&p, 1, &mut n);
        }
    }
    n
}
