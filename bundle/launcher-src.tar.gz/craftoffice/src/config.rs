//! Beállítások és a legutóbbi fájlok listája (JSON). Hordozható módban a program mellett tárolódik.

use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub enum Theme {
    #[default]
    System,
    Light,
    Dark,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecentEntry {
    pub path: String,
    pub app_id: String,
    /// Unix időbélyeg (mp)
    pub opened: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct Config {
    pub theme: Theme,
    /// Felhasználó által hozzáadott alkalmazásmappák
    pub extra_roots: Vec<String>,
    /// Ide telepíti a letöltött appokat (üres = <program>\apps)
    pub download_dir: String,
    /// Ezekben a mappákban keres dokumentumokat
    pub scan_dirs: Vec<String>,
    pub recent: Vec<RecentEntry>,
    pub pinned: Vec<String>,
    pub check_updates_on_start: bool,
    pub show_extras: bool,
    /// Kézzel megadott exe-helyek app-azonosító szerint
    pub exe_overrides: std::collections::BTreeMap<String, String>,
    /// Az appok felületi nyelve: "" = rendszer, "hu", "ro", "en"
    pub app_lang: String,
}

impl Default for Config {
    fn default() -> Self {
        let mut scan_dirs = Vec::new();
        if let Some(home) = home_dir() {
            for d in ["Documents", "Desktop", "Downloads", "OneDrive\\Documents"] {
                let p = home.join(d);
                if p.is_dir() {
                    scan_dirs.push(p.display().to_string());
                }
            }
        }
        Self {
            theme: Theme::System,
            extra_roots: Vec::new(),
            download_dir: String::new(),
            scan_dirs,
            recent: Vec::new(),
            pinned: Vec::new(),
            check_updates_on_start: true,
            show_extras: true,
            exe_overrides: Default::default(),
            app_lang: String::new(),
        }
    }
}

pub fn home_dir() -> Option<PathBuf> {
    std::env::var_os("USERPROFILE")
        .or_else(|| std::env::var_os("HOME"))
        .map(PathBuf::from)
}

pub fn exe_dir() -> PathBuf {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(Path::to_path_buf))
        .unwrap_or_else(|| PathBuf::from("."))
}

/// Hordozható mód: <program>\CraftOfficeData, ha írható; különben %APPDATA%\CraftOffice.
pub fn data_dir() -> PathBuf {
    let portable = exe_dir().join("CraftOfficeData");
    if std::fs::create_dir_all(&portable).is_ok() {
        let probe = portable.join(".write-test");
        if std::fs::write(&probe, b"ok").is_ok() {
            let _ = std::fs::remove_file(probe);
            return portable;
        }
    }
    let base = std::env::var_os("APPDATA")
        .map(PathBuf::from)
        .or_else(|| home_dir().map(|h| h.join(".config")))
        .unwrap_or_else(|| PathBuf::from("."));
    let d = base.join("CraftOffice");
    let _ = std::fs::create_dir_all(&d);
    d
}

impl Config {
    pub fn path() -> PathBuf {
        data_dir().join("config.json")
    }

    pub fn load() -> Self {
        std::fs::read_to_string(Self::path())
            .ok()
            .and_then(|s| serde_json::from_str(&s).ok())
            .unwrap_or_default()
    }

    pub fn save(&self) {
        if let Ok(s) = serde_json::to_string_pretty(self) {
            let p = Self::path();
            let tmp = p.with_extension("json.tmp");
            if std::fs::write(&tmp, s).is_ok() {
                let _ = std::fs::rename(tmp, p);
            }
        }
    }

    pub fn download_dir(&self) -> PathBuf {
        if self.download_dir.trim().is_empty() {
            exe_dir().join("apps")
        } else {
            PathBuf::from(self.download_dir.trim())
        }
    }

    /// Ahol appokat keresünk: <program>\apps, a program mappája, annak szülője, a letöltési mappa és a saját mappák.
    pub fn roots(&self) -> Vec<PathBuf> {
        let exe = exe_dir();
        let mut v = vec![exe.join("apps"), exe.clone()];
        if let Some(parent) = exe.parent() {
            v.push(parent.to_path_buf());
        }
        v.push(self.download_dir());
        // MSI-vel telepített Craft appok (pl. C:\Program Files\ArtCraft\artcraft.exe)
        for var in ["ProgramFiles", "ProgramW6432", "LOCALAPPDATA"] {
            if let Some(p) = std::env::var_os(var) {
                let p = PathBuf::from(p);
                v.push(if var == "LOCALAPPDATA" { p.join("Programs") } else { p });
            }
        }
        v.extend(self.extra_roots.iter().map(PathBuf::from));
        let mut out: Vec<PathBuf> = Vec::new();
        for p in v {
            if !out.contains(&p) {
                out.push(p);
            }
        }
        out
    }

    pub fn push_recent(&mut self, path: &Path, app_id: &str) {
        let s = path.display().to_string();
        self.recent.retain(|r| !r.path.eq_ignore_ascii_case(&s));
        self.recent.insert(
            0,
            RecentEntry {
                path: s,
                app_id: app_id.to_string(),
                opened: chrono::Local::now().timestamp(),
            },
        );
        self.recent.truncate(100);
    }

    pub fn is_pinned(&self, path: &str) -> bool {
        self.pinned.iter().any(|p| p.eq_ignore_ascii_case(path))
    }

    pub fn toggle_pin(&mut self, path: &str) {
        if self.is_pinned(path) {
            self.pinned.retain(|p| !p.eq_ignore_ascii_case(path));
        } else {
            self.pinned.insert(0, path.to_string());
        }
    }
}
