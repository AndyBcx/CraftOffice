//! Appok letöltése / frissítése a GitHub-kiadásokból.
//! A Windows beépített `curl.exe` és `tar.exe` eszközeit használja; ha a curl nem működik,
//! PowerShell-lel próbálkozik. Minden lépés naplózódik: CraftOfficeData\letoltes.log

use crate::apps::{exe_name, hidden_command, AppDef};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::mpsc::Sender;

#[derive(Debug)]
pub enum Msg {
    Status(&'static str, String),
    Installed(&'static str, String),
    Failed(&'static str, String),
    Latest(&'static str, String),
}

const UA: &str = "CraftOffice-Launcher";

pub fn log_path() -> PathBuf {
    crate::config::data_dir().join("letoltes.log")
}

fn log(line: &str) {
    if let Ok(mut f) = std::fs::OpenOptions::new().create(true).append(true).open(log_path()) {
        let _ = writeln!(f, "[{}] {line}", chrono::Local::now().format("%Y-%m-%d %H:%M:%S"));
    }
}

fn curl() -> &'static str {
    if cfg!(windows) {
        "curl.exe"
    } else {
        "curl"
    }
}

fn tar() -> &'static str {
    if cfg!(windows) {
        "tar.exe"
    } else {
        "bsdtar"
    }
}

/// HTTP GET: először curl (visszavonás-ellenőrzés „best effort” módban, mert vírusirtók/proxyk
/// mellett a Windows curl gyakran CRYPT_E_NO_REVOCATION_CHECK hibával áll le), majd PowerShell.
/// `out` = Some(fájl) esetén oda ment, különben a törzset adja vissza.
fn http_get(url: &str, out: Option<&Path>, accept_json: bool) -> Result<Vec<u8>, String> {
    let mut errors = Vec::new();
    for revoke_flag in [true, false] {
        let mut c = hidden_command(curl());
        c.args(["-sSL", "--fail", "--retry", "2", "--connect-timeout", "20", "-A", UA]);
        if revoke_flag && cfg!(windows) {
            c.arg("--ssl-revoke-best-effort");
        }
        if accept_json {
            c.args(["-H", "Accept: application/vnd.github+json"]);
        }
        if let Some(o) = out {
            c.arg("-o").arg(o);
        }
        c.arg(url);
        match c.output() {
            Ok(o) if o.status.success() => return Ok(o.stdout),
            Ok(o) => {
                let e = format!(
                    "curl{} kilépési kód {:?}: {}",
                    if revoke_flag { " (--ssl-revoke-best-effort)" } else { "" },
                    o.status.code(),
                    String::from_utf8_lossy(&o.stderr).trim()
                );
                log(&format!("  {url}: {e}"));
                errors.push(e);
            }
            Err(e) => {
                let e = format!("curl nem indítható: {e}");
                log(&format!("  {e}"));
                errors.push(e);
                break;
            }
        }
    }
    // Tartalék: PowerShell (Invoke-WebRequest)
    if cfg!(windows) {
        let esc = |s: &str| s.replace('\'', "''");
        let script = match out {
            Some(o) => format!(
                "$ProgressPreference='SilentlyContinue';[Net.ServicePointManager]::SecurityProtocol='Tls12';\
                 Invoke-WebRequest -UseBasicParsing -UserAgent '{UA}' -Uri '{}' -OutFile '{}'",
                esc(url),
                esc(&o.display().to_string())
            ),
            None => format!(
                "$ProgressPreference='SilentlyContinue';[Net.ServicePointManager]::SecurityProtocol='Tls12';\
                 [Console]::OutputEncoding=[Text.Encoding]::UTF8;\
                 (Invoke-WebRequest -UseBasicParsing -UserAgent '{UA}' -Uri '{}').Content",
                esc(url)
            ),
        };
        match hidden_command("powershell.exe")
            .args(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", &script])
            .output()
        {
            Ok(o) if o.status.success() => {
                log(&format!("  {url}: PowerShell-lel sikerült"));
                return Ok(o.stdout);
            }
            Ok(o) => {
                let e = format!("PowerShell: {}", String::from_utf8_lossy(&o.stderr).trim());
                log(&format!("  {url}: {e}"));
                errors.push(e);
            }
            Err(e) => errors.push(format!("PowerShell nem indítható: {e}")),
        }
    }
    Err(errors.last().cloned().unwrap_or_else(|| "ismeretlen hálózati hiba".into()))
}

struct Release {
    tag: String,
    asset_name: String,
    url: String,
}

fn is_win_asset(name: &str) -> bool {
    let n = name.to_lowercase();
    n.ends_with(".zip") && n.contains("windows") && (n.contains("x64") || n.contains("x86_64")) && n.contains("portable")
}

/// Az API-ból: a legfrissebb (elő)kiadás, amelyben van Windows x64 hordozható zip.
fn release_from_api(app: &AppDef) -> Result<Release, String> {
    let api = format!("https://api.github.com/repos/{}/releases?per_page=15", app.repo);
    let body = http_get(&api, None, true)?;
    let v: serde_json::Value =
        serde_json::from_slice(&body).map_err(|e| format!("Hibás GitHub-válasz: {e}"))?;
    let list = v.as_array().ok_or_else(|| {
        format!("Váratlan GitHub-válasz: {}", v["message"].as_str().unwrap_or("?"))
    })?;
    for rel in list {
        if rel["draft"].as_bool().unwrap_or(false) {
            continue;
        }
        if let Some(asset) = rel["assets"]
            .as_array()
            .and_then(|a| a.iter().find(|x| x["name"].as_str().is_some_and(is_win_asset)))
        {
            return Ok(Release {
                tag: rel["tag_name"].as_str().unwrap_or("").trim_start_matches('v').to_string(),
                asset_name: asset["name"].as_str().unwrap_or_default().to_string(),
                url: asset["browser_download_url"].as_str().unwrap_or_default().to_string(),
            });
        }
    }
    Err("A kiadásokban nincs Windows x64 hordozható csomag".into())
}

/// Tartalék API nélkül (pl. ha a GitHub API lekérési korlátja betelt):
/// a /releases/latest átirányításából kiolvassa a verziót, és a szokásos fájlnevet tölti le.
fn release_from_redirect(app: &AppDef) -> Result<Release, String> {
    let url = format!("https://github.com/{}/releases/latest", app.repo);
    let mut c = hidden_command(curl());
    c.args(["-sSI", "-A", UA, "-o", if cfg!(windows) { "NUL" } else { "/dev/null" }, "-w", "%{redirect_url}"]);
    if cfg!(windows) {
        c.arg("--ssl-revoke-best-effort");
    }
    let o = c.arg(&url).output().map_err(|e| e.to_string())?;
    let loc = String::from_utf8_lossy(&o.stdout).trim().to_string();
    let tag = loc
        .rsplit("/tag/")
        .next()
        .filter(|t| !t.is_empty() && loc.contains("/tag/"))
        .ok_or_else(|| format!("Nem sikerült a legfrissebb verziót megállapítani ({})", String::from_utf8_lossy(&o.stderr).trim()))?
        .to_string();
    let ver = tag.trim_start_matches('v').to_string();
    let asset_name = format!("{}-{}-windows-x64-portable.zip", app.id, ver);
    Ok(Release {
        url: format!("https://github.com/{}/releases/download/{}/{}", app.repo, tag, asset_name),
        tag: ver,
        asset_name,
    })
}

fn latest_release(app: &AppDef) -> Result<Release, String> {
    match release_from_api(app) {
        Ok(r) => Ok(r),
        Err(e) => {
            log(&format!("{}: API-hiba: {e} – tartalék útvonal", app.name));
            release_from_redirect(app).map_err(|e2| format!("{e} / {e2}"))
        }
    }
}

/// Legfrissebb verzió lekérdezése (háttérszálon).
pub fn spawn_check(app: &'static AppDef, tx: Sender<Msg>, ctx: egui::Context) {
    std::thread::spawn(move || {
        if let Ok(r) = latest_release(app) {
            let _ = tx.send(Msg::Latest(app.id, r.tag));
            ctx.request_repaint();
        }
    });
}

/// Letöltés és kicsomagolás a `dest` mappába (háttérszálon).
pub fn spawn_install(app: &'static AppDef, dest: PathBuf, tx: Sender<Msg>, ctx: egui::Context) {
    std::thread::spawn(move || {
        let send = |m: Msg| {
            let _ = tx.send(m);
            ctx.request_repaint();
        };
        log(&format!("=== {} telepítése ide: {}", app.name, dest.display()));
        match install(app, &dest, &|s| send(Msg::Status(app.id, s.to_string()))) {
            Ok(v) => {
                log(&format!("{} v{v} kész", app.name));
                send(Msg::Installed(app.id, v))
            }
            Err(e) => {
                log(&format!("{} HIBA: {e}", app.name));
                send(Msg::Failed(app.id, e))
            }
        }
    });
}

fn install(app: &AppDef, dest: &Path, status: &dyn Fn(&str)) -> Result<String, String> {
    status("Kiadás keresése…");
    let rel = latest_release(app)?;
    log(&format!("{}: v{} – {}", app.name, rel.tag, rel.url));
    std::fs::create_dir_all(dest).map_err(|e| format!("A mappa nem hozható létre ({}): {e}", dest.display()))?;
    let zip = dest.join(&rel.asset_name);
    status(&format!("Letöltés: v{}…", rel.tag));
    if let Err(e) = http_get(&rel.url, Some(&zip), false) {
        let _ = std::fs::remove_file(&zip);
        return Err(format!("A letöltés nem sikerült: {e}"));
    }
    let size = std::fs::metadata(&zip).map(|m| m.len()).unwrap_or(0);
    log(&format!("  letöltve: {size} bájt"));
    if size < 100_000 {
        let _ = std::fs::remove_file(&zip);
        return Err(format!("A letöltött fájl túl kicsi ({size} bájt) – valószínűleg hibaoldal"));
    }
    status("Kicsomagolás…");
    let tmp = dest.join(format!("_kicsomagolas_{}", app.id));
    let _ = std::fs::remove_dir_all(&tmp);
    std::fs::create_dir_all(&tmp).map_err(|e| e.to_string())?;
    let out = hidden_command(tar())
        .arg("-xf")
        .arg(&zip)
        .arg("-C")
        .arg(&tmp)
        .output();
    let ok = match &out {
        Ok(o) if o.status.success() => true,
        Ok(o) => {
            log(&format!("  tar: {}", String::from_utf8_lossy(&o.stderr).trim()));
            false
        }
        Err(e) => {
            log(&format!("  tar nem indítható: {e}"));
            false
        }
    };
    if !ok && cfg!(windows) {
        // tartalék: PowerShell Expand-Archive
        let script = format!(
            "Expand-Archive -Force -LiteralPath '{}' -DestinationPath '{}'",
            zip.display().to_string().replace('\'', "''"),
            tmp.display().to_string().replace('\'', "''")
        );
        let st = hidden_command("powershell.exe")
            .args(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", &script])
            .status();
        if !st.map(|s| s.success()).unwrap_or(false) {
            let _ = std::fs::remove_dir_all(&tmp);
            return Err("A kicsomagolás nem sikerült (zip megmaradt a mappában)".into());
        }
    } else if !ok {
        let _ = std::fs::remove_dir_all(&tmp);
        return Err("A kicsomagolás nem sikerült".into());
    }
    let _ = std::fs::remove_file(&zip);
    let exe_dir = find_exe_dir(&tmp, &exe_name(app.id), 0)
        .ok_or_else(|| format!("A csomagban nincs {}", exe_name(app.id)))?;
    let stem = rel.asset_name.trim_end_matches(".zip");
    let final_dir = dest.join(stem);
    let _ = std::fs::remove_dir_all(&final_dir);
    std::fs::rename(&exe_dir, &final_dir).map_err(|e| format!("Áthelyezés: {e}"))?;
    let _ = std::fs::remove_dir_all(&tmp);
    Ok(rel.tag)
}

fn find_exe_dir(dir: &Path, exe: &str, depth: usize) -> Option<PathBuf> {
    if dir.join(exe).is_file() {
        return Some(dir.to_path_buf());
    }
    if depth >= 3 {
        return None;
    }
    for e in std::fs::read_dir(dir).ok()?.flatten() {
        if e.path().is_dir() {
            if let Some(p) = find_exe_dir(&e.path(), exe, depth + 1) {
                return Some(p);
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    #[test]
    fn asset_names() {
        assert!(super::is_win_asset("deckcraft-0.18.1-windows-x64-portable.zip"));
        assert!(!super::is_win_asset("deckcraft-0.18.1-windows-arm64-portable.zip"));
        assert!(!super::is_win_asset("deckcraft-0.18.1-windows-x64.msi"));
    }
}
