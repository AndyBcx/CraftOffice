//! Dokumentumok keresése a felhasználó mappáiban (háttérszálon).

use crate::apps::{app_for_path, APPS};
use std::path::{Path, PathBuf};
use std::time::SystemTime;

#[derive(Debug, Clone)]
pub struct FileItem {
    pub path: PathBuf,
    pub modified: SystemTime,
    pub app_id: &'static str,
}

const SKIP_DIRS: &[&str] = &[
    "node_modules", "target", ".git", "appdata", "$recycle.bin", "system volume information",
    "__pycache__", ".cache", "build", "dist",
];

pub fn scan(dirs: &[String], core_only: bool) -> Vec<FileItem> {
    let mut out = Vec::new();
    let mut budget = 40_000usize; // ennyi bejegyzést nézünk meg legfeljebb
    for d in dirs {
        walk(Path::new(d), 0, &mut out, &mut budget, core_only);
    }
    out.sort_by(|a, b| b.modified.cmp(&a.modified));
    out.dedup_by(|a, b| a.path == b.path);
    out.truncate(300);
    out
}

fn walk(dir: &Path, depth: usize, out: &mut Vec<FileItem>, budget: &mut usize, core_only: bool) {
    if depth > 4 || *budget == 0 {
        return;
    }
    let Ok(rd) = std::fs::read_dir(dir) else { return };
    for e in rd.flatten() {
        if *budget == 0 {
            return;
        }
        *budget -= 1;
        let name = e.file_name().to_string_lossy().to_lowercase();
        if name.starts_with('.') || name.starts_with("~$") {
            continue;
        }
        let Ok(ft) = e.file_type() else { continue };
        let path = e.path();
        if ft.is_dir() {
            if !SKIP_DIRS.contains(&name.as_str()) {
                walk(&path, depth + 1, out, budget, core_only);
            }
        } else if ft.is_file() {
            if let Some(app) = app_for_path(&path) {
                if core_only && !app.core {
                    continue;
                }
                // a .txt/.md/.html túl gyakori — csak a valódi irodai formátumokat listázzuk
                if matches!(
                    crate::apps::ext_of(&path).as_deref(),
                    Some("txt" | "md" | "markdown" | "htm" | "html" | "tex" | "svg" | "csv" | "tsv")
                ) {
                    continue;
                }
                let modified = e
                    .metadata()
                    .and_then(|m| m.modified())
                    .unwrap_or(SystemTime::UNIX_EPOCH);
                out.push(FileItem { path, modified, app_id: app.id });
            }
        }
    }
}

#[allow(dead_code)]
pub fn known_exts() -> Vec<&'static str> {
    APPS.iter().flat_map(|a| a.exts.iter().copied()).collect()
}
