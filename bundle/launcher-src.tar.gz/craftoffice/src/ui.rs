//! A CraftOffice kezdőfelülete (Office-szerű „Kezdőlap”).

use crate::apps::{self, app_by_id, app_for_path, AppDef, Installed, GROUPS};
use crate::config::{exe_dir, Config, Theme};
use crate::download::{self, Msg};
use crate::scan::{self, FileItem};
use crate::system;
use egui::{
    pos2, vec2, Align, Align2, Color32, CornerRadius, FontFamily, FontId, Frame, Layout, Margin,
    Rect, RichText, Sense, Stroke, StrokeKind, Ui,
};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::time::SystemTime;

#[derive(Clone, Copy, PartialEq, Eq)]
enum Page {
    Home,
    New,
    Open,
    Apps,
    Settings,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum FileTab {
    Recent,
    Pinned,
    Computer,
}

struct Toast {
    text: String,
    error: bool,
    until: f64,
}

pub struct OfficeApp {
    cfg: Config,
    installed: HashMap<&'static str, Installed>,
    page: Page,
    tab: FileTab,
    search: String,
    scanned: Vec<FileItem>,
    scan_rx: Option<Receiver<Vec<FileItem>>>,
    tx: Sender<Msg>,
    rx: Receiver<Msg>,
    busy: HashMap<&'static str, String>,
    latest: HashMap<&'static str, String>,
    errors: HashMap<&'static str, String>,
    textures: HashMap<&'static str, egui::TextureHandle>,
    toast: Option<Toast>,
    pending_toast: Option<(String, bool)>,
    new_root: String,
    new_scan: String,
    ctx: egui::Context,
}

fn rgb(c: [u8; 3]) -> Color32 {
    Color32::from_rgb(c[0], c[1], c[2])
}

struct Pal {
    bg: Color32,
    card: Color32,
    card_hover: Color32,
    border: Color32,
    text: Color32,
    sub: Color32,
    rail: Color32,
    rail_text: Color32,
    rail_sel: Color32,
    accent: Color32,
    on_accent: Color32,
}

/// CraftOffice arculat: sötétkék + arany.
pub const NAVY: Color32 = Color32::from_rgb(0x14, 0x21, 0x3D);
pub const NAVY_2: Color32 = Color32::from_rgb(0x1F, 0x33, 0x5C);
pub const GOLD: Color32 = Color32::from_rgb(0xD4, 0xA5, 0x37);
pub const GOLD_LIGHT: Color32 = Color32::from_rgb(0xF0, 0xC9, 0x6A);

fn pal(ui: &Ui) -> Pal {
    if ui.visuals().dark_mode {
        Pal {
            bg: Color32::from_rgb(0x10, 0x16, 0x26),
            card: Color32::from_rgb(0x19, 0x22, 0x38),
            card_hover: Color32::from_rgb(0x22, 0x2D, 0x48),
            border: Color32::from_rgb(0x2A, 0x36, 0x52),
            text: Color32::from_rgb(0xEC, 0xEE, 0xF4),
            sub: Color32::from_rgb(0x9E, 0xA8, 0xBE),
            rail: Color32::from_rgb(0x0B, 0x12, 0x22),
            rail_text: Color32::from_rgb(0xE8, 0xEB, 0xF3),
            rail_sel: Color32::from_rgba_unmultiplied(0xD4, 0xA5, 0x37, 40),
            accent: GOLD,
            on_accent: NAVY,
        }
    } else {
        Pal {
            bg: Color32::from_rgb(0xF6, 0xF4, 0xEE),
            card: Color32::WHITE,
            card_hover: Color32::from_rgb(0xEF, 0xEB, 0xDF),
            border: Color32::from_rgb(0xE2, 0xDC, 0xCB),
            text: Color32::from_rgb(0x14, 0x21, 0x3D),
            sub: Color32::from_rgb(0x5E, 0x67, 0x7C),
            rail: NAVY,
            rail_text: Color32::from_rgb(0xF2, 0xF4, 0xFA),
            rail_sel: Color32::from_rgba_unmultiplied(0xD4, 0xA5, 0x37, 48),
            accent: NAVY_2,
            on_accent: Color32::WHITE,
        }
    }
}

fn bold(size: f32) -> FontId {
    FontId::new(size, FontFamily::Name("bold".into()))
}

/// App-ikon a CraftOffice arculatában: sötétkék alapra hangolt app-szín, arany piktogram,
/// alul app-színű csík. Ha az appnak saját ikonja van (`tex`), azt rajzolja.
pub fn paint_app_icon_tex(painter: &egui::Painter, rect: Rect, app: &AppDef, faded: bool, tex: Option<egui::TextureId>) {
    if let Some(t) = tex {
        let tint = if faded { Color32::from_white_alpha(110) } else { Color32::WHITE };
        painter.image(t, rect, Rect::from_min_max(pos2(0.0, 0.0), pos2(1.0, 1.0)), tint);
        return;
    }
    paint_app_icon(painter, rect, app, faded);
}

pub fn paint_app_icon(painter: &egui::Painter, rect: Rect, app: &AppDef, faded: bool) {
    let c = rgb(app.color);
    let mix = |a: u8, b: u8| ((a as f32) * 0.42 + (b as f32) * 0.58) as u8;
    let mut fill = Color32::from_rgb(mix(c.r(), NAVY.r()), mix(c.g(), NAVY.g()), mix(c.b(), NAVY.b()));
    let mut gold = GOLD_LIGHT;
    let mut band = c;
    if faded {
        fill = fill.gamma_multiply(0.38);
        gold = gold.gamma_multiply(0.55);
        band = band.gamma_multiply(0.4);
    }
    let r = (rect.width() * 0.22) as u8;
    painter.rect_filled(rect, CornerRadius::same(r), fill);
    let bh = (rect.height() * 0.09).max(2.0);
    painter.rect_filled(
        Rect::from_min_max(pos2(rect.left(), rect.bottom() - bh), rect.max),
        CornerRadius { nw: 0, ne: 0, sw: r, se: r },
        band,
    );
    let inner = Rect::from_center_size(pos2(rect.center().x, rect.center().y - bh * 0.35), rect.size() * 0.70);
    paint_glyph(painter, inner, app.id, gold, fill);
}

/// Vonalas piktogramok egy 24×24-es rácson (betű helyett).
pub fn paint_glyph(painter: &egui::Painter, r: Rect, kind: &str, col: Color32, bg: Color32) {
    let u = r.width() / 24.0;
    let p = |x: f32, y: f32| pos2(r.left() + x * u, r.top() + y * u);
    let w = (u * 1.7).max(1.0);
    let s = Stroke::new(w, col);
    let thin = Stroke::new((u * 1.2).max(0.8), col);
    let line = |pts: &[(f32, f32)], st: Stroke| {
        painter.add(egui::Shape::line(pts.iter().map(|&(x, y)| p(x, y)).collect(), st));
    };
    let closed = |pts: &[(f32, f32)], st: Stroke| {
        painter.add(egui::Shape::closed_line(pts.iter().map(|&(x, y)| p(x, y)).collect(), st));
    };
    let rect = |x0: f32, y0: f32, x1: f32, y1: f32| Rect::from_min_max(p(x0, y0), p(x1, y1));
    let rad = |v: f32| (v * u) as u8;
    match kind {
        "wordcraft" => {
            painter.rect_stroke(rect(5.5, 2.5, 18.5, 21.5), rad(1.5), s, StrokeKind::Middle);
            for (y, x1) in [(7.5, 15.5), (10.5, 15.5), (13.5, 15.5), (16.5, 12.5)] {
                line(&[(8.5, y), (x1, y)], thin);
            }
        }
        "gridcraft" => {
            painter.rect_filled(rect(3.5, 4.5, 20.5, 9.0), rad(1.0), col.gamma_multiply(0.35));
            painter.rect_stroke(rect(3.5, 4.5, 20.5, 19.5), rad(1.5), s, StrokeKind::Middle);
            for x in [9.2, 14.8] {
                line(&[(x, 4.5), (x, 19.5)], thin);
            }
            for y in [9.0, 14.25] {
                line(&[(3.5, y), (20.5, y)], thin);
            }
        }
        "deckcraft" => {
            painter.rect_stroke(rect(3.0, 3.5, 21.0, 15.0), rad(1.0), s, StrokeKind::Middle);
            line(&[(12.0, 15.0), (12.0, 18.0)], s);
            line(&[(8.0, 21.0), (12.0, 18.0), (16.0, 21.0)], s);
            for (x, h) in [(8.0, 3.0), (11.0, 5.0), (14.0, 7.0)] {
                painter.rect_filled(rect(x, 12.5 - h, x + 2.0, 12.5), 0, col);
            }
        }
        "designcraft" => {
            painter.rect_stroke(rect(4.5, 2.5, 19.5, 21.5), rad(1.2), s, StrokeKind::Middle);
            painter.rect_filled(rect(7.0, 5.0, 17.0, 10.5), rad(0.8), col.gamma_multiply(0.75));
            for y in [13.5, 16.0, 18.5] {
                line(&[(7.0, y), (11.0, y)], thin);
                line(&[(13.0, y), (17.0, y)], thin);
            }
        }
        "pdfcraft" => {
            closed(&[(5.5, 2.5), (14.0, 2.5), (18.5, 7.0), (18.5, 21.5), (5.5, 21.5)], s);
            line(&[(14.0, 2.5), (14.0, 7.0), (18.5, 7.0)], thin);
            // aláírás-hullám
            line(&[(8.0, 16.0), (9.5, 13.5), (11.0, 16.5), (12.5, 13.5), (14.0, 16.5), (15.5, 15.0)], thin);
            line(&[(8.0, 18.5), (16.0, 18.5)], thin);
        }
        "photocraft" => {
            painter.rect_stroke(rect(2.5, 4.5, 21.5, 19.5), rad(1.5), s, StrokeKind::Middle);
            painter.add(egui::Shape::convex_polygon(vec![p(4.5, 17.5), p(10.0, 10.5), p(14.5, 17.5)], col, Stroke::NONE));
            painter.add(egui::Shape::convex_polygon(vec![p(11.5, 17.5), p(15.5, 12.0), p(19.5, 17.5)], col.gamma_multiply(0.7), Stroke::NONE));
            painter.circle_filled(p(16.5, 8.5), 1.8 * u, col);
        }
        "vectorcraft" => {
            let pts: Vec<egui::Pos2> = (0..=24)
                .map(|i| {
                    let t = i as f32 / 24.0;
                    let (a, b, c2, d) = ((4.0, 18.0), (6.0, 4.0), (18.0, 20.0), (20.0, 6.0));
                    let m = 1.0 - t;
                    let x = m * m * m * a.0 + 3.0 * m * m * t * b.0 + 3.0 * m * t * t * c2.0 + t * t * t * d.0;
                    let y = m * m * m * a.1 + 3.0 * m * m * t * b.1 + 3.0 * m * t * t * c2.1 + t * t * t * d.1;
                    p(x, y)
                })
                .collect();
            painter.add(egui::Shape::line(pts, s));
            line(&[(4.0, 18.0), (6.0, 4.0)], thin);
            line(&[(20.0, 6.0), (18.0, 20.0)], thin);
            for (x, y) in [(4.0, 18.0), (20.0, 6.0)] {
                painter.rect_filled(Rect::from_center_size(p(x, y), vec2(3.2 * u, 3.2 * u)), 0, col);
            }
            for (x, y) in [(6.0, 4.0), (18.0, 20.0)] {
                painter.circle_filled(p(x, y), 1.4 * u, col);
            }
        }
        "lightcraft" => {
            painter.circle_stroke(p(12.0, 12.0), 9.0 * u, s);
            painter.circle_stroke(p(12.0, 12.0), 4.0 * u, s);
            for k in 0..6 {
                let a = k as f32 * std::f32::consts::TAU / 6.0;
                let (x0, y0) = (12.0 + 4.0 * a.cos(), 12.0 + 4.0 * a.sin());
                let b = a + 1.15;
                let (x1, y1) = (12.0 + 9.0 * b.cos(), 12.0 + 9.0 * b.sin());
                line(&[(x0, y0), (x1, y1)], thin);
            }
        }
        "filmcraft" => {
            painter.rect_stroke(rect(3.0, 4.0, 21.0, 20.0), rad(1.2), s, StrokeKind::Middle);
            for x in [5.0, 8.5, 12.0, 15.5, 19.0] {
                painter.rect_filled(Rect::from_center_size(p(x, 6.3), vec2(1.8 * u, 1.6 * u)), 0, col);
                painter.rect_filled(Rect::from_center_size(p(x, 17.7), vec2(1.8 * u, 1.6 * u)), 0, col);
            }
            painter.add(egui::Shape::convex_polygon(vec![p(10.0, 9.0), p(15.5, 12.0), p(10.0, 15.0)], col, Stroke::NONE));
        }
        "effectcraft" | "artcraft" => {
            let star = |cx: f32, cy: f32, big: f32| {
                let small = big * 0.28;
                let pts = [
                    (cx, cy - big),
                    (cx + small, cy - small),
                    (cx + big, cy),
                    (cx + small, cy + small),
                    (cx, cy + big),
                    (cx - small, cy + small),
                    (cx - big, cy),
                    (cx - small, cy - small),
                ];
                for k in 0..4 {
                    let tri = vec![p(cx, cy), p(pts[2 * k].0, pts[2 * k].1), p(pts[(2 * k + 1) % 8].0, pts[(2 * k + 1) % 8].1)];
                    painter.add(egui::Shape::convex_polygon(tri, col, Stroke::NONE));
                    let tri = vec![p(cx, cy), p(pts[(2 * k + 1) % 8].0, pts[(2 * k + 1) % 8].1), p(pts[(2 * k + 2) % 8].0, pts[(2 * k + 2) % 8].1)];
                    painter.add(egui::Shape::convex_polygon(tri, col, Stroke::NONE));
                }
            };
            if kind == "effectcraft" {
                star(10.0, 13.0, 8.0);
                star(18.5, 5.5, 3.5);
                star(19.0, 18.5, 2.2);
            } else {
                line(&[(4.0, 20.0), (13.5, 10.5)], Stroke::new(u * 2.6, col));
                star(16.5, 7.5, 5.0);
                star(7.0, 6.0, 2.2);
                star(20.0, 15.0, 2.0);
            }
        }
        "soundcraft" => {
            for (i, h) in [3.0, 7.0, 11.0, 6.0, 15.0, 9.0, 12.0, 5.0].iter().enumerate() {
                let x = 4.5 + i as f32 * 2.15;
                line(&[(x, 12.0 - h / 2.0), (x, 12.0 + h / 2.0)], Stroke::new(u * 1.5, col));
            }
        }
        "figcraft" => {
            for (x, y, dx, dy) in [(3.5, 3.5, 1.0, 1.0), (20.5, 3.5, -1.0, 1.0), (3.5, 20.5, 1.0, -1.0), (20.5, 20.5, -1.0, -1.0)] {
                line(&[(x + dx * 4.0, y), (x, y), (x, y + dy * 4.0)], thin);
            }
            painter.add(egui::Shape::convex_polygon(
                vec![p(8.0, 6.5), p(17.0, 13.0), p(12.8, 13.8), p(8.6, 16.6)],
                col,
                Stroke::NONE,
            ));
            line(&[(12.8, 13.8), (15.3, 18.0)], Stroke::new(u * 1.9, col));
        }
        "cadcraft" => {
            closed(&[(3.5, 20.5), (3.5, 6.0), (18.0, 20.5)], s);
            closed(&[(6.5, 17.5), (6.5, 13.0), (11.0, 17.5)], thin);
            painter.circle_stroke(p(16.0, 7.5), 4.0 * u, s);
            painter.circle_filled(p(16.0, 7.5), 1.0 * u, col);
        }
        "texturecraft" => {
            painter.circle_stroke(p(12.0, 12.0), 8.5 * u, s);
            let ell = |rx: f32| {
                let pts: Vec<egui::Pos2> = (0..=32)
                    .map(|i| {
                        let a = i as f32 / 32.0 * std::f32::consts::TAU;
                        p(12.0 + rx * a.cos(), 12.0 + 8.5 * a.sin())
                    })
                    .collect();
                painter.add(egui::Shape::line(pts, thin));
            };
            ell(3.8);
            line(&[(3.5, 12.0), (20.5, 12.0)], thin);
            painter.add(egui::Shape::convex_polygon(
                vec![p(12.0, 3.5), p(15.6, 4.3), p(18.6, 6.4), p(12.0, 12.0)],
                col.gamma_multiply(0.7),
                Stroke::NONE,
            ));
        }
        "anicraft" => {
            // mozgó labda „hagymahéj” nyomvonallal
            for (i, (x, y)) in [(4.5, 17.0), (8.5, 10.0), (12.5, 7.5)].iter().enumerate() {
                painter.circle_stroke(p(*x, *y), 2.2 * u, Stroke::new(u * 0.9, col.gamma_multiply(0.35 + 0.2 * i as f32)));
            }
            painter.circle_filled(p(17.0, 9.5), 3.2 * u, col);
            line(&[(3.0, 20.5), (21.0, 20.5)], thin);
        }
        "materialcraft" => {
            line(&[(7.0, 7.0), (12.0, 12.0), (7.0, 17.0)], thin);
            line(&[(12.0, 12.0), (18.0, 12.0)], thin);
            for (x, y, r0) in [(6.0, 6.0, 2.8), (6.0, 18.0, 2.8), (12.0, 12.0, 3.2)] {
                painter.rect_stroke(Rect::from_center_size(p(x, y), vec2(r0 * 2.0 * u, r0 * 2.0 * u)), rad(1.0), s, StrokeKind::Middle);
            }
            painter.circle_filled(p(18.5, 12.0), 3.4 * u, col);
        }
        "craft-anything" => {
            line(&[(8.5, 6.5), (3.5, 12.0), (8.5, 17.5)], s);
            line(&[(15.5, 6.5), (20.5, 12.0), (15.5, 17.5)], s);
            line(&[(13.8, 5.0), (10.2, 19.0)], s);
        }
        "vormantis" => {
            // izometrikus kocka
            let top = vec![p(12.0, 3.5), p(19.5, 7.8), p(12.0, 12.0), p(4.5, 7.8)];
            painter.add(egui::Shape::convex_polygon(top, col.gamma_multiply(0.85), Stroke::NONE));
            closed(&[(4.5, 7.8), (12.0, 12.0), (19.5, 7.8), (19.5, 16.5), (12.0, 20.8), (4.5, 16.5)], s);
            line(&[(12.0, 12.0), (12.0, 20.8)], s);
        }
        _ => {
            for (x, y) in [(4.5, 4.5), (13.0, 4.5), (4.5, 13.0), (13.0, 13.0)] {
                painter.rect_stroke(rect(x, y, x + 6.5, y + 6.5), rad(1.5), s, StrokeKind::Middle);
            }
        }
    }
    let _ = bg;
}

/// A CraftOffice logó: arany négyzet, benne sötétkék „C” ív és pont.
pub fn paint_logo(painter: &egui::Painter, rect: Rect) {
    let r = (rect.width() * 0.24) as u8;
    painter.rect_filled(rect, CornerRadius::same(r), GOLD);
    let c = rect.center();
    let rad = rect.width() * 0.27;
    let pts: Vec<egui::Pos2> = (0..=40)
        .map(|i| {
            let a = std::f32::consts::PI * (0.25 + 1.5 * i as f32 / 40.0);
            pos2(c.x + rad * a.cos(), c.y - rad * a.sin())
        })
        .collect();
    painter.add(egui::Shape::line(pts, Stroke::new(rect.width() * 0.11, NAVY)));
    painter.circle_filled(pos2(c.x + rad * 0.15, c.y), rect.width() * 0.07, NAVY);
}

fn fmt_time(t: chrono::DateTime<chrono::Local>) -> String {
    let now = chrono::Local::now();
    let d = now.date_naive() - t.date_naive();
    if d.num_days() == 0 {
        format!("Ma {}", t.format("%H:%M"))
    } else if d.num_days() == 1 {
        format!("Tegnap {}", t.format("%H:%M"))
    } else if d.num_days() < 7 {
        let days = ["hétfő", "kedd", "szerda", "csütörtök", "péntek", "szombat", "vasárnap"];
        use chrono::Datelike;
        format!("{} {}", days[t.weekday().num_days_from_monday() as usize], t.format("%H:%M"))
    } else {
        t.format("%Y. %m. %d.").to_string()
    }
}

fn sys_to_local(t: SystemTime) -> chrono::DateTime<chrono::Local> {
    chrono::DateTime::<chrono::Local>::from(t)
}

struct Row {
    path: String,
    app: &'static AppDef,
    when: chrono::DateTime<chrono::Local>,
}

fn load_fonts(ctx: &egui::Context) {
    let mut fonts = egui::FontDefinitions::default();
    let dir = std::env::var_os("WINDIR")
        .map(|w| PathBuf::from(w).join("Fonts"))
        .unwrap_or_else(|| PathBuf::from("C:\\Windows\\Fonts"));
    let try_load = |names: &[&str]| -> Option<Vec<u8>> {
        names.iter().find_map(|n| std::fs::read(dir.join(n)).ok())
    };
    let defaults = fonts.families.get(&FontFamily::Proportional).cloned().unwrap_or_default();
    let mut regular_name = None;
    if let Some(data) = try_load(&["segoeui.ttf"]) {
        fonts.font_data.insert("segoe".into(), std::sync::Arc::new(egui::FontData::from_owned(data)));
        regular_name = Some("segoe".to_string());
        fonts
            .families
            .entry(FontFamily::Proportional)
            .or_default()
            .insert(0, "segoe".into());
    }
    let mut bold_list = Vec::new();
    if let Some(data) = try_load(&["segoeuib.ttf", "seguisb.ttf"]) {
        fonts.font_data.insert("segoe-bold".into(), std::sync::Arc::new(egui::FontData::from_owned(data)));
        bold_list.push("segoe-bold".to_string());
    } else if let Some(r) = regular_name {
        bold_list.push(r);
    }
    bold_list.extend(defaults);
    fonts.families.insert(FontFamily::Name("bold".into()), bold_list);
    ctx.set_fonts(fonts);
}

fn apply_theme(ctx: &egui::Context, theme: Theme) {
    ctx.set_theme(match theme {
        Theme::System => egui::ThemePreference::System,
        Theme::Light => egui::ThemePreference::Light,
        Theme::Dark => egui::ThemePreference::Dark,
    });
}

impl OfficeApp {
    pub fn new(cc: &eframe::CreationContext<'_>, pending: Option<String>) -> Self {
        let ctx = cc.egui_ctx.clone();
        load_fonts(&ctx);
        ctx.all_styles_mut(|s| {
            s.spacing.item_spacing = vec2(8.0, 6.0);
            s.spacing.button_padding = vec2(12.0, 5.0);
            s.spacing.interact_size.y = 28.0;
            for (_, f) in s.text_styles.iter_mut() {
                f.size *= 1.07;
            }
        });
        ctx.style_mut_of(egui::Theme::Dark, |st| {
            let v = &mut st.visuals;
            v.extreme_bg_color = Color32::from_rgb(0x0B, 0x11, 0x20);
            v.widgets.inactive.weak_bg_fill = Color32::from_rgb(0x22, 0x30, 0x4F);
            v.widgets.inactive.bg_fill = Color32::from_rgb(0x22, 0x30, 0x4F);
            v.widgets.hovered.weak_bg_fill = Color32::from_rgb(0x2C, 0x3D, 0x63);
            v.widgets.hovered.bg_fill = Color32::from_rgb(0x2C, 0x3D, 0x63);
            v.widgets.active.weak_bg_fill = Color32::from_rgb(0x35, 0x48, 0x73);
            v.selection.bg_fill = GOLD.gamma_multiply(0.55);
            v.selection.stroke.color = GOLD_LIGHT;
            v.hyperlink_color = GOLD_LIGHT;
        });
        ctx.style_mut_of(egui::Theme::Light, |st| {
            let v = &mut st.visuals;
            v.widgets.inactive.weak_bg_fill = Color32::from_rgb(0xEC, 0xE7, 0xD9);
            v.widgets.inactive.bg_fill = Color32::from_rgb(0xEC, 0xE7, 0xD9);
            v.widgets.hovered.weak_bg_fill = Color32::from_rgb(0xE3, 0xDB, 0xC5);
            v.widgets.hovered.bg_fill = Color32::from_rgb(0xE3, 0xDB, 0xC5);
            v.selection.bg_fill = GOLD.gamma_multiply(0.45);
            v.selection.stroke.color = NAVY;
            v.hyperlink_color = NAVY_2;
        });
        let cfg = Config::load();
        apply_theme(&ctx, cfg.theme);
        // az apps mappa app-mappáinak és exe-inek átnevezése CraftOffice-névre (egyszer)
        let renamed = apps::migrate_names(&cfg.download_dir());
        apps::unblock_tree(&cfg.download_dir());
        let (tx, rx) = channel();
        let mut app = Self {
            installed: apps::discover_cfg(&cfg),
            cfg,
            page: Page::Home,
            tab: FileTab::Recent,
            search: String::new(),
            scanned: Vec::new(),
            scan_rx: None,
            tx,
            rx,
            busy: HashMap::new(),
            latest: HashMap::new(),
            errors: HashMap::new(),
            textures: HashMap::new(),
            toast: None,
            pending_toast: pending.map(|m| (m, true)).or_else(|| {
                (renamed > 0).then(|| (format!("{renamed} alkalmazás átnevezve CraftOffice-névre"), false))
            }),
            new_root: String::new(),
            new_scan: String::new(),
            ctx,
        };
        app.load_icons();
        app.start_scan();
        // magyar helyesírási szótár a WordCraft mappájába (háttérben, csendben)
        std::thread::spawn(|| {
            let _ = crate::spell::install();
        });
        if app.cfg.check_updates_on_start {
            app.check_updates();
        }
        app
    }

    // ---------- műveletek ----------

    fn rediscover(&mut self) {
        self.installed = apps::discover_cfg(&self.cfg);
        self.load_icons();
    }

    /// Saját app-ikonok (pl. Vormantis icon-512.png) betöltése textúrának.
    fn load_icons(&mut self) {
        self.textures.clear();
        for (id, inst) in &self.installed {
            let Some(path) = apps::own_icon(inst) else { continue };
            let Ok(img) = image::open(&path) else { continue };
            let img = img.resize(128, 128, image::imageops::FilterType::Lanczos3).to_rgba8();
            let size = [img.width() as usize, img.height() as usize];
            let ci = egui::ColorImage::from_rgba_unmultiplied(size, img.as_raw());
            let t = self.ctx.load_texture(format!("icon-{id}"), ci, egui::TextureOptions::LINEAR);
            self.textures.insert(id, t);
        }
    }

    fn icon(&self, painter: &egui::Painter, rect: Rect, app: &AppDef, faded: bool) {
        paint_app_icon_tex(painter, rect, app, faded, self.textures.get(app.id).map(|t| t.id()));
    }

    fn start_scan(&mut self) {
        let (tx, rx) = channel();
        let dirs = self.cfg.scan_dirs.clone();
        let ctx = self.ctx.clone();
        std::thread::spawn(move || {
            let r = scan::scan(&dirs, false);
            let _ = tx.send(r);
            ctx.request_repaint();
        });
        self.scan_rx = Some(rx);
    }

    fn check_updates(&mut self) {
        for app in apps::all().into_iter().filter(|a| a.core || self.installed.contains_key(a.id)) {
            download::spawn_check(app, self.tx.clone(), self.ctx.clone());
        }
    }

    /// Az app exe-jének kézi kiválasztása (pl. saját app, ami nincs a keresett mappákban).
    fn pick_exe(&mut self, app: &'static AppDef) {
        if let Some(f) = rfd::FileDialog::new()
            .set_title(format!("{} – hol van a program?", app.name))
            .add_filter("Program", &["exe"])
            .pick_file()
        {
            self.cfg.exe_overrides.insert(app.id.to_string(), f.display().to_string());
            self.cfg.save();
            self.rediscover();
            self.notify(format!("{} hozzáadva: {}", app.name, f.display()), false);
        }
    }

    fn install(&mut self, app: &'static AppDef) {
        self.busy.insert(app.id, "Indítás…".into());
        self.errors.remove(app.id);
        download::spawn_install(app, self.cfg.download_dir(), self.tx.clone(), self.ctx.clone());
    }

    fn notify(&mut self, text: impl Into<String>, error: bool) {
        let now = self.ctx.input(|i| i.time);
        self.toast = Some(Toast { text: text.into(), error, until: now + if error { 6.0 } else { 3.5 } });
        self.ctx.request_repaint();
    }

    fn launch_app(&mut self, app: &'static AppDef, extra: &[&str]) {
        match self.installed.get(app.id).cloned() {
            Some(inst) => match apps::launch(&inst, None, extra) {
                Ok(()) => self.notify(format!("{} indul…", app.name), false),
                Err(e) => self.notify(format!("{} nem indítható: {e}", app.name), true),
            },
            None => {
                self.notify(
                    format!("A(z) {} nincs telepítve. Letöltheted az Alkalmazások oldalon.", app.name),
                    true,
                );
                self.page = Page::Apps;
            }
        }
    }

    fn open_path(&mut self, path: &Path) {
        let Some(app) = app_for_path(path) else {
            self.notify(format!("Ismeretlen fájltípus: {}", path.display()), true);
            return;
        };
        match self.installed.get(app.id).cloned() {
            Some(inst) => match apps::launch(&inst, Some(path), &[]) {
                Ok(()) => {
                    self.cfg.push_recent(path, app.id);
                    self.cfg.save();
                    let name = path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
                    self.notify(format!("{name} megnyitása – {}", app.name), false);
                }
                Err(e) => self.notify(format!("{} nem indítható: {e}", app.name), true),
            },
            None => {
                self.notify(
                    format!("A fájlhoz a(z) {} kell, ami nincs telepítve. Töltsd le az Alkalmazások oldalon.", app.name),
                    true,
                );
                self.page = Page::Apps;
            }
        }
    }

    fn browse_open(&mut self) {
        let all: Vec<&str> = apps::all().into_iter().filter(|a| !a.exts.is_empty()).flat_map(|a| a.exts.iter().copied()).collect();
        let mut dlg = rfd::FileDialog::new()
            .set_title("Megnyitás")
            .add_filter("Minden támogatott fájl", &all);
        for a in apps::all().into_iter().filter(|a| !a.exts.is_empty()) {
            dlg = dlg.add_filter(format!("{} ({})", a.name, a.origin), a.exts);
        }
        if let Some(files) = dlg.pick_files() {
            for f in files {
                self.open_path(&f);
            }
        }
    }

    fn poll(&mut self) {
        while let Ok(m) = self.rx.try_recv() {
            match m {
                Msg::Status(id, s) => {
                    self.busy.insert(id, s);
                }
                Msg::Installed(id, v) => {
                    self.busy.remove(id);
                    apps::migrate_names(&self.cfg.download_dir());
                    apps::unblock_tree(&self.cfg.download_dir());
                    self.rediscover();
                    let name = app_by_id(id).map(|a| a.name).unwrap_or(id);
                    self.notify(format!("{name} v{v} telepítve"), false);
                }
                Msg::Failed(id, e) => {
                    self.busy.remove(id);
                    self.errors.insert(id, e.clone());
                    let name = app_by_id(id).map(|a| a.name).unwrap_or(id);
                    self.notify(format!("{name}: {e}"), true);
                }
                Msg::Latest(id, v) => {
                    self.latest.insert(id, v);
                }
            }
        }
        if let Some(rx) = &self.scan_rx {
            if let Ok(r) = rx.try_recv() {
                self.scanned = r;
                self.scan_rx = None;
            }
        }
        if let Some((t, e)) = self.pending_toast.take() {
            self.notify(t, e);
        }
        let dropped: Vec<PathBuf> =
            self.ctx.input(|i| i.raw.dropped_files.iter().map(|f| f.path().to_path_buf()).collect());
        for p in dropped {
            self.open_path(&p);
        }
        if self.ctx.input_mut(|i| i.consume_key(egui::Modifiers::COMMAND, egui::Key::O)) {
            self.browse_open();
        }
    }

    fn update_available(&self, id: &str) -> Option<&String> {
        let latest = self.latest.get(id)?;
        let inst = self.installed.get(id)?;
        match &inst.version {
            Some(v) if apps::version_newer(latest, v) => Some(latest),
            _ => None,
        }
    }

    // ---------- felület ----------

    fn rail(&mut self, ui: &mut Ui) {
        let p = pal(ui);
        ui.add_space(6.0);
        // logó: négy színes négyzet + név
        ui.horizontal(|ui| {
            let (r, _) = ui.allocate_exact_size(vec2(32.0, 32.0), Sense::hover());
            paint_logo(ui.painter(), r);
            ui.spacing_mut().item_spacing.x = 0.0;
            ui.label(RichText::new("Craft").font(bold(21.0)).color(p.rail_text));
            ui.label(RichText::new("Office").font(bold(21.0)).color(GOLD));
        });
        ui.add_space(22.0);
        let items = [
            (Page::Home, "home", "Kezdőlap"),
            (Page::New, "new", "Új"),
            (Page::Open, "open", "Megnyitás"),
            (Page::Apps, "apps", "Alkalmazások"),
        ];
        for (pg, icon, label) in items {
            if nav_item(ui, &p, icon, label, self.page == pg) {
                self.page = pg;
            }
        }
        ui.with_layout(Layout::bottom_up(Align::Min), |ui| {
            ui.add_space(4.0);
            ui.label(
                RichText::new(format!("v{}", env!("CARGO_PKG_VERSION")))
                    .size(11.0)
                    .color(p.rail_text.gamma_multiply(0.55)),
            );
            if nav_item(ui, &p, "settings", "Beállítások", self.page == Page::Settings) {
                self.page = Page::Settings;
            }
        });
    }

    fn topbar(&mut self, ui: &mut Ui) {
        let p = pal(ui);
        ui.horizontal(|ui| {
            ui.add_space(4.0);
            let edit = egui::TextEdit::singleline(&mut self.search)
                .hint_text("Keresés a fájlok között…")
                .desired_width(440.0)
                .margin(vec2(10.0, 7.0));
            let r = ui.add(edit);
            if r.changed() && !self.search.is_empty() && self.page != Page::Home && self.page != Page::Open {
                self.page = Page::Home;
            }
            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                let dark = ui.visuals().dark_mode;
                if ui
                    .button(if dark { "Világos téma" } else { "Sötét téma" })
                    .on_hover_text("Téma váltása")
                    .clicked()
                {
                    self.cfg.theme = if dark { Theme::Light } else { Theme::Dark };
                    apply_theme(&self.ctx, self.cfg.theme);
                    self.cfg.save();
                }
                if ui
                    .add(egui::Button::new(RichText::new("Megnyitás…").color(p.on_accent)).fill(p.accent))
                    .on_hover_text("Ctrl+O")
                    .clicked()
                {
                    self.browse_open();
                }
            });
        });
    }

    fn section_title(ui: &mut Ui, text: &str) {
        ui.add_space(14.0);
        ui.label(RichText::new(text).font(bold(17.0)));
        ui.add_space(6.0);
    }

    fn home(&mut self, ui: &mut Ui) {
        use chrono::Timelike;
        let h = chrono::Local::now().hour();
        let greet = match h {
            5..=9 => "Jó reggelt!",
            10..=17 => "Jó napot!",
            _ => "Jó estét!",
        };
        ui.label(RichText::new(greet).font(bold(28.0)));

        for g in GROUPS {
            if *g != "Iroda" && !self.cfg.show_extras {
                continue;
            }
            if !apps::all().iter().any(|a| a.group == *g) {
                continue;
            }
            Self::section_title(ui, g);
            self.app_tiles(ui, g);
        }

        Self::section_title(ui, "Új létrehozása");
        self.new_cards(ui, false);

        ui.add_space(10.0);
        self.files_section(ui);
    }

    fn app_tiles(&mut self, ui: &mut Ui, group: &str) {
        let p = pal(ui);
        let mut clicked: Option<&'static AppDef> = None;
        ui.horizontal_wrapped(|ui| {
            ui.spacing_mut().item_spacing = vec2(10.0, 10.0);
            for app in apps::all().into_iter().filter(|a| a.group == group) {
                let inst = self.installed.get(app.id);
                let (rect, resp) = ui.allocate_exact_size(vec2(112.0, 116.0), Sense::click());
                if resp.hovered() {
                    ui.painter().rect_filled(rect, 10, p.card_hover);
                }
                let icon = Rect::from_center_size(pos2(rect.center().x, rect.top() + 42.0), vec2(56.0, 56.0));
                self.icon(ui.painter(), icon, app, inst.is_none());
                ui.painter().text(
                    pos2(rect.center().x, rect.top() + 86.0),
                    Align2::CENTER_CENTER,
                    app.name,
                    FontId::proportional(14.5),
                    p.text,
                );
                let sub = if self.busy.contains_key(app.id) {
                    "letöltés…".to_string()
                } else if inst.is_none() {
                    "Letöltés".to_string()
                } else if self.update_available(app.id).is_some() {
                    "frissítés elérhető".to_string()
                } else {
                    app.office.to_string()
                };
                ui.painter().text(
                    pos2(rect.center().x, rect.top() + 104.0),
                    Align2::CENTER_CENTER,
                    sub,
                    FontId::proportional(11.5),
                    if inst.is_none() { p.accent } else { p.sub },
                );
                let tip = match inst {
                    Some(i) => format!(
                        "{} ({} alapon) – {} megfelelő\n{}\nVerzió: {}",
                        app.name,
                        app.origin,
                        app.office,
                        app.desc,
                        i.version.clone().unwrap_or_else(|| "ismeretlen".into())
                    ),
                    None => format!(
                        "{} ({} alapon) – {} megfelelő\n{}\nNincs telepítve – kattints a letöltéshez",
                        app.name, app.origin, app.office, app.desc
                    ),
                };
                if resp.on_hover_text(tip).clicked() {
                    clicked = Some(app);
                }
            }
        });
        if let Some(app) = clicked {
            if self.installed.contains_key(app.id) {
                self.launch_app(app, &[]);
            } else if app.repo.is_empty() {
                self.pick_exe(app);
            } else if !self.busy.contains_key(app.id) {
                self.install(app);
                self.notify(format!("{} letöltése elindult…", app.name), false);
            }
        }
    }

    fn new_cards(&mut self, ui: &mut Ui, with_samples: bool) {
        let p = pal(ui);
        let mut action: Option<(&'static AppDef, bool)> = None;
        ui.horizontal_wrapped(|ui| {
            ui.spacing_mut().item_spacing = vec2(14.0, 14.0);
            let mut cards: Vec<(&'static AppDef, bool)> =
                apps::all().into_iter().filter(|a| a.core && a.id != "pdfcraft").map(|a| (a, false)).collect();
            if with_samples {
                cards.extend(apps::all().into_iter().filter(|a| a.core && a.sample).map(|a| (a, true)));
            }
            for (app, sample) in cards {
                let (rect, resp) = ui.allocate_exact_size(vec2(150.0, 168.0), Sense::click());
                let page = Rect::from_min_size(rect.min + vec2(15.0, 0.0), vec2(120.0, 136.0));
                let hovered = resp.hovered();
                ui.painter().rect_filled(page, 6, p.card);
                ui.painter().rect_stroke(
                    page,
                    6,
                    Stroke::new(if hovered { 2.0 } else { 1.0 }, if hovered { rgb(app.color) } else { p.border }),
                    StrokeKind::Inside,
                );
                // stilizált tartalom
                let c = rgb(app.color);
                match app.id {
                    "gridcraft" => {
                        for i in 0..6 {
                            let y = page.top() + 22.0 + i as f32 * 14.0;
                            ui.painter().line_segment(
                                [pos2(page.left() + 12.0, y), pos2(page.right() - 12.0, y)],
                                Stroke::new(1.0, p.border),
                            );
                        }
                        for i in 0..4 {
                            let x = page.left() + 12.0 + i as f32 * 32.0;
                            ui.painter().line_segment(
                                [pos2(x, page.top() + 22.0), pos2(x, page.top() + 92.0)],
                                Stroke::new(1.0, p.border),
                            );
                        }
                    }
                    "deckcraft" => {
                        let s = Rect::from_min_size(page.min + vec2(12.0, 26.0), vec2(96.0, 56.0));
                        ui.painter().rect_filled(s, 3, c.gamma_multiply(0.18));
                        ui.painter().rect_filled(
                            Rect::from_min_size(s.min + vec2(10.0, 12.0), vec2(60.0, 8.0)),
                            2,
                            c.gamma_multiply(0.7),
                        );
                    }
                    "designcraft" => {
                        ui.painter().rect_filled(
                            Rect::from_min_size(page.min + vec2(12.0, 16.0), vec2(96.0, 44.0)),
                            3,
                            c.gamma_multiply(0.25),
                        );
                        for i in 0..3 {
                            let y = page.top() + 70.0 + i as f32 * 10.0;
                            ui.painter().line_segment(
                                [pos2(page.left() + 12.0, y), pos2(page.left() + 56.0, y)],
                                Stroke::new(2.0, p.border),
                            );
                            ui.painter().line_segment(
                                [pos2(page.left() + 64.0, y), pos2(page.right() - 12.0, y)],
                                Stroke::new(2.0, p.border),
                            );
                        }
                    }
                    _ => {
                        for i in 0..7 {
                            let y = page.top() + 22.0 + i as f32 * 11.0;
                            let w = if i % 3 == 2 { 60.0 } else { 96.0 };
                            ui.painter().line_segment(
                                [pos2(page.left() + 12.0, y), pos2(page.left() + 12.0 + w, y)],
                                Stroke::new(2.0, if i == 0 { c.gamma_multiply(0.7) } else { p.border }),
                            );
                        }
                    }
                }
                let icon = Rect::from_min_size(pos2(page.right() - 34.0, page.bottom() - 34.0), vec2(26.0, 26.0));
                self.icon(ui.painter(), icon, app, !self.installed.contains_key(app.id));
                let label = if sample { format!("Minta – {}", app.name) } else { app.new_label.to_string() };
                ui.painter().text(
                    pos2(rect.center().x, rect.bottom() - 18.0),
                    Align2::CENTER_CENTER,
                    label,
                    FontId::proportional(13.5),
                    p.text,
                );
                if resp.on_hover_text(format!("{} – {}", app.name, app.office)).clicked() {
                    action = Some((app, sample));
                }
            }
        });
        if let Some((app, sample)) = action {
            self.launch_app(app, if sample { &["--sample"] } else { &[] });
        }
    }

    fn rows(&self) -> Vec<Row> {
        let q = self.search.trim().to_lowercase();
        let matches = |s: &str| q.is_empty() || s.to_lowercase().contains(&q);
        let mut v: Vec<Row> = match self.tab {
            FileTab::Recent => self
                .cfg
                .recent
                .iter()
                .filter_map(|r| {
                    Some(Row {
                        app: app_by_id(&r.app_id).or_else(|| app_for_path(Path::new(&r.path)))?,
                        when: chrono::DateTime::from_timestamp(r.opened, 0)?.with_timezone(&chrono::Local),
                        path: r.path.clone(),
                    })
                })
                .collect(),
            FileTab::Pinned => self
                .cfg
                .pinned
                .iter()
                .filter_map(|p| {
                    let path = Path::new(p);
                    let when = std::fs::metadata(path).and_then(|m| m.modified()).map(sys_to_local).ok()?;
                    Some(Row { app: app_for_path(path)?, when, path: p.clone() })
                })
                .collect(),
            FileTab::Computer => self
                .scanned
                .iter()
                .filter_map(|f| {
                    Some(Row {
                        app: app_by_id(f.app_id)?,
                        when: sys_to_local(f.modified),
                        path: f.path.display().to_string(),
                    })
                })
                .collect(),
        };
        v.retain(|r| matches(&r.path));
        v
    }

    fn files_section(&mut self, ui: &mut Ui) {
        let p = pal(ui);
        ui.horizontal(|ui| {
            for (t, label) in [
                (FileTab::Recent, "Legutóbbiak"),
                (FileTab::Pinned, "Rögzítettek"),
                (FileTab::Computer, "Dokumentumok a gépen"),
            ] {
                let sel = self.tab == t;
                let r = ui.add(
                    egui::Button::new(RichText::new(label).font(if sel { bold(15.0) } else { FontId::proportional(15.0) }))
                        .frame(false),
                );
                if sel {
                    let r2 = r.rect;
                    ui.painter().line_segment(
                        [pos2(r2.left() + 6.0, r2.bottom() + 2.0), pos2(r2.right() - 6.0, r2.bottom() + 2.0)],
                        Stroke::new(3.0, p.accent),
                    );
                }
                if r.clicked() {
                    self.tab = t;
                }
            }
            if self.tab == FileTab::Computer {
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    if self.scan_rx.is_some() {
                        ui.spinner();
                    } else if ui.small_button("Újrakeresés").clicked() {
                        self.start_scan();
                    }
                });
            }
        });
        ui.add_space(6.0);

        let rows = self.rows();
        let mut open: Option<String> = None;
        let mut pin: Option<String> = None;
        let mut remove: Option<String> = None;
        let mut reveal: Option<String> = None;

        Frame::NONE
            .fill(p.card)
            .stroke(Stroke::new(1.0, p.border))
            .corner_radius(8)
            .inner_margin(Margin::same(6))
            .show(ui, |ui| {
                ui.set_width(ui.available_width());
                // fejléc
                ui.horizontal(|ui| {
                    ui.add_space(46.0);
                    ui.label(RichText::new("Név").color(p.sub).size(12.5));
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        ui.add_space(44.0);
                        ui.add_sized([150.0, 18.0], egui::Label::new(RichText::new(match self.tab {
                            FileTab::Recent => "Megnyitva",
                            _ => "Módosítva",
                        }).color(p.sub).size(12.5)));
                    });
                });
                ui.separator();
                if rows.is_empty() {
                    ui.add_space(18.0);
                    ui.vertical_centered(|ui| {
                        let msg = if !self.search.is_empty() {
                            "Nincs találat."
                        } else {
                            match self.tab {
                                FileTab::Recent => "Még nincs legutóbbi fájl. Nyiss meg egyet a Megnyitás gombbal, vagy húzd ide.",
                                FileTab::Pinned => "Nincs rögzített fájl. Jobb kattintás egy fájlon → Rögzítés, vagy a csillag ikon.",
                                FileTab::Computer => {
                                    if self.scan_rx.is_some() { "Keresés folyamatban…" } else { "Nem található dokumentum a megadott mappákban." }
                                }
                            }
                        };
                        ui.label(RichText::new(msg).color(p.sub));
                    });
                    ui.add_space(18.0);
                    return;
                }
                for (i, row) in rows.iter().take(150).enumerate() {
                    let width = ui.available_width();
                    let (rect, resp) = ui.allocate_exact_size(vec2(width, 44.0), Sense::click());
                    let star_rect = Rect::from_center_size(pos2(rect.right() - 20.0, rect.center().y), vec2(30.0, 30.0));
                    let star = ui.interact(star_rect, ui.scope_id().with(("star", i)), Sense::click());
                    if resp.hovered() || star.hovered() {
                        ui.painter().rect_filled(rect, 6, p.card_hover);
                    }
                    let exists = Path::new(&row.path).exists();
                    let icon = Rect::from_min_size(pos2(rect.left() + 10.0, rect.center().y - 14.0), vec2(28.0, 28.0));
                    self.icon(ui.painter(), icon, row.app, !exists);
                    let path = Path::new(&row.path);
                    let name = path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
                    let folder = path.parent().map(|d| d.display().to_string()).unwrap_or_default();
                    let painter = ui.painter_at(Rect::from_min_max(rect.min, pos2(rect.right() - 210.0, rect.max.y)));
                    painter.text(
                        pos2(rect.left() + 48.0, rect.top() + 14.0),
                        Align2::LEFT_CENTER,
                        &name,
                        FontId::proportional(14.5),
                        if exists { p.text } else { p.sub },
                    );
                    painter.text(
                        pos2(rect.left() + 48.0, rect.top() + 31.0),
                        Align2::LEFT_CENTER,
                        if exists { folder } else { format!("{folder}  (nem található)") },
                        FontId::proportional(11.5),
                        p.sub,
                    );
                    ui.painter().text(
                        pos2(rect.right() - 190.0, rect.center().y),
                        Align2::LEFT_CENTER,
                        fmt_time(row.when),
                        FontId::proportional(13.0),
                        p.sub,
                    );
                    let pinned = self.cfg.is_pinned(&row.path);
                    paint_star(
                        ui.painter(),
                        star_rect.center(),
                        8.5,
                        pinned,
                        if pinned { Color32::from_rgb(0xE8, 0xA3, 0x17) } else if star.hovered() { p.text } else { p.sub.gamma_multiply(0.6) },
                    );
                    if star.on_hover_text(if pinned { "Rögzítés feloldása" } else { "Rögzítés" }).clicked() {
                        pin = Some(row.path.clone());
                    } else if resp.clicked() {
                        open = Some(row.path.clone());
                    }
                    resp.context_menu(|ui| {
                        if ui.button("Megnyitás").clicked() {
                            open = Some(row.path.clone());
                            ui.close();
                        }
                        if ui.button("Fájl helyének megnyitása").clicked() {
                            reveal = Some(row.path.clone());
                            ui.close();
                        }
                        if ui.button("Elérési út másolása").clicked() {
                            ui.ctx().copy_text(row.path.clone());
                            ui.close();
                        }
                        if ui.button(if pinned { "Rögzítés feloldása" } else { "Rögzítés" }).clicked() {
                            pin = Some(row.path.clone());
                            ui.close();
                        }
                        if self.tab == FileTab::Recent && ui.button("Eltávolítás a listából").clicked() {
                            remove = Some(row.path.clone());
                            ui.close();
                        }
                    });
                }
            });

        if let Some(p) = open {
            self.open_path(Path::new(&p));
        }
        if let Some(p) = pin {
            self.cfg.toggle_pin(&p);
            self.cfg.save();
        }
        if let Some(p) = remove {
            self.cfg.recent.retain(|r| r.path != p);
            self.cfg.save();
        }
        if let Some(p) = reveal {
            apps::reveal(Path::new(&p));
        }
    }

    fn new_page(&mut self, ui: &mut Ui) {
        ui.label(RichText::new("Új").font(bold(28.0)));
        ui.label(RichText::new("Válaszd ki, mit szeretnél létrehozni.").color(pal(ui).sub));
        Self::section_title(ui, "Üres fájlok és minták");
        self.new_cards(ui, true);
    }

    fn open_page(&mut self, ui: &mut Ui) {
        let p = pal(ui);
        ui.label(RichText::new("Megnyitás").font(bold(28.0)));
        ui.add_space(8.0);
        ui.horizontal(|ui| {
            if ui
                .add(
                    egui::Button::new(RichText::new("Tallózás…").size(16.0).color(p.on_accent))
                        .fill(p.accent)
                        .min_size(vec2(160.0, 40.0)),
                )
                .clicked()
            {
                self.browse_open();
            }
            ui.label(RichText::new("vagy húzz egy fájlt bárhová ebbe az ablakba").color(p.sub));
        });
        ui.add_space(4.0);
        ui.horizontal_wrapped(|ui| {
            ui.label(RichText::new("Gyors elérés:").color(p.sub));
            for d in self.cfg.scan_dirs.clone() {
                let name = Path::new(&d).file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or(d.clone());
                if ui.small_button(name.clone()).on_hover_text(&d).clicked() {
                    apps::reveal(Path::new(&d));
                }
            }
        });
        ui.add_space(10.0);
        self.files_section(ui);
    }

    fn apps_page(&mut self, ui: &mut Ui) {
        let p = pal(ui);
        ui.horizontal(|ui| {
            ui.label(RichText::new("Alkalmazások").font(bold(28.0)));
            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                if ui.button("Újrakeresés a gépen").clicked() {
                    self.rediscover();
                    self.notify(format!("{} alkalmazás található", self.installed.len()), false);
                }
                if ui.button("Frissítések keresése").clicked() {
                    self.check_updates();
                    self.notify("Frissítések keresése…", false);
                }
            });
        });
        ui.label(
            RichText::new(format!(
                "A letöltött alkalmazások ide kerülnek: {}",
                self.cfg.download_dir().display()
            ))
            .color(p.sub)
            .size(12.5),
        );

        for g in GROUPS {
            let list: Vec<&'static AppDef> = apps::all().into_iter().filter(|a| a.group == *g).collect();
            if list.is_empty() {
                continue;
            }
            Self::section_title(ui, g);
            for app in list {
                let inst = self.installed.get(app.id).cloned();
                Frame::NONE
                    .fill(p.card)
                    .stroke(Stroke::new(1.0, p.border))
                    .corner_radius(8)
                    .inner_margin(Margin::symmetric(14, 10))
                    .show(ui, |ui| {
                        ui.set_width(ui.available_width());
                        ui.horizontal(|ui| {
                            let (r, _) = ui.allocate_exact_size(vec2(48.0, 48.0), Sense::hover());
                            self.icon(ui.painter(), r, app, inst.is_none());
                            ui.add_space(6.0);
                            ui.vertical(|ui| {
                                ui.horizontal(|ui| {
                                    ui.label(RichText::new(app.name).font(bold(16.0)));
                                    ui.label(RichText::new(format!("· {} alapon · {} megfelelő", app.origin, app.office)).color(p.sub));
                                });
                                ui.label(RichText::new(app.desc).color(p.sub).size(12.5));
                                let status = match &inst {
                                    Some(i) => format!(
                                        "Telepítve{} – {}",
                                        i.version.as_ref().map(|v| format!(" v{v}")).unwrap_or_default(),
                                        i.dir.display()
                                    ),
                                    None => "Nincs telepítve".to_string(),
                                };
                                ui.label(RichText::new(status).size(12.0).color(if inst.is_some() {
                                    Color32::from_rgb(0x2E, 0x9E, 0x5B)
                                } else {
                                    p.sub
                                }));
                                if let Some(e) = self.errors.get(app.id).cloned() {
                                    ui.horizontal_wrapped(|ui| {
                                        ui.label(
                                            RichText::new(format!("Letöltési hiba: {e}"))
                                                .size(12.0)
                                                .color(Color32::from_rgb(0xD0, 0x3A, 0x2A)),
                                        );
                                        if ui.small_button("Napló megnyitása").clicked() {
                                            apps::open_url(&download::log_path().display().to_string());
                                        }
                                    });
                                }
                            });
                            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                                if let Some(s) = self.busy.get(app.id) {
                                    ui.label(RichText::new(s).color(p.sub));
                                    ui.spinner();
                                    return;
                                }
                                if let Some(i) = &inst {
                                    if ui.button("Mappa").on_hover_text("Mappa megnyitása").clicked() {
                                        apps::reveal(&i.dir);
                                    }
                                    if let Some(v) = self.update_available(app.id).cloned() {
                                        if ui.button(format!("Frissítés: v{v}")).clicked() {
                                            self.install(app);
                                        }
                                    }
                                    if ui
                                        .add(egui::Button::new(RichText::new("Indítás").color(Color32::WHITE)).fill(rgb(app.color)))
                                        .clicked()
                                    {
                                        self.launch_app(app, &[]);
                                    }
                                } else if app.repo.is_empty() {
                                    if ui
                                        .add(egui::Button::new(RichText::new("Hely megadása…").color(p.on_accent)).fill(p.accent))
                                        .on_hover_text("Válaszd ki a program exe-fájlját")
                                        .clicked()
                                    {
                                        self.pick_exe(app);
                                    }
                                } else {
                                    if ui.small_button("Hely…").on_hover_text("Már telepítve van máshol? Válaszd ki az exe-t").clicked() {
                                        self.pick_exe(app);
                                    }
                                    if ui.button("Kézi letöltés").on_hover_text(format!("https://github.com/{}/releases – töltsd le a windows-x64-portable.zip-et, és csomagold ki az apps mappába", app.repo)).clicked() {
                                        apps::open_url(&format!("https://github.com/{}/releases", app.repo));
                                    }
                                    let label = match self.latest.get(app.id) {
                                        Some(v) => format!("Letöltés (v{v})"),
                                        None => "Letöltés".to_string(),
                                    };
                                    if ui
                                        .add(egui::Button::new(RichText::new(label).color(p.on_accent)).fill(p.accent))
                                        .clicked()
                                    {
                                        self.install(app);
                                    }
                                }
                            });
                        });
                    });
                ui.add_space(6.0);
            }
        }
    }

    fn path_list(ui: &mut Ui, list: &mut Vec<String>, input: &mut String, what: &str) -> bool {
        let mut changed = false;
        let mut del = None;
        for (i, d) in list.iter().enumerate() {
            ui.horizontal(|ui| {
                if ui.small_button("Törlés").on_hover_text("Eltávolítás").clicked() {
                    del = Some(i);
                }
                ui.label(d);
                if !Path::new(d).is_dir() {
                    ui.label(RichText::new("(nem létezik)").color(Color32::from_rgb(0xD0, 0x4A, 0x3A)));
                }
            });
        }
        if let Some(i) = del {
            list.remove(i);
            changed = true;
        }
        ui.horizontal(|ui| {
            ui.add(egui::TextEdit::singleline(input).hint_text(what).desired_width(380.0));
            if ui.button("Tallózás…").clicked() {
                if let Some(d) = rfd::FileDialog::new().pick_folder() {
                    *input = d.display().to_string();
                }
            }
            if ui.button("Hozzáadás").clicked() && !input.trim().is_empty() {
                let v = input.trim().to_string();
                if !list.contains(&v) {
                    list.push(v);
                    changed = true;
                }
                input.clear();
            }
        });
        changed
    }

    fn settings_page(&mut self, ui: &mut Ui) {
        let p = pal(ui);
        ui.label(RichText::new("Beállítások").font(bold(28.0)));

        Self::section_title(ui, "Megjelenés");
        ui.horizontal(|ui| {
            let mut t = self.cfg.theme;
            ui.radio_value(&mut t, Theme::System, "Rendszer szerint");
            ui.radio_value(&mut t, Theme::Light, "Világos");
            ui.radio_value(&mut t, Theme::Dark, "Sötét");
            if t != self.cfg.theme {
                self.cfg.theme = t;
                apply_theme(&self.ctx, t);
                self.cfg.save();
            }
        });
        if ui.checkbox(&mut self.cfg.show_extras, "További Craft alkalmazások megjelenítése (PhotoCraft, CADCraft…)").changed() {
            self.cfg.save();
        }

        Self::section_title(ui, "Alkalmazások nyelve");
        ui.horizontal(|ui| {
            let mut l = self.cfg.app_lang.clone();
            ui.radio_value(&mut l, String::new(), "Windows nyelve");
            ui.radio_value(&mut l, "hu".to_string(), "Magyar");
            ui.radio_value(&mut l, "ro".to_string(), "Română");
            ui.radio_value(&mut l, "en".to_string(), "English");
            if l != self.cfg.app_lang {
                self.cfg.app_lang = l;
                self.cfg.save();
            }
        });
        ui.label(
            RichText::new(
                "A Slides és az Audio ezt követi. A többi app a Windows nyelvével indul, \
                 és a saját beállításaiban (Fájl › Beállítások / Nézet › Nyelv) bármikor átállítható.",
            )
            .size(12.0)
            .color(p.sub),
        );

        Self::section_title(ui, "Alkalmazások helye");
        ui.label(RichText::new("Automatikusan átnézett mappák:").color(p.sub).size(12.5));
        let auto: Vec<PathBuf> = {
            let mut c = self.cfg.clone();
            c.extra_roots.clear();
            c.roots()
        };
        for r in auto {
            ui.label(RichText::new(format!("  • {}", r.display())).size(12.5).color(p.sub));
        }
        ui.add_space(4.0);
        ui.label("Saját mappák (ahol a *craft-… mappák vannak):");
        if Self::path_list(ui, &mut self.cfg.extra_roots, &mut self.new_root, "pl. D:\\portables") {
            self.cfg.save();
            self.rediscover();
        }
        ui.add_space(4.0);
        ui.horizontal(|ui| {
            ui.label("Letöltési mappa:");
            let mut d = self.cfg.download_dir.clone();
            let r = ui.add(
                egui::TextEdit::singleline(&mut d)
                    .hint_text(self.cfg.download_dir().display().to_string())
                    .desired_width(340.0),
            );
            if r.changed() {
                self.cfg.download_dir = d;
                self.cfg.save();
            }
            if ui.button("Tallózás…").clicked() {
                if let Some(f) = rfd::FileDialog::new().pick_folder() {
                    self.cfg.download_dir = f.display().to_string();
                    self.cfg.save();
                    self.rediscover();
                }
            }
        });

        Self::section_title(ui, "Dokumentumok keresése");
        ui.label(RichText::new("A „Dokumentumok a gépen” lista ezekből a mappákból készül (4 szint mélyen).").color(p.sub).size(12.5));
        if Self::path_list(ui, &mut self.cfg.scan_dirs, &mut self.new_scan, "pl. E:\\Dokumentumok") {
            self.cfg.save();
            self.start_scan();
        }

        Self::section_title(ui, "Helyesírás (magyar, román, angol)");
        let (b, i) = (crate::spell::bundled(), crate::spell::installed());
        let langs = crate::spell::languages();
        ui.label(if b {
            format!(
                "Nyelvi csomagok: {} – helyesírás, automatikus javítás és szinonimaszótár a LibreOffice szótáraiból \
                 (Magyar Ispell, rospell; MPL / LGPL / GPL). Az angol beépített.",
                langs.join(", ")
            )
        } else {
            "A csomagból hiányoznak a szótárak (szotarak mappa).".to_string()
        });
        ui.label(
            RichText::new(if i {
                "Telepítve a Writer (WordCraft) szótármappájába: helyesírás-ellenőrzés javaslatokkal, automatikus javítás \
                 (LibreOffice-lista) és szinonimaszótár (Véleményezés › Szinonimaszótár, vagy jobb kattintás egy szón)."
            } else {
                "Még nincs a WordCraft szótármappájában."
            })
            .size(12.5)
            .color(if i { Color32::from_rgb(0x2E, 0x9E, 0x5B) } else { p.sub }),
        );
        ui.label(
            RichText::new(
                "A nyelv a dokumentum nyelvét követi; új dokumentumnál a Windows nyelve (magyar). \
                 Más szövegrésznél: Nyelv › Nyelvi ellenőrzés nyelvének beállítása… › Magyar.",
            )
            .size(12.0)
            .color(p.sub),
        );
        ui.horizontal(|ui| {
            if ui.button(if i { "Újratelepítés" } else { "Telepítés" }).clicked() {
                match crate::spell::install() {
                    Ok(d) => self.notify(format!("Magyar szótár telepítve: {}", d.display()), false),
                    Err(e) => self.notify(format!("Hiba: {e}"), true),
                }
            }
            if let Some(d) = crate::spell::wordcraft_dir() {
                if ui.button("Szótármappa megnyitása").clicked() {
                    let _ = std::fs::create_dir_all(&d);
                    apps::reveal(&d);
                }
            }
        });

        Self::section_title(ui, "Windows-integráció");
        ui.label(
            RichText::new(
                "A társítás után a .docx, .xlsx, .pptx, .pdf… fájlok „Megnyitás ezzel” menüjében megjelenik a CraftOffice. \
                 Alapértelmezetté a Windows Alapértelmezett alkalmazások beállításában teheted.",
            )
            .color(p.sub)
            .size(12.5),
        );
        let launcher = std::env::current_exe().unwrap_or_else(|_| exe_dir().join("craftoffice.exe"));
        ui.horizontal_wrapped(|ui| {
            if ui.button("Fájltársítások regisztrálása").clicked() {
                match system::register_associations(&launcher) {
                    Ok(n) => self.notify(format!("{n} fájltípus regisztrálva"), false),
                    Err(e) => self.notify(format!("Hiba: {e}"), true),
                }
            }
            if ui.button("Társítások eltávolítása").clicked() {
                match system::unregister_associations() {
                    Ok(()) => self.notify("Társítások eltávolítva", false),
                    Err(e) => self.notify(format!("Hiba: {e}"), true),
                }
            }
            if ui.button("Alapértelmezett alkalmazások…").clicked() {
                system::open_default_apps_settings();
            }
        });
        ui.horizontal_wrapped(|ui| {
            if ui.button("Asztali parancsikon").clicked() {
                match system::desktop_shortcut(&launcher) {
                    Ok(()) => self.notify("Parancsikon létrehozva az Asztalon", false),
                    Err(e) => self.notify(format!("Hiba: {e}"), true),
                }
            }
            if ui.button("Start menü parancsikonok").clicked() {
                match system::start_menu_shortcuts(&launcher, &self.installed) {
                    Ok(n) => self.notify(format!("{n} parancsikon a Start menü CraftOffice mappájában"), false),
                    Err(e) => self.notify(format!("Hiba: {e}"), true),
                }
            }
        });

        Self::section_title(ui, "Frissítések");
        if ui.checkbox(&mut self.cfg.check_updates_on_start, "Frissítések keresése indításkor (GitHub)").changed() {
            self.cfg.save();
        }

        Self::section_title(ui, "Névjegy");
        ui.label(format!("CraftOffice v{} – saját irodai és kreatív csomag a Craft alkalmazásokra építve.", env!("CARGO_PKG_VERSION")));
        ui.label(
            RichText::new(
                "A csomag alkalmazásai az ArtCraft csapat nyílt forrású (MIT / Apache-2.0) Craft alkalmazásai \
                 (WordCraft, GridCraft, DeckCraft, DesignCraft, PdfCraft, PhotoCraft…), a SolidCraft a Tangency Labs közösségi appja. \
                 A CraftOffice független, saját indító és arculat. A magyar szótár: Magyar Ispell (MPL 2.0 / LGPL 3+). \
                 A Microsoft Office a Microsoft védjegye.",
            )
            .color(p.sub)
            .size(12.5),
        );
        ui.label(RichText::new(format!("Beállítások: {}", Config::path().display())).color(p.sub).size(12.0));
        ui.add_space(20.0);
    }

    fn draw_toast(&mut self, ctx: &egui::Context) {
        let now = ctx.input(|i| i.time);
        let Some(t) = &self.toast else { return };
        if now > t.until {
            self.toast = None;
            return;
        }
        ctx.request_repaint_after(std::time::Duration::from_millis(250));
        let (bg, fg) = if t.error {
            (Color32::from_rgb(0xB4, 0x2B, 0x2B), Color32::WHITE)
        } else {
            (Color32::from_rgb(0x26, 0x2A, 0x33), Color32::WHITE)
        };
        let text = t.text.clone();
        egui::Area::new(egui::Id::unique("toast"))
            .anchor(Align2::CENTER_BOTTOM, vec2(110.0, -24.0))
            .order(egui::Order::Foreground)
            .interactable(true)
            .show(ctx, |ui| {
                let r = Frame::NONE
                    .fill(bg)
                    .corner_radius(8)
                    .inner_margin(Margin::symmetric(16, 10))
                    .show(ui, |ui| {
                        ui.set_max_width(560.0);
                        ui.label(RichText::new(text).color(fg));
                    });
                if r.response.interact(Sense::click()).clicked() {
                    self.toast = None;
                }
            });
    }
}

fn nav_item(ui: &mut Ui, p: &Pal, icon: &str, label: &str, selected: bool) -> bool {
    let (rect, resp) = ui.allocate_exact_size(vec2(ui.available_width(), 40.0), Sense::click());
    if selected || resp.hovered() {
        ui.painter().rect_filled(rect, 6, if selected { p.rail_sel } else { p.rail_sel.gamma_multiply(0.5) });
    }
    if selected {
        ui.painter().rect_filled(
            Rect::from_min_size(pos2(rect.left(), rect.top() + 9.0), vec2(3.0, 22.0)),
            2,
            GOLD,
        );
    }
    paint_nav_icon(ui.painter(), pos2(rect.left() + 22.0, rect.center().y), icon, p.rail_text);
    ui.painter().text(
        pos2(rect.left() + 44.0, rect.center().y),
        Align2::LEFT_CENTER,
        label,
        if selected { bold(15.0) } else { FontId::proportional(15.0) },
        p.rail_text,
    );
    resp.clicked()
}

impl eframe::App for OfficeApp {
    fn ui(&mut self, ui: &mut Ui, _frame: &mut eframe::Frame) {
        self.poll();
        let p = pal(ui);
        egui::Panel::left("rail")
            .exact_size(214.0)
            .resizable(false)
            .show_separator_line(false)
            .frame(Frame::NONE.fill(p.rail).inner_margin(Margin::symmetric(12, 14)))
            .show(ui, |ui| self.rail(ui));
        egui::Panel::top("top")
            .show_separator_line(false)
            .frame(Frame::NONE.fill(p.bg).inner_margin(Margin { left: 28, right: 24, top: 14, bottom: 6 }))
            .show(ui, |ui| self.topbar(ui));
        egui::CentralPanel::default()
            .frame(Frame::NONE.fill(p.bg).inner_margin(Margin { left: 32, right: 28, top: 10, bottom: 10 }))
            .show(ui, |ui| {
                egui::ScrollArea::vertical().id_salt(self.page as u8).auto_shrink([false, false]).show(ui, |ui| {
                    ui.set_max_width(ui.available_width().min(1100.0));
                    match self.page {
                        Page::Home => self.home(ui),
                        Page::New => self.new_page(ui),
                        Page::Open => self.open_page(ui),
                        Page::Apps => self.apps_page(ui),
                        Page::Settings => self.settings_page(ui),
                    }
                    ui.add_space(24.0);
                });
            });
        let ctx = ui.ctx().clone();
        self.draw_toast(&ctx);
        if ctx.input(|i| !i.raw.hovered_files.is_empty()) {
            let screen = ctx.content_rect();
            ctx.layer_painter(egui::LayerId::new(egui::Order::Foreground, egui::Id::unique("drop")))
                .rect_filled(screen, 0, Color32::from_black_alpha(140));
            ctx.layer_painter(egui::LayerId::new(egui::Order::Foreground, egui::Id::unique("drop_t"))).text(
                screen.center(),
                Align2::CENTER_CENTER,
                "Engedd el a megnyitáshoz",
                bold(26.0),
                Color32::WHITE,
            );
        }
    }
}

fn paint_star(painter: &egui::Painter, c: egui::Pos2, r: f32, filled: bool, color: Color32) {
    use std::f32::consts::{FRAC_PI_2, PI};
    let pts: Vec<egui::Pos2> = (0..10)
        .map(|k| {
            let a = -FRAC_PI_2 + k as f32 * PI / 5.0;
            let rad = if k % 2 == 0 { r } else { r * 0.45 };
            pos2(c.x + rad * a.cos(), c.y + rad * a.sin())
        })
        .collect();
    if filled {
        for k in (0..10).step_by(2) {
            let quad = vec![c, pts[(k + 9) % 10], pts[k], pts[(k + 1) % 10]];
            painter.add(egui::Shape::convex_polygon(quad, color, Stroke::NONE));
        }
    } else {
        painter.add(egui::Shape::closed_line(pts, Stroke::new(1.4, color)));
    }
}

/// Egyszerű vektoros ikonok a bal oldali menühöz (nem függnek a betűkészlettől).
fn paint_nav_icon(painter: &egui::Painter, c: egui::Pos2, kind: &str, color: Color32) {
    let s = Stroke::new(1.6, color);
    match kind {
        "home" => {
            painter.add(egui::Shape::line(
                vec![pos2(c.x - 8.0, c.y - 1.0), pos2(c.x, c.y - 8.0), pos2(c.x + 8.0, c.y - 1.0)],
                s,
            ));
            painter.add(egui::Shape::line(
                vec![pos2(c.x - 6.0, c.y - 2.5), pos2(c.x - 6.0, c.y + 7.0), pos2(c.x + 6.0, c.y + 7.0), pos2(c.x + 6.0, c.y - 2.5)],
                s,
            ));
            painter.rect_filled(Rect::from_min_max(pos2(c.x - 2.0, c.y + 2.0), pos2(c.x + 2.0, c.y + 7.0)), 0, color);
        }
        "new" => {
            painter.line_segment([pos2(c.x - 7.0, c.y), pos2(c.x + 7.0, c.y)], Stroke::new(2.0, color));
            painter.line_segment([pos2(c.x, c.y - 7.0), pos2(c.x, c.y + 7.0)], Stroke::new(2.0, color));
        }
        "open" => {
            painter.add(egui::Shape::closed_line(
                vec![
                    pos2(c.x - 8.0, c.y - 6.0),
                    pos2(c.x - 2.5, c.y - 6.0),
                    pos2(c.x - 0.5, c.y - 3.5),
                    pos2(c.x + 8.0, c.y - 3.5),
                    pos2(c.x + 8.0, c.y + 6.5),
                    pos2(c.x - 8.0, c.y + 6.5),
                ],
                s,
            ));
        }
        "apps" => {
            for (dx, dy) in [(-4.5, -4.5), (4.5, -4.5), (-4.5, 4.5), (4.5, 4.5)] {
                painter.rect_stroke(Rect::from_center_size(pos2(c.x + dx, c.y + dy), vec2(6.5, 6.5)), 1.5, s, StrokeKind::Middle);
            }
        }
        _ => {
            painter.circle_stroke(c, 3.2, s);
            painter.circle_stroke(c, 6.3, s);
            for k in 0..8 {
                let a = k as f32 * std::f32::consts::PI / 4.0;
                let (cs, sn) = (a.cos(), a.sin());
                painter.line_segment([pos2(c.x + 6.0 * cs, c.y + 6.0 * sn), pos2(c.x + 9.0 * cs, c.y + 9.0 * sn)], Stroke::new(2.6, color));
            }
        }
    }
}
