fn main() {
    println!("cargo:rerun-if-changed=assets/craftoffice.ico");
    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("windows") {
        let mut res = winresource::WindowsResource::new();
        res.set_icon("assets/craftoffice.ico")
            .set("ProductName", "CraftOffice")
            .set("FileDescription", "CraftOffice – irodai csomag indító")
            .set("LegalCopyright", "MIT OR Apache-2.0");
        if let Err(e) = res.compile() {
            println!("cargo:warning=ikon beágyazása sikertelen: {e}");
        }
    }
}
